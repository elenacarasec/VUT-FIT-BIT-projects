
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, Space, Input, Select} from 'antd';
import StaffHeader from '../../components/header/staff_header';
import styles from '../../styles/index.module.scss';
import staffStyles from '../../styles/staff.module.scss';
import Router from 'next/router' 
import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";

const { Search } = Input;
const onSearch = value => console.log(value);
class StaffPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loggedUser: 'loading',
        }
    }
    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user})
        }
    }

    handleFinish = (data) => {
        console.log('This is my data!!!', data)
    }

    render() {
        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && this.state.loggedUser.role === 'STAFF') {

        return (
            <div>
                <Head>
                    <title>Staff</title>
                </Head>
		        <Header style={{padding: '0',}}>
                	<StaffHeader/>
		        </Header>  
                
                <Row align='center' className={styles.centerdBlock} style={{padding: '60em 50em'}}>
                    
                <Search
                    placeholder="Input route numder"
                    allowClear
                    enterButton="Search"
                    size="large"
                    onSearch={onSearch}
    />
                </Row>
            </div>
        )}
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'STAFF')) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}


const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (StaffPage);