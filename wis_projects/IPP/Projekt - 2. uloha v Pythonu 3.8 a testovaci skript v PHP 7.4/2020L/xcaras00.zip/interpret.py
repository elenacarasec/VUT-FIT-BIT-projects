import argparse
import os.path
import sys
import re
import xml.etree.ElementTree as ET
from collections import namedtuple

def arg_parse():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--help', required=False)
    parser.add_argument('--src', nargs=1, type=str)
    parser.add_argument('--input', nargs=1, type=str)
    args = parser.parse_args()
    if not (args.src or args.input):
        parser.error('Please enter source or input file, or both.')
    if args.src:
        try:
            os.path.exists(args.src[0])
        except:
            parser.error('Invalid source file.')
            exit(11)
        else:
            args.src = args.src[0]
    else:
        args.src = sys.stdin
    if args.input:
        try:
            os.path.exists(args.input[0])
        except:
            parser.error('Invalid input file.')
            exit(11)
        
            args.input = args.input[0]
    else:
        args.input = sys.stdin
    return args.src, args.input


class Frame:
    def __init__(self):
        self.state = 'GF'
        self.curr_frame_vars = []
        self.temp_frame = []
        self.stack_frames = []

    def createframe(self):
        self.stack_frames.append(self.curr_frame_vars)
        self.temp_frame.append(1)
        self.state = 'TF'

    def pushframe(self):
        self.state = 'LF'
        try:
            self.temp_frame.pop()
        except:
            print("PUSHFRAME without CREATEFRAME", file=sys.stderr)
            exit(55)

    def popframe(self):
        if self.state != 'LF':
            print("POPFRAME without PUSHFRAME", file=sys.stderr)
            exit(55)
        self.curr_frame_vars = self.stack_frames.pop()
        if len(self.stack_frames) > 0:
            self.state = 'TF'
        else:
            self.state = 'GF'

    def get_state(self):
        return self.state


class Variable:
    def __init__(self, name, frame):
        self.name = name[3:]
        self.type = None
        self.value = None
        frame.curr_frame_vars.append(self)

    def check_frame(frame, frame_name):
        if not (f"{frame.get_state()}@" == frame_name or frame_name == 'GF@'):
            exit(55)

    def update(frame, name, newvalue, newvaluetype):
        Variable.check_frame(frame, name[:3])
        found = False
        for var in frame.curr_frame_vars:
            if name[3:] == var.name:
                found = True
                var.type = newvaluetype
                var.value = newvalue
        if not found:
            print("Undefined variable", file=sys.stderr)
            exit(54)

    def get_value(self, frame, name, accepted_types):
        Variable.check_frame(frame, name[:3])
        found = False
        var_list = frame.curr_frame_vars
        if name[:3] == 'GF' and not frame.get_state() == 'GF':
            var_list = frame.stack_frames[0]
        for var in var_list:
            if name[3:] == var.name:
                found = True
                if var.value == None:
                    print("Variable without value", file=sys.stderr)
                    exit(56)
                # if not var.type in accepted_types:
                #     print(f"Unacceptable variable type: {var.type}, acepted: {accepted_types}", file = sys.stderr)
                #     exit(53)
                return var.value
        if not found:
            print("Undefined variable", file=sys.stderr)
            exit(54)

    def get_type(frame, name):
        Variable.check_frame(frame, name[:3])
        found = False
        var_list = frame.curr_frame_vars
        if name[:3] == 'GF'and not frame.get_state()  == 'GF':
            var_list = frame.stack_frames[0]
        for var in var_list:
            if name[3:] == var.name:
                found = True
                return var.type
        if not found:
            print("Undefined variable", file=sys.stderr)
            exit(54)


class Interpret:
    def var_symb1_symb2(opcode, grandson, frame):
        val1, val2 = 0, 0
        if opcode == 'ADD':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                try:
                    val1 = int(var1.get_value(frame, grandson[1].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val1 = int(grandson[1].text)
                except:
                    exit(53)

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'int'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                try:
                    val2 = int(var2.get_value(frame, grandson[2].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val2 = int(grandson[2].text)
                except:
                    exit(53)

            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            Variable.update(frame, grandson[0].text, str(val1 + val2), 'int')

        elif opcode == 'SUB':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                try:
                    val1 = int(var1.get_value(frame, grandson[1].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val1 = int(grandson[1].text)
                except:
                    exit(53)

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'int'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                try:
                    val2 = int(var2.get_value(frame, grandson[2].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val2 = int(grandson[2].text)
                except:
                    exit(53)

            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            Variable.update(frame, grandson[0].text, str(val1 - val2), 'int')

        elif opcode == 'MUL':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                try:
                    val1 = int(var1.get_value(frame, grandson[1].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val1 = int(grandson[1].text)
                except:
                    exit(53)

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'int'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                try:
                    val2 = int(var2.get_value(frame, grandson[2].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val2 = int(grandson[2].text)
                except:
                    exit(53)

            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            Variable.update(frame, grandson[0].text, str(val1 * val2), 'int')

        elif opcode == 'IDIV':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                try:
                    val1 = int(var1.get_value(frame, grandson[1].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val1 = int(grandson[1].text)
                except:
                    exit(53)

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'int'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                try:
                    val2 = int(var2.get_value(frame, grandson[2].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val2 = int(grandson[2].text)
                except:
                    exit(53)
            if val2 == 0:
                exit(57)
            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            Variable.update(frame, grandson[0].text, str(val1 // val2), 'int')

        elif opcode == 'LT':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int', 'bool', 'string'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['int'])
            else:
                val1 = grandson[1].text

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'int', 'bool', 'string'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                val2 = var2.get_value(frame, grandson[2].text, ['int'])
            else:
                val2 = grandson[2].text

            type1, type2 = None, None
            if grandson[1].attrib['type'] == 'var':
                type1 = Variable.get_type(frame, grandson[1].text)
            else:
                type1 = grandson[1].attrib['type']
            
            if grandson[2].attrib['type'] == 'var':
                type2 = Variable.get_type(frame, grandson[2].text)
            else:
                type2 = grandson[2].attrib['type']

            if type1 != type2:
                exit(53)
            
            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            if type1 == 'int':
                try:
                    Variable.update(frame, grandson[0].text, str(int(val1) < int(val2)), 'bool')
                except:
                    exit(53)
            elif type2 == 'bool':
                try:
                    Variable.update(frame, grandson[0].text, str(bool(val1) < bool(val2)), 'bool')
                except:
                    exit(53)
            else:
                try:
                    Variable.update(frame, grandson[0].text, str(val1 < val2), 'bool')
                except:
                    exit(53)
        elif opcode == 'GT':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int', 'bool', 'string'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['int'])
            else:
                val1 = grandson[1].text

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'int', 'bool', 'string'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                val2 = var2.get_value(frame, grandson[2].text, ['int'])
            else:
                val2 = grandson[2].text

            type1, type2 = None, None
            if grandson[1].attrib['type'] == 'var':
                type1 = Variable.get_type(frame, grandson[1].text)
            else:
                type1 = grandson[1].attrib['type']
            
            if grandson[2].attrib['type'] == 'var':
                type2 = Variable.get_type(frame, grandson[2].text)
            else:
                type2 = grandson[2].attrib['type']

            if type1 != type2:
                exit(53)
            
            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            if type1 == 'int':
                try:
                    Variable.update(frame, grandson[0].text, str(int(val1) > int(val2)), 'bool')
                except:
                    exit(53)
            elif type2 == 'bool':
                try:
                    Variable.update(frame, grandson[0].text, str(bool(val1) > bool(val2)), 'bool')
                except:
                    exit(53)
            else:
                try:
                    Variable.update(frame, grandson[0].text, str(val1 > val2), 'bool')
                except:
                    exit(53)
        elif opcode == 'EQ':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int', 'bool', 'string', 'nil'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['int'])
            else:
                val1 = grandson[1].text

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'int', 'bool', 'string', 'nil'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                val2 = var2.get_value(frame, grandson[2].text, ['int'])
            else:
                val2 = grandson[2].text

            type1, type2 = None, None
            if grandson[1].attrib['type'] == 'var':
                type1 = Variable.get_type(frame, grandson[1].text)
            else:
                type1 = grandson[1].attrib['type']
            
            if grandson[2].attrib['type'] == 'var':
                type2 = Variable.get_type(frame, grandson[2].text)
            else:
                type2 = grandson[2].attrib['type']

            if not (type1 == type2 or type1 == 'nil' or type2 == 'nil'):
                exit(53)
            
            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            Variable.update(frame, grandson[0].text, str(val1 == val2), 'bool')

        elif opcode == 'AND':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'bool'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                try:
                    val1 = bool(var1.get_value(frame, grandson[1].text, ['bool']))
                except:
                    exit(53)
            else:
                try:
                    val1 = bool(grandson[1].text)
                except:
                    exit(53)

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'bool'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                try:
                    val2 = bool(var2.get_value(frame, grandson[2].text, ['bool']))
                except:
                    exit(53)
            else:
                try:
                    val2 = bool(grandson[2].text)
                except:
                    exit(53)

            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            Variable.update(frame, grandson[0].text, str(val1 and val2), 'bool')

        elif opcode == 'OR':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'bool'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                try:
                    val1 = bool(var1.get_value(frame, grandson[1].text, ['bool']))
                except:
                    exit(53)
            else:
                try:
                    val1 = bool(grandson[1].text)
                except:
                    exit(53)

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'bool'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                try:
                    val2 = bool(var2.get_value(frame, grandson[2].text, ['bool']))
                except:
                    exit(53)
            else:
                try:
                    val2 = bool(grandson[2].text)
                except:
                    exit(53)

            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            Variable.update(frame, grandson[0].text, str(val1 or val2), 'bool')

        elif opcode == 'STRI2INT':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'string'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['string'])
            else:
                val1 = grandson[1].text

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'int'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                try:
                    val2 = int(var2.get_value(frame, grandson[2].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val2 = int(grandson[2].text)
                except:
                    exit(53)

            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            try:
                ord(val1[val2])
            except:
                exit(58)
            Variable.update(frame, grandson[0].text, str(ord(val1[val2])), 'int')
        
        elif opcode == 'CONCAT':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'string'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['string'])
            else:
                val1 = grandson[1].text

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'string'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                val2 = var2.get_value(frame, grandson[2].text, ['string'])
            else:
                val2 = grandson[2].text

            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            Variable.update(frame, grandson[0].text, val1 + val2, 'string')
                
        elif opcode == 'GETCHAR':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'string'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['string'])
            else:
                val1 = grandson[1].text

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'int'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                val2 = int(var.get_value(frame, grandson[2].text, ['int']))
            else:
                val2 = int(grandson[2].text)

            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            try:
                val1[val2]
            except:
                exit(58)
            Variable.update(frame, grandson[0].text, val1[val2], 'string')

        elif opcode == 'SETCHAR':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = int(var1.get_value(frame, grandson[1].text, ['int']))
            else:
                val1 = int(grandson[1].text)

            Type.is_acceptable_type(grandson[2].attrib['type'], ['var', 'string'], grandson[2].text)
            if grandson[2].attrib['type'] == 'var':
                var2 = Variable(grandson[2].text, frame)
                val2 = var2.get_value(frame, grandson[2].text, ['string'])
            else:
                val2 = grandson[2].text

            if val2 == '':
                exit(58)

            # Type.is_acceptable_type(grandson[0].attrib['type'], ['var'], grandson[0].text)
            # var0 = Variable(grandson[0].text, frame)
            var0 = list(Variable.get_value(frame, grandson[0].text, ['string']))
            try:
                var0[val1] = val2[0]
                var0 = ''.join(var0)
            except:
                exit(58)
            Variable.update(frame, grandson[0].text, var0, 'string')

    #JUMPIFEQ|JUMPIFNEQ
    def label_symb1_symb2(opcode, grandson, frame):
        pass

    def var(opcode, grandson, frame, stack):
        if opcode == 'DEFVAR':
            if grandson[0].text[:2] != frame.get_state():
                exit(55)
            var = Variable(grandson[0].text, frame)
        
        elif opcode == 'POPS':
            val1 = 0
            try:
                val1 = stack.pop()
            except:
                exit(56)
            Variable.update(frame, grandson[0].text, val1[0], val1[1])


    def var_symb(opcode, grandson, frame):
        if opcode == 'MOVE':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int', 'bool', 'string', 'nil'], grandson[1].text)
            symb_type = grandson[1].attrib['type']
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['int'])
                symb_type = Variable.get_type(frame, grandson[1].text)
            else:
                val1 = grandson[1].text
            Variable.update(frame, grandson[0].text, val1, 'string')

        elif opcode == 'INT2CHAR':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int'], grandson[1].text)
            symb_type = grandson[1].attrib['type']
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['int'])
            else:
                val1 = grandson[1].text
            try:
                chr(val1)
            except:
                exit(58)
            Variable.update(frame, grandson[0].text, chr(val1), 'string')

        elif opcode == 'STRLEN':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'string'], grandson[1].text)
            symb_type = grandson[1].attrib['type']
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['string'])
            else:
                val1 = grandson[1].text
            try:
                Variable.update(frame, grandson[0].text, str(len(val1)), 'int')
            except:
                exit(53)
        
        elif opcode == 'TYPE':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'int', 'bool', 'string', 'nil'], grandson[1].text)
            symb_type = grandson[1].attrib['type']
            if grandson[1].attrib['type'] == 'var':
                symb_type = Variable.get_type(frame, grandson[1].text)

            if symb_type == None:
                symb_type = ''
            Variable.update(frame, grandson[0].text, symb_type, 'string')
        
        elif opcode == 'NOT':
            Type.is_acceptable_type(grandson[1].attrib['type'], ['var', 'bool'], grandson[1].text)
            if grandson[1].attrib['type'] == 'var':
                var1 = Variable(grandson[1].text, frame)
                val1 = var1.get_value(frame, grandson[1].text, ['bool'])
            else:
                val1 = grandson[1].text

            try:
                Variable.update(frame, grandson[0].text, str(not(bool(val1))), 'bool')
            except:
                exit(53)


    # READ
    def read(opcode, grandson, frame, prg_input):
        symb_type = grandson[1].text
        try:
            val1 = prg_input.readline()
            if symb_type == 'string':
                if not Type.check_string('string', val1):
                    exit(53)
            elif symb_type == 'int':
                if not Type.check_int('int', val1):
                    exit(53)
            elif symb_type == 'bool':
                if not Type.check_bool('bool', val1):
                    exit(53)
        except:
            val1 = 'nil'
            symb_type = 'nil'

        if symb_type == 'bool':
            if val1.upper() == 'TRUE':
                val1 = 'True'
            else:
                val1 = 'False'
    
        Variable.update(frame, grandson[0].text, val1, symb_type)
        


    def symb(opcode, grandson, frame, stack):
        if opcode == 'WRITE':
            if Type.check_type(grandson[0].attrib['type'], grandson[0].text):
                this_type = grandson[0].attrib['type']
                if this_type == 'int':
                    print(grandson[0].text, end='')
                elif this_type == 'bool':
                    if grandson[0].text == 'true':
                        print('true', end='')
                    else:
                        print('false', end='')
                elif this_type == 'string':
                    def ascii_repl(matchobj):
                        return chr(int(matchobj.group(0)[1:]))
                    this_str = re.sub(r'\\[0-9]{3}', ascii_repl, grandson[0].text)
                    print(this_str, end='')
                elif this_type == 'nil':
                    print('', end='')
                elif this_type == 'var':
                    var = Variable(grandson[0].text, frame)
                    print(var.get_value(frame, grandson[0].text, ['int', 'bool', 'string', 'nil']), end='')
                else:
                    exit(53)

        elif opcode == 'DPRINT':
            pass

        elif opcode == 'EXIT':
            Type.is_acceptable_type(grandson[0].attrib['type'], ['var', 'int'], grandson[0].text)
            if grandson[0].attrib['type'] == 'var':
                var1 = Variable(grandson[0].text, frame)
                try:
                    val1 = int(var1.get_value(frame, grandson[0].text, ['int']))
                except:
                    exit(53)
            else:
                try:
                    val1 = int(grandson[0].text)
                except:
                    exit(53)

            if val1 < 0 or val1 > 49:
                exit(57)
            else:
                exit(val1)
        
        elif opcode == 'PUSHS':
            symb_type = grandson[0].attrib['type']
            if grandson[0].attrib['type'] == 'var':
                var1 = Variable(grandson[0].text, frame)
                val1 = var1.get_value(frame, grandson[0].text, ['int'])
                symb_type = var1.get_type(frame, grandson[0].text)
            else:
                val1 = grandson[0].text
            stack.append([val1, symb_type])

    
    # CALL|LABEL|JUMP
    def label(opcode, grandson, frame):
        pass

    # RETURN
    def nothing(opcode, frame):
        if opcode == 'BREAK':
            pass
        elif opcode == 'CREATEFRAME':
            frame.createframe()
        elif opcode == 'PUSHFRAME':
            frame.pushframe()
        elif opcode == 'POPFRAME':
            frame.popframe()
        elif opcode == 'RETURN':
            pass


class Type:
    def check_var(this_str):
        var_re = r"^(GF|TF|LF){1}@([_\-\$\&%\*\!\?]|[a-z]|[A-Z])([_\-\$\&%\*\!\?]|\w)*$"
        if re.match(var_re, this_str):
            return True

    def check_label(this_str):
        label_re = r"^[_\-\$\&%\*\!\?]|[a-z]|[A-Z]([_\-\$\&%\*\!\?]|\w)*$"
        if re.match(label_re, this_str):
            return True

    def check_int(str_type, this_str):
        if re.match(r"^[\+\-]?(\d)*$", this_str):
            return True

    def check_bool(str_type, this_str):
        return True

    def check_string(str_type, this_str):
        str_re = r"^(\\\\[0-9]{3}|\w|[_\+\-\*\,\.\/\$\&%\*\!\?@\'\"\<\>\[\]\(\)\{\}\^\=\:\;\`\|\~])*$"
        if not re.search(r"(?!\\[0-9]{3})[\s\\#]", this_str):
            return True

    def check_nil(str_type, this_str):
        if this_str == 'nil':
            return True

    def check_type(str_type, this_str):
        if str_type == 'int':
            return Type.check_int(str_type, this_str)
        elif str_type == 'string':
            return Type.check_string(str_type, this_str)
        elif str_type == 'bool':
            return Type.check_bool(str_type, this_str)
        elif str_type == 'nil':
            Type.check_nil(str_type, this_str)
        elif str_type == 'var':
            return Type.check_var(this_str)
        elif str_type == 'label':
            return Type.check_label(this_str)
        else:
            return False
    
    def is_acceptable_type(str_type, accepted_types, this_str):
        if str_type in accepted_types:
            return Type.check_type(str_type, this_str)


class Operation:
    def __init__(self, opcode):
        self.opcode = opcode

    def check_opcode_group(self, frame, stack, grandson, prg_input):
        print(self.opcode, file=sys.stderr)
        if re.match("^(CREATEFRAME|PUSHFRAME|POPFRAME|RETURN|BREAK)$", self.opcode):
            Operation.check_group0(grandson)
            Interpret.nothing(self.opcode, frame)
        elif re.match("^(PUSHS|WRITE|EXIT|DPRINT)$", self.opcode):
            Operation.check_group1_symb(grandson)
            Interpret.symb(self.opcode, grandson, frame, stack)
        elif re.match("^(DEFVAR|POPS)$", self.opcode):
            Operation.check_group1_var(grandson)
            Interpret.var(self.opcode, grandson, frame, stack)
        elif re.match("^(CALL|LABEL|JUMP)$", self.opcode):
            Operation.check_group1_label(grandson)
            Interpret.label(self.opcode, grandson, frame)
        elif re.match("^(MOVE|INT2CHAR|STRLEN|TYPE|NOT)$", self.opcode):
            Operation.check_group2_var_symb(grandson)
            Interpret.var_symb(self.opcode, grandson, frame)
        elif self.opcode == "READ":
            Operation.check_group2_var_type(grandson)
            Interpret.read(self.opcode, grandson, frame, prg_input)
        elif re.match("^(ADD|SUB|MUL|IDIV|LT|GT|EQ|AND|OR|STRI2INT|CONCAT|GETCHAR|SETCHAR)$", self.opcode):
            Operation.check_group3_var_symb1_symb2(grandson)
            Interpret.var_symb1_symb2(self.opcode, grandson, frame)
        elif re.match("^(JUMPIFEQ|JUMPIFNEQ)$", self.opcode):
            Operation.check_group3_label_symb1_symb2(grandson)
            Interpret.label_symb1_symb2(self.opcode, grandson, frame)
        else:
            exit(32)

    def check_group0(grandson):
        pass

    def check_group1_symb(grandson):
        if grandson[0].tag != 'arg1':
            exit(32)
        if not Type.check_type(grandson[0].attrib['type'], grandson[0].text):
            exit(53)

    def check_group1_var(grandson):
        if grandson[0].tag != 'arg1':
            exit(32)
        if grandson[0].attrib['type'] != 'var':
            exit(32)
        if not Type.check_var(grandson[0].text):
            exit(53)

    def check_group1_label(grandson):
        if grandson[0].tag != 'arg1':
            exit(32)
        if grandson[0].attrib['type'] != 'label':
            exit(32)
        if not re.match("[_\-\$\&%\*\!\?]|[a-z]|[A-Z]([_\-\$\&%\*\!\?]|\w)*/", grandson[0].text):
            exit(53)

    def check_group2_var_symb(grandson):
        if grandson[0].tag == 'arg1' and grandson[1].tag == 'arg2':
            if grandson[0].attrib['type'] == 'var':
                if Type.check_var(grandson[0].text) and Type.check_type(grandson[1].attrib['type'], grandson[1].text):
                    pass
                else:
                    exit(53)
            else:
                exit(32)
        elif grandson[1].tag == 'arg1' and grandson[0].tag == 'arg2':
            if grandson[1].attrib['type'] == 'var':
                if Type.check_var(grandson[1].text) and Type.check_type(grandson[0].attrib['type'], grandson[0].text):
                    pass
                else:
                    exit(53)
            else:
                exit(32)
        else:
            exit(32)

    def check_group2_var_type(grandson):
        if grandson[0].tag == 'arg1' and grandson[1].tag == 'arg2':
            if grandson[0].attrib['type'] == 'var' and grandson[1].attrib['type'] == 'type':
                if not Type.check_var(grandson[0].text) or not re.match("int|string|bool", grandson[1].text):
                    exit(53)
            else:
                exit(32)
        elif grandson[1].tag == 'arg1' and grandson[0].tag == 'arg2':
            if grandson[1].attrib['type'] == 'var' and grandson[0].attrib['type'] == 'type':
                if not Type.check_var(grandson[1].text) or not re.match("int|string|bool", grandson[0].text):
                    exit(53)
            else:
                exit(32)
        else:
            exit(32)

    def check_group3_var_symb1_symb2(grandson):
        args = [False, False, False]
        for son in grandson:
            if son.tag == 'arg1':
                if son.attrib['type'] == 'var' and Type.check_var(son.text):
                    args[0] = True
                    continue
                exit(53)
            elif son.tag == 'arg2':
                if Type.check_type(son.attrib['type'], son.text):
                    args[1] = True
                    continue
                exit(53)
            elif son.tag == 'arg3':
                print(son.attrib['type'], son.text, file=sys.stderr)
                if Type.check_type(son.attrib['type'], son.text):
                    args[2] = True
                    continue
                exit(53)
        if False in args:
            exit(32)

    def check_group3_label_symb1_symb2(grandson):
        args = [False, False, False]
        for son in grandson:
            if son.tag == 'arg1':
                if son.attrib['type'] == 'label':
                    args[0] = True
                    continue
                exit(53)
            if son.tag == 'arg2':
                if re.match("^(int|var|string|bool|nil)$", son.attrib['type']):
                    args[1] = True
                    continue
                exit(53)
            if son.tag == 'arg3':
                if re.match("^(int|var|string|bool|nil)$", son.attrib['type']):
                    args[2] = True
                    continue
                exit(53)
        if False in args:
            exit(32)


def xml_parse(src, prg_input):
    try:
        xml_tree = ET.parse(src)
    except:
        exit(31)
    root = xml_tree.getroot()
    if root.tag != 'program':
        exit(32)
    for attr in root.attrib:
        if attr == 'language':
            if root.attrib['language'].upper() != 'IPPCODE21':
                exit(32)
        elif attr == 'name' or attr == 'description':
            pass
        else:
            print(f'Invalid root attribute {attr}', file=sys.stderr)
            exit(32)

    try:
        root[:] = sorted(root, key=lambda child: int(child.get('order')))
    except:
        exit(32)
    order_num = 0
    opcodes = ['MOVE', 'CREATEFRAME', 'PUSHFRAME', 'POPFRAME', 'DEFVAR', 'CALL', 'RETURN', 'PUSHS', 'POPS', 'ADD', 'SUB', 'MUL', 'IDIV', 
                'LT', 'GT', 'EQ', 'AND', 'OR', 'NOT', 'INT2CHAR', 'STRI2INT', 'READ', 'WRITE', 'CONCAT', 'STRLEN', 'GETCHAR', 'SETCHAR', 'TYPE', 'LABEL', 'JUMP',
                'JUMPIFEQ', 'JUMPIFNEQ', 'LABEL', 'EXIT', 'DPRINT', 'BREAK']

    frame = Frame()
    stack = []
    for child in root:
        if child.tag != 'instruction':
            print(f'Unexpected child tag {child.tag}', file=sys.stderr)
            exit(32)

        for attr in child.attrib:
            if attr == 'order' and int(child.attrib['order']) > order_num:
                order_num = int(child.attrib['order'])
            elif attr == 'opcode':
                if child.attrib['opcode'].upper() not in opcodes:
                    print(f'Invalid opcode: {child.attrib["opcode"]}', file=sys.stderr)
                    exit(32)
            else:
                print(f'Invalid instruction attribute {attr}', file=sys.stderr)
                exit(32)
        try:
            operation = Operation(child.attrib['opcode'].upper())
        except:
            exit(32)
        operation.check_opcode_group(frame, stack, child, prg_input)


def __main__():
    src, prg_input = arg_parse()
    if prg_input != sys.stdin:
        try:
            f = open(prg_input[0], "r")
        except:
            print(f'Error, while opening input file {prg_input}', file=sys.stderr)
            exit(11)
        xml_parse(src, f)
        f.close()
    else:
        xml_parse(src, prg_input)


__main__()
