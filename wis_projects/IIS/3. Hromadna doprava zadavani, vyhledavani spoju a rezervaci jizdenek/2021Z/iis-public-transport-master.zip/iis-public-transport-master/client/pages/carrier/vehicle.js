import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Button, Table, Space, Typography} from 'antd';
const { Text } = Typography;
const { Column, ColumnGroup } = Table;
import CarrierHeader from '../../components/header/carrier_header';
import AdminHeader from '../../components/header/forms/adminHeader'
import styles from '../../styles/index.module.scss';
import Link from "next/link"; 
import axios from 'axios';
import { message } from 'antd';

import Router from 'next/router' 
import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";


class CarrierPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          loggedUser: "loading",
          data: []
        }


      }
      componentDidMount = () => {
          let token = localStorage.getItem('authToken')
          if (token === null) {
              Router.push('/')
          } else {
              let user = jwt_decode(token)
              this.setState({loggedUser: user})
          }
        axios({
          method: "get",
          url: "https://iis-public-transport.herokuapp.com/api/vehicle/list_all",
      })
          .then(res => {
            console.log(res.data)

            this.setState({data:res.data})
          }
              )
          .catch(err =>   message.info('No vehicles found'))
    }

    handleChoose = (data) => {
      console.log(data)

      Router.push({pathname: '/carrier/vehicleEdit', 
      query: {id: data.id,connectionId: data.connectionId, model: data.model, description: data.description, license_plate: data.license_plate, number: Number(data.number),number_of_seats: Number(data.number_of_seats )}})
    }

    render() {

      const columns = [
        {
          title: ' ID',
          dataIndex: 'id',
          key: 'id',
          render: text => <a>{text}</a>,
        },
        {
          title: 'connection ID',
          dataIndex: 'connectionId',
          key: 'connectionId',
          render: text => <a>{text}</a>,
        },
        {
          title: 'Model',
          dataIndex: 'model',
          key: 'model',
        },

        {
          title: 'Description',
          dataIndex: 'description',
          key: 'description',
        },
        {
           title: 'license_plate',
           dataIndex: 'license_plate',
           key: 'license_plate',
        },
        {
          title: 'number',
          dataIndex: 'number',
          key: 'number',
        },
        {
          title: 'number_of_seats',
          dataIndex: 'number_of_seats',
          key: 'number_of_seats',
        },
          {
            title: 'Choose',
            key: 'Choose',
            render: (text, record) => (
              <Space size="middle">
                <a onClick={() => {this.handleChoose(record)}}>Choose</a>
              </Space>
            ),
          },
    
      ];

      if (this.state.loggedUser === 'loading') {
        return (
            <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                <LoadingOutlined/>
            </div>
        )
    } else if (this.state.loggedUser && (this.state.loggedUser.role === 'CARRIER' || this.state.loggedUser.role === 'ADMIN') ) {

        return (
          <>
          {console.log('this.state.data.length', this.state.data.length)}
          {this.state.data.length > 0 ?
            <div>
                <Head>
                    <title>Staff</title>
                </Head>     
                
                <Header style={{padding: '0'}}>
                  {this.state.loggedUser.role === 'CARRIER' ?
                     <CarrierHeader/>
                     : <AdminHeader/>
                  }
                  
                   
                </Header>
     
                <Row  style={{marginTop: '12em'}}>
                <Col xs={0} sm={1} md={3} lg={4} xl={4}>
                </Col>
                <Col align='right' xs={0} sm={6} md={14} lg={15} xl={15}>
                <Link href="/carrier/newVehicle">
                    <Button type='primary' size='large' htmlType='submit'style={{marginRight:"500px", marginBottom:"50px"}} className={styles.buttonLog}>Add new vehicle</Button>
                </Link>
                {console.log(this.state.data)}
                    {this.state.data &&
                    <Table columns={columns} dataSource={this.state.data} />}
                </Col>
                </Row> 

            </div>
          :
          <p></p>
        }
        </>
        )}
        else if ((this.state.loggedUser && (this.state.loggedUser.role !== 'CARRIER' || this.state.loggedUser.role !== 'ADMIN' ))) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (CarrierPage);

