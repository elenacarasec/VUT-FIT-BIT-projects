import React, { useEffect, useState } from "react";
import { Provider } from 'react-redux'
import { useStore } from '../store/makeStore'
import {Layout} from "antd";

import 'antd/dist/antd.min.css';
import '../style.sass'; // Global Styles is here
import Head from "next/head";

import { useRouter } from 'next/router';
import OurHeader from '../components/header/header'
import Api from "../Api"

const {Content, Header} = Layout;

export default function App({ Component, pageProps }) {
    const store = useStore(pageProps.initialReduxState)
    const router = useRouter();
    useEffect(() => {
        const api = new Api
      });
    return (
        <Provider store={store}>
            <Head>
                <title> Transport </title>
            </Head>

            {router.pathname !== '/staff/staff' 
                && router.pathname !== '/carrier/carrier'
                && router.pathname !== '/carrier/staff'
                && router.pathname !== '/carrier/staffEdition'
                && router.pathname !== '/carrier/staffRegistration'
                && router.pathname !== '/carrier/newVehicle'
                && router.pathname !== '/carrier/vehicle'
                && router.pathname !== '/carrier/vehicleEdit'
                && router.pathname !== '/carrier/connectionList'
                && router.pathname !== '/carrier/connectionEdit'
                && router.pathname !== '/carrier/newConnection'
                && router.pathname !== '/carrier/transportAdmin'
                && router.pathname !== '/admin' 
                && router.pathname !== '/adminTable' 
                && router.pathname !== '/adminAddAcc' 
                && router.pathname !== '/registrationUser' 
                && router.pathname !== '/adminPage' 
                && router.pathname !== '/staff/staffAdmin' 
                && router.pathname !== '/staff/staffRoute' 
                && router.pathname !== '/staff/staffTable' 
                && router.pathname !== '/staff/staffEdit' 
                && router.pathname !== '/staff/staffStop' 
                && router.pathname !== '/staff/ticketsList' 
                && router.pathname !== '/carrier/addingStations' 
                && router.pathname !== '/carrier/stationTable'
                && router.pathname !== '/carrier/stationEdit'
                && 

            <Header style={{padding: '0',}}>
                <OurHeader/>
            </Header>}
            <Layout>
                <Content style={{ padding: '0 0', backgroundColor: '#d0e5c7'}}>
                    <div style={{paddingTop: 0, minHeight: 380 }}>
                        <Component {...pageProps} />
                    </div>
                </Content>
            </Layout>
        </Provider>
  ) }