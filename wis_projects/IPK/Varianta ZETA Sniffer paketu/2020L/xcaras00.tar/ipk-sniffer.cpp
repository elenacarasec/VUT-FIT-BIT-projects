/**
 * @file ipk-sniffer.cpp
 * @author Elena Carasec (xcaras00@stud.fit.vutbr.cz)
 * @brief Packets' sniffer.
 * @date 2021-04-25
 * 
 */

#include <getopt.h>
#include <signal.h>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdlib>
#include <pcap/pcap.h>
#include <linux/if_ether.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>

using namespace std;

pcap_t *handle;
pcap_if_t *ifcs;

/**
 * @brief Structure for filtering flags.
 */
struct packets_to_parse {
    bool tcp;
    bool udp;
    bool arp;
    bool icmp;
};

/**
 * @brief Structure to be filled in with user arguments.
 */
struct arguments_info {
    string ifc;                     // interface name
    int port;                       // port number
    int pkts_num;                   // number of packets to be examined
    packets_to_parse pkts_allowed;  // allowed packets' types 
};

/**
 * @brief Print packet symbols in hex and in char.
 * 
 * @param pkt   Pointer to packet.
 * @param len   Packet length.
 */
void print_pkt(const u_char *pkt, int len)
{
    unsigned int line_num = 0x0000;
    printf("0x%04X:", line_num);
    for(int i = 0; i < len; i++) {
        if( i != 0 && i % 16 == 0) {
            cout << "         ";
            
            for(int j = i - 16; j < i; j++){
                if(pkt[j] >= 32 && pkt[j] <= 126) {
                    cout << static_cast<unsigned char>(pkt[j]); 
                }
                else{
                    cout << ".";
                }
            }
            cout << endl;
            line_num += 16;
            cout << "0x" << hex << setfill('0') << setw(4) << line_num << dec << ":";
        }
    
        if (i % 16 == 0) printf("   ");
            cout << " " << hex << setfill('0') << setw(2) << static_cast<unsigned int>(pkt[i]) << dec;
                    
        if(i == len - 1) {
            for(int j = 0; j < 15 - i % 16; j++){
                cout << "   ";
            }                
            cout << "         ";

            for(int j = i - i % 16; j <= i; j++){
                if(pkt[j] >= 32 && pkt[j] <= 126){
                    cout << pkt[j];
                }
                else{
                    cout << ".";
                }
            }
            cout << endl;
        }
    }
    cout << endl << endl;
}

/**
 * @brief Callback function for pcap_loop().
 * Print timestamp, source and destination addresses.
 * 
 * @param hdr   Packet header pointer.
 * @param pkt   Pointer to packet
 */
void print_packet_info(u_char *args, const struct pcap_pkthdr *hdr, const u_char *pkt) {
    struct tm *nowtm;
    char tmbuf[64], buf[128];

    (void)args; 
    memset(tmbuf, 0, 64);
    nowtm = localtime(&hdr->ts.tv_sec);
    strftime(tmbuf, sizeof(tmbuf) , "%Y-%m-%dT%T%z", nowtm);
    char thisbuf[20];
    char tzbuf[6];

    for (int i = 0; i < 19; i++) {
        thisbuf[i] = tmbuf[i];
    }
    thisbuf[19] = '\0';

    for (int i = 0; i < 5; i++) {
        tzbuf[i] = tmbuf[i + 19];
    }
    tzbuf[5] = '\0';

    char timezonebuf[7];
    timezonebuf[0] = tzbuf[0];
    timezonebuf[1] = tzbuf[1];
    timezonebuf[2] = tzbuf[2];
    timezonebuf[3] = ':';
    timezonebuf[4] = tzbuf[3];
    timezonebuf[5] = tzbuf[4];
    timezonebuf[6] = '\0';
    snprintf(buf, sizeof(buf), "%s.%03ld%s ", thisbuf, hdr->ts.tv_usec / 1000, timezonebuf);

    char src_ip[INET_ADDRSTRLEN];
    char dst_ip[INET_ADDRSTRLEN];
    char src_ip6[INET6_ADDRSTRLEN], dst_ip6[INET6_ADDRSTRLEN];
    struct ethhdr *eth_hdr = (struct ethhdr *)pkt;
    int src_port, dst_port;
    uint16_t proto = ntohs(eth_hdr->h_proto);
    if (proto == ETH_P_ARP) {
        uint8_t src_mac[ETH_ALEN], dst_mac[ETH_ALEN];
        memcpy(src_mac, eth_hdr->h_source, sizeof(src_mac));
        memcpy(dst_mac, eth_hdr->h_dest, sizeof(dst_mac));
        cout << buf;
        printf("%02X:%02X:%02X:%02X:%02X:%02X > ", src_mac[0], src_mac[1], src_mac[2], src_mac[3], src_mac[4], src_mac[5]);
        printf("%02X:%02X:%02X:%02X:%02X:%02X", dst_mac[0], dst_mac[1], dst_mac[2], dst_mac[3], dst_mac[4], dst_mac[5]);
        cout << ", length: " << hdr->len << " bytes" << endl << endl;
        print_pkt(pkt, hdr->len);
    }
    else if (proto == ETH_P_IP) {
        struct ip *ipv4_hdr = (struct ip *)(pkt + sizeof(struct ethhdr));
        inet_ntop(AF_INET, &ipv4_hdr->ip_src, src_ip, INET_ADDRSTRLEN);
        inet_ntop(AF_INET, &ipv4_hdr->ip_dst, dst_ip, INET_ADDRSTRLEN);
        int ipv4_len = 4 * ipv4_hdr->ip_hl;
        if (ipv4_hdr->ip_p == IPPROTO_TCP) {
            struct tcphdr *tcp_hdr = (struct tcphdr *)(pkt + sizeof(struct ethhdr) + ipv4_len);
            src_port = ntohs(tcp_hdr->th_sport);
            dst_port = ntohs(tcp_hdr->th_dport);
            cout << buf << src_ip << ":" << src_port << " > " << dst_ip << ":" << dst_port << ", length: " << hdr->len << " bytes" << endl << endl;
        }
        else if (ipv4_hdr->ip_p == IPPROTO_UDP) {
            struct udphdr *udp_hdr = (struct udphdr *)(pkt + sizeof(struct ethhdr) + ipv4_len);
            src_port = ntohs(udp_hdr->uh_sport);
            dst_port = ntohs(udp_hdr->uh_dport);
            cout << buf << src_ip << ":" << src_port << " > " << dst_ip << ":" << dst_port << ", length: " << hdr->len << " bytes" << endl << endl;
        }
        else if (ipv4_hdr->ip_p == IPPROTO_ICMP) {
            cout << buf << src_ip << " > " << dst_ip << ", length: " << hdr->len << " bytes" << endl << endl;
        }
        print_pkt(pkt, hdr->len);
    }
    else if (proto == ETH_P_IPV6) {
        // https://sites.uclouvain.be/SystInfo/usr/include/netinet/ip6.h.html
        struct ip6_hdr *ipv6_hdr = (struct ip6_hdr *)(pkt + sizeof(struct ethhdr));
        inet_ntop(AF_INET6, &ipv6_hdr->ip6_src, src_ip6, INET6_ADDRSTRLEN);
        inet_ntop(AF_INET6, &ipv6_hdr->ip6_dst, dst_ip6, INET6_ADDRSTRLEN);

        if (ipv6_hdr->ip6_nxt == IPPROTO_TCP) {
            struct tcphdr *tcp_hdr = (struct tcphdr *)(pkt + sizeof(struct ethhdr) + sizeof(struct ip6_hdr));
            src_port = ntohs(tcp_hdr->th_sport);
            dst_port = ntohs(tcp_hdr->th_dport);
            cout << buf << src_ip6 << " : " << src_port << " > " << dst_ip6 << " : " << dst_port << ", length: " << hdr->len << " bytes" << endl << endl;
        }
        else if (ipv6_hdr->ip6_nxt == IPPROTO_UDP) {
            struct udphdr *udp_hdr = (struct udphdr *)(pkt + sizeof(struct ethhdr) + sizeof(struct ip6_hdr));
            src_port = ntohs(udp_hdr->uh_sport);
            dst_port = ntohs(udp_hdr->uh_dport);
            cout << buf << src_ip6 << " : " << src_port << " > " << dst_ip6 << " : " << dst_port << ", length: " << hdr->len << " bytes" << endl << endl;
        }
        else if (ipv6_hdr->ip6_nxt == IPPROTO_ICMPV6) {
            cout << buf << src_ip6 << " > " << dst_ip6 << ", length: " << hdr->len << " bytes" << endl << endl;
        }
        print_pkt(pkt, hdr->len);
    }
    else {
        cout << "Unknown type of packet:" << eth_hdr->h_proto << endl;
    }
}

/**
 * @brief Prepare sniffer.
 * https://www.tcpdump.org/pcap.html?fbclid=IwAR3k6xLpryyqbpE6_BJMnWQvuCLQvsqot15-I-TQLaRvw82pN_it_0FUee0
 * 
 * @param pkts_num  // Number of packets to examine
 * @param dev_name  // Name of interface
 * @param filter    // Pcap filter
 * @return 0 on success, otherwise 1.
 */
int sniff_packets(int pkts_num, char *dev_name, string filter) {
    char errbuf[PCAP_ERRBUF_SIZE];
    struct bpf_program fp;		/* The compiled filter expression */
	bpf_u_int32 mask;		/* The netmask of our sniffing device */
	bpf_u_int32 net;		/* The IP of our sniffing device */
	u_char *packet = nullptr;		/* The actual packet */

	if (pcap_lookupnet(dev_name, &net, &mask, errbuf) == -1) {
		fprintf(stderr, "Can't get netmask for device %s\n", dev_name);
		net = 0;
		mask = 0;
	}

	handle = pcap_open_live(dev_name, BUFSIZ, 1, 1000, errbuf);
    if (handle == NULL) {
		cerr << "Couldn't open device \n" << dev_name << " " << errbuf << endl;
        return 1;
	}

    if (pcap_datalink(handle) != DLT_EN10MB) {
		cerr << "Device " << dev_name << "doesn't provide Ethernet headers - not supported\n" << endl;
		return 1;
	}

    if (pcap_compile(handle, &fp, filter.c_str(), 0, net) == -1) {
		cerr << "Couldn't parse filter " << filter << ": " << pcap_geterr(handle);
		return 1;
	}

	if (pcap_setfilter(handle, &fp) == -1) {
		cerr << "Couldn't install filter " << filter <<": " << pcap_geterr(handle);
		return 1;
	}

    if (!pcap_loop(handle, pkts_num, print_packet_info, packet)) {
        cerr << pcap_geterr(handle) << endl;
    }

	pcap_close(handle);
	return(0);
}

/**
 * @brief Find available interfaces.
 * https://www.tcpdump.org/manpages/pcap_findalldevs.3pcap.html
 * 
 * @return pcap_if_t* List of interfaces
 */
pcap_if_t *find_interfaces() {
    char errbuf[PCAP_ERRBUF_SIZE];
    pcap_if_t *alldevsp;
    if (pcap_findalldevs(&alldevsp, errbuf) == PCAP_ERROR) {
        cerr << "Error: no interfaces found" << endl;
        exit(PCAP_ERROR);
    }
    return alldevsp;
}

/**
 * @brief Print list of available interfaces.
 * 
 * @param ifcs  List of interfaces
 */
void print_interfaces(pcap_if_t *ifcs) {
    pcap_if_t *tmp;
    for(tmp = ifcs; tmp; tmp = tmp->next)
        cout << tmp->name << endl;

}

/**
 * @brief Check if the interface is in the list.
 * 
 * @param ifcs          List of iterfaces
 * @param ifc           Interface name
 * @return pcap_if_t*   
 */
pcap_if_t *find_device(pcap_if_t *ifcs, string ifc) {
    pcap_if_t *tmp;
    for(tmp = ifcs; tmp; tmp = tmp->next) {
        if (tmp->name == ifc)
            return tmp;
    }
    return nullptr;
}

/**
 * @brief Create a filter based on input arguments.
 * 
 * @param info      Structure with user arguments
 * @return string   Filter
 */
string create_filter(struct arguments_info *info) {
    string filter = "(";
    if (info->pkts_allowed.tcp)
        filter = filter + "tcp ";

    if (info->pkts_allowed.udp) {
        if (filter != "(")
            filter = filter + "or ";
        filter = filter + "udp ";
    }
        
    if (info->pkts_allowed.arp) {
        if (filter != "(")
            filter = filter + "or ";
        filter = filter + "arp ";
    }

    if (info->pkts_allowed.icmp) {
        if (filter != "(")
            filter = filter + "or ";
        filter = filter + "icmp ";
    }

    filter = filter + ")";
    if (info->port > -1) {
        filter = filter + " and port " + to_string(info->port);
    }

    return filter;
}

/**
 * @brief Parse incoming arguments.
 * 
 * @return string  Filter
 */
string parse_arguments(int argc, char **argv, struct arguments_info *info) {
    static struct option long_options[] = {
        {"interface", optional_argument, 0, 'i'},
        {"tcp", no_argument, 0, 't'},
        {"udp", no_argument, 0, 'u'},
        {"arp", no_argument, 0, 0},
        {"icmp", no_argument, 0, 0},
        {0, 0, 0, 0}
    };

    int option_index = 0;
    int getoption = 0;
    while ((getoption = getopt_long(argc, argv, "i::p:tun:", long_options, &option_index)) != -1) {
        if (getoption < 0) {
            cerr << "getopt_long() has failed" << endl;
            exit(EXIT_FAILURE);
        }
        char *endptr = nullptr;
        switch (getoption) {
            case 0:
                if (!strcmp(long_options[option_index].name, "arp")) {
                    info->pkts_allowed.arp = true;
                }
                else if (!strcmp(long_options[option_index].name, "icmp")) {
                    info->pkts_allowed.icmp = true;
                }
                break;
            case 'i':
                if (argv[optind]) {
                    if (argv[optind][0] != '-') {
                        info->ifc = argv[optind];
                    }
                }
                break;
            case 'p':
                info->port = strtol(optarg, &endptr, 10);
                if (*endptr) {
                    cerr << endptr;
                    cerr << "-p option = " << optarg << " but argument should be a number" << endl;
                    exit(EXIT_FAILURE);
                }
                break;
            case 'u':
                info->pkts_allowed.udp = true;
                break;
            case 't':
                info->pkts_allowed.tcp = true;
                break;
            case 'n':
                info->pkts_num = strtol(optarg, &endptr, 10);
                if (*endptr) {
                    cerr << "-n option = " << optarg << " but argument should be a number" << endl;
                    exit(EXIT_FAILURE);
                }
                break;
            case '?':
                exit(EXIT_FAILURE);
            default:
                cerr << "unknown argument" << optarg << endl;
                break;
        }

    }

    if (optind < argc) {
        while (optind < argc) {
            if (argv[optind] != info->ifc) {
                cerr << "Unexpected argument:" << argv[optind] << endl;
                exit(EXIT_FAILURE);
            }
            optind++;
        }
    }

    if (info->pkts_allowed.arp == false && info->pkts_allowed.icmp == false
            && info->pkts_allowed.tcp == false && info->pkts_allowed.udp == false) {
        info->pkts_allowed.arp = true;
        info->pkts_allowed.icmp = true;
        info->pkts_allowed.tcp = true;
        info->pkts_allowed.udp = true;
    }

    return create_filter(info);
}

/**
 * @brief Signal handler
 * 
 * @param sig   Signal code.
 */
void signal_catched(int sig)
{
    (void)sig;
    pcap_close(handle);
    pcap_freealldevs(ifcs);
    exit(0);
}

/**
 * @brief Main function.
 * 
 * @return int  Exit code.
 */
int main(int argc, char *argv[]) {
    struct packets_to_parse pkts_allowed = {false, false, false, false};
    struct arguments_info arg_info = {"", -1, 1, pkts_allowed};
    string filter = parse_arguments(argc, argv, &arg_info);

    ifcs = find_interfaces();
    pcap_if_t *dev = nullptr;
    if (arg_info.ifc == "") {
        print_interfaces(ifcs);
        pcap_freealldevs(ifcs);
        return 0;
    }
    else {
        dev = find_device(ifcs, arg_info.ifc);
        if (dev == nullptr) {
            cerr << "Interface " << arg_info.ifc << " was not found" << endl;
        }
        signal(SIGINT, signal_catched);
        signal(SIGTERM, signal_catched);
        signal(SIGQUIT, signal_catched);
        sniff_packets(arg_info.pkts_num, dev->name, filter);
    }

    pcap_freealldevs(ifcs);

    return 0;
}