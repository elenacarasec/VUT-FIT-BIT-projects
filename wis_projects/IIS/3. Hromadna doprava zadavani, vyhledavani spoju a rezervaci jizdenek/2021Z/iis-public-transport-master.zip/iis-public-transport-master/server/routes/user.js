const Router = require('express')
const router = new Router()
const user_controller = require('../controllers/user')
const auth_middleware = require('../middleware/auth_middleware')
const role_middleware = require('../middleware/role_middleware')


router.post('/registration', user_controller.registration)
router.post('/login', user_controller.login)
router.post('/user_update', user_controller.user_update)
router.post('/get_user', user_controller.get_user)
router.post('/user_delite', user_controller.user_delite)
router.post('/get_user', user_controller.get_user)
router.post('/get_staff', role_middleware(['CARRIER']), user_controller.get_staff)
router.post('/list_staff', user_controller.list_staff)
router.get('/auth', user_controller.auth_check)
router.get('/list_all', user_controller.list_all)

module.exports = router