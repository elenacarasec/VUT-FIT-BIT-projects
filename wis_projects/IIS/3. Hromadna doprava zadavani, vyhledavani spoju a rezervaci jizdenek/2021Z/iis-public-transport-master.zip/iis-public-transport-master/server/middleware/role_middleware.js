const jwt = require('jsonwebtoken')

module.exports = function(role) {
    return function (req, res, next) {
        if (req.method === "OPTIONS") {
            next()
        }
        try {
            const token = req.headers.authorization.split(' ')[1]
            if (!token) {
                return res.status(401).json({message: "user is not authorized"})
            }
            const decoded = jwt.verify(token, process.env.SECRET_KEY)
            console.log('-------------------------')
            console.log(decoded)
            console.log('-------------------------')
            var has_access = 0
            console.log(role)
            role.forEach(element => {
                if (decoded.role === element) {
                        has_access+=1
                    }
            });
            
            if (has_access === 0) {
                return res.status(403).json({message: "No access"})
            }
            console.log('---- ------------------ ----')
            console.log('---- SUCCEED ROLE CHECK ----')
            console.log('---- ------------------ ----')
            req.user = decoded;
            next()
        } catch (e) {
            res.status(401).json({message: "user is not authorized"})
        }
    };
}