import React from "react";
import moment from 'moment';
import axios from 'axios';
import Router from 'next/router';

import Result from "../../findRouteResults/results";

import {Button, Form, Input, Select} from 'antd'; 
import {LoadingOutlined} from '@ant-design/icons';

import { DatePicker } from 'antd';
import {PlusOutlined, MinusCircleOutlined} from '@ant-design/icons';
const {Option} = Select;


import styles from '/styles/forms.module.scss'
export default class FindRoute extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            stations: 'loading',
            result: null
        }
    }

    componentDidMount = () => {
       
            axios({
            method: "get",
            url: "https://iis-public-transport.herokuapp.com/api/station/list_all",
                })
                .then(res => {
                    this.setState({stations: res.data})
                })
                .catch(err => message.info('No stations found'))
    }

    disabledDate(current) {
        // Can not select days before today and today
        return current && current < moment().startOf('day');
    }

    handleFinish = (data) => {
        if (data.date) data.date = moment(data.date).format("YYYY-MM-DD")
        
        this.setState({station_from: data.station_from, station_to: data.station_to})
        console.log("state", this.state)

        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/ride/search",
            data: data
        })
        .then(
        res => {
            console.log("result", res.data)
            this.setState({result: res.data});
            
        })
        .catch(err => {
            this.setState({result: []});
        })
    }

    render() {
        return (
            <>
                <Form onFinish={this.handleFinish} className={styles.forms} style={{marginBottom: '2em'}}
                            scrollToFirstError='True' >
                          {this.state.stations === 'loading' ?
                            <div align='center'>
                                <LoadingOutlined style={{fontSize: '2em'}}/>
                            </div>
                            :
                            <Form.Item name="station_from" style={{ width: '100%'}}>
                                <Select placeholder={'From'} required optionFilterProp="children" size='large'>
                                    {this.state.stations.map((el, key) => {
                                        return (
                                            <Option key={key+"P"} value={el.id}>{el.city  + ' ' + el.label}</Option>
                                        )
                                    })}
                                </Select>
                            </Form.Item>
                            }
                            {this.state.stations === 'loading' ?
                            <div align='center'>
                                <LoadingOutlined style={{fontSize: '2em'}}/>
                            </div>
                            :
                            <Form.Item name="station_to" style={{ width: '100%'}}>
                                <Select placeholder={'To'} required optionFilterProp="children" size='large'>
                                    {this.state.stations.map((el, key) => {
                                        return (
                                            <Option key={key+"Z"} value={el.id}>{el.city  + ' ' + el.label}</Option>
                                        )
                                    })}
                                </Select>
                            </Form.Item>
                            }
                    <Form.Item name="date">       
                        <DatePicker
                            rules={[{ required: true, message: 'Choose a date' }]}
                            placeholder='Departure'className={styles.forms} size='large'
                            style={{paddingTop: 10,paddingBottom: 10, fontSize:20}} disabledDate={this.disabledDate}/>        
                    </Form.Item>
                    
                    <Form.List name="passengers">
                        {(fields, { add, remove }) => (
                        <>
                        {fields.map(({ key, name, fieldKey, ...restField }) => (

                        <div key={key} style={{ display: 'block', marginBottom: 8, position: 'relative' }} align="baseline">
                            <Form.Item
                                {...restField}
                                name={'ticketType'}
                                rules={[{ required: true, message: 'Choose type of ticket' }]}
                                style={{ width: '80%', display: 'inline-block'}}>
                                    <Select showSearch size='large' placeholder={
                                        <span>
                                            Passengers
                                        </span>} 
                                    style={{padding: 0}}
                                    className={styles.forms}
                                    optionFilterProp="children">
                                        <Option value="1">Adult 18-64 years</Option>
                                        <Option value="2">Child &gt; 6 years</Option>
                                        <Option value="3">Children 6-18 years</Option>
                                        <Option value="4">Student &lt; 26(ISIC)</Option>
                                        <Option value="5">Senior &gt; 65 years</Option>
                                        <Option value="6">ZTP</Option>
                                        <Option value="7">Guide of ZTP </Option>
                                    </Select>
                            </Form.Item>
                            {fields.length > 1 &&
                            <MinusCircleOutlined style={{position: 'absolute', right: '0', top: '7%',  fontSize: '2.2em'}} onClick={() => remove(name)} />}
                        </div>
                        ))}

                        <Form.Item>
                            <Button type="dashed" disabled={fields.length >= 4} onClick={() => {fields.length < 4 ? add() : null}} block icon={<PlusOutlined />}>
                                Add Passenger
                            </Button>
                        </Form.Item>
                        </>
                        )}
                    </Form.List>

                    
                    <Form.Item>
                    <div align='center'>
                            <Button type='primary' size='large' htmlType='submit' className={styles.button}> SEARCH </Button>
                    </div>
                    </Form.Item>
                </Form>
                
                
                {this.state.result !== null && 
                    (this.state.result.length > 0 ?
                    (this.state.result.map((el, idx) => {
                        return (
                            <div key={idx + JSON.stringify(el.route)}>
                                <Result route={el} station_to={this.state.station_to} station_from={this.state.station_from}/>
                            </div> 
                        )
                    }))
                    :
                    <div align='center' style={{fontSize: '2em'}}>
                        Nothing was found :(
                    </div>)
                }
                                
            </>
        )
    }
}
