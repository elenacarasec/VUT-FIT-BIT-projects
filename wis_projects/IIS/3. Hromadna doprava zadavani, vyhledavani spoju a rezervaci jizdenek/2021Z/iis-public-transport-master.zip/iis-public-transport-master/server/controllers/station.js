const ApiError = require('../error/api_error')
const {Station} = require('../models/models')

class StationController {
    async add_new(req, res, next) {
        const {label, city, longtitude, latitude, proposed} = req.body
        if (!label || !city || !longtitude || !latitude || !proposed) {
            return next(ApiError.bad_request('required station info was not found'))
        }        
        const candidate = await Station.findOne({where: {longtitude, latitude}})
        if (candidate) {
            return next(ApiError.bad_request('station already exists'))
        }
        
        console.log(label, city, longtitude, latitude, proposed)
        const station = await Station.create({label, city, longtitude, latitude, proposed})
        return res.json(station)
    }

    async update(req, res, next) {
        const {id, label, city, longtitude, latitude, proposed} = req.body

        if (!id || !label || !city || !longtitude || !latitude || !proposed) {
            return next(ApiError.bad_request('required station info was not found'))
        }        
        const candidate = await Station.findOne({where: {id : id}})
        if (!candidate) {
            return next(ApiError.bad_request('station does not exists'))
        }
        const station = await Station.update({label, city, longtitude, latitude, proposed}, {where: {id:id}})
        return res.json(station)
    }

    async approve(req, res, next) {
        const {id} = req.body
        if (!id) {
            return next(ApiError.bad_request('required data for approve was not found'))
        }
        const candidate = await Station.findOne({where: {id : id}})
        if (!candidate) {
            return next(ApiError.bad_request('station does not exists unexpectedly'))
        }        
        const candidate_updated = await Station.update({approved:1}, {where: {id : id}})
        return res.json(candidate)
    }

    async delite(req, res, next) {
        const {id} = req.body
        if (!id) {
            return next(ApiError.bad_request('required data for approve was not found'))
        }
        const candidate = await Station.findOne({where: {id : id}})
        if (!candidate) {
            return next(ApiError.bad_request('station does not exists'))
        }        
        const candidate_delited = await Station.destroy({where: {id : id}})
        return res.json(candidate)
    }

    async get_station(req, res, next) {
        const {id} = req.body
        if (!id) {
            return next(ApiError.bad_request('required data for station was not found'))
        }
        const candidate = await Station.findOne({where: {id}})
        if (!candidate) {
            return next(ApiError.bad_request('station does not exists'))
        }        
        return res.json(candidate)
    }

    async list_proposed(req, res, next) {
        const candidates = await Station.findAll({where: {proposed: 1, approved: 0}})
        return res.json(candidates)
    }

    async list_all(req, res, next) {
        const candidates = await Station.findAll()
        console.log(candidates)
        return res.json(candidates)
    }
}

module.exports = new StationController()