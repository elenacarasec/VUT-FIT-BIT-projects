const ApiError = require('../error/api_error')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const {User} = require('../models/models')
const {json} = require('sequelize/dist')

const generate_jwt = (id, email, role) => {
    return jwt.sign(
        {id, email, role},
        process.env.SECRET_KEY,
        {expiresIn: '24h'}
    )
}

class UserController {
    async registration(req, res, next) {
        const {role, email, name, phone_number, password, company, age} = req.body
        if (!email || !password) {
            console.log(role, email, name, phone_number, password)
            return next(ApiError.bad_request('invalid username or password'))
        }
        
        const candidate = await User.findOne({where: {email}})
        if (candidate) {
            return next(ApiError.not_acceptable('user already exists'))
        }

        const hash_passwd = await bcrypt.hash(password, 3)
        const user = await User.create({role, email, name, phone_number, password:hash_passwd, company, age})
        const token = generate_jwt(user.id, user.email, user.role)
        return res.json(token)
    }

    async login(req, res, next) {
        const {email, password} = req.body
        const user = await User.findOne({where:{email}})
        if (!user) {
            return next(ApiError.bad_request('user does not exists'))
        }
        
        const compare_password = bcrypt.compareSync(password, user.password)
        if (!compare_password) {
            return next(ApiError.bad_request('wrong password or username'))
        }
        const token = generate_jwt(user.id, user.email, user.role)
        return res.json(token)
    }

    async user_update(req, res, next) {
        const {id, email, name, phone_number} = req.body
        const user_to_change = await User.findOne({where: {id}})
        if (!user_to_change) {
            return next(ApiError.bad_request('requiered user does not exist'))
        }
        const change = await User.update({email, name, phone_number}, {where: {id : user_to_change.id}})
        return res.json(change)
    }
    
    async user_delite(req, res, next) {
        const {id} = req.body
        const user_to_change = await User.findOne({where: {id}})
        if (!user_to_change) {
            return next(ApiError.bad_request('requiered user does not exist'))
        }
        const change = await User.destroy({where: {id : user_to_change.id}})
        return res.json(change)
    }

    async get_user(req, res, next) {
        const {email} = req.body
        if (!email) {
            console.log(email)
            return next(ApiError.bad_request('there is no email param'))
        }
        const candidate = await User.findOne({where: {email}})
        if (!candidate) {
            return next(ApiError.bad_request('user with that email does not exists'))
        }
        return res.json(candidate)
    }
    
    async list_staff(req, res, next) {
        const {role} = req.body
        const staff = await User.findAll({where: {role}})
        return res.json(staff)
    }

    async list_all(req, res, next) {
        const staff = await User.findAll()
        return res.json(staff)
    }

    async auth_check(req, res, next) {
        const token = generate_jwt(req.user.id, req.user.email, req.user.role)
        return res.json({token})
    }

    async get_staff(req, res, next) {
        const {email} = req.body
        const staff_editing = await User.findOne({where: {id:req.user.id}})
        if (!staff_editing) {
            return next(ApiError.bad_request('could not load carrier user data'))
        }
        const staff = await User.findOne({where: {role: 'STAFF', company: staff_editing.company, email: email}})
        if (!staff) {
            return next(ApiError.bad_request('requested staff user was not found or you don not have enough rights'))
        }
        return res.json(staff)
    }
}

module.exports = new UserController()