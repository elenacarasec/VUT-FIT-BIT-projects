<?php
//
// Author: Elena Carasec (xcaras00)
// Date: 2021.03.09
//

function xml_prohibited_symbols($arg) {
    return str_replace(
        array("&", "<", ">", '"', "'"),
        array("&amp;", "&lt;", "&gt;", "&quot;", "&apos;"), 
        $arg);
}

function print_xml_element($xml, $arg_type, $arg_num, $arg) {
    xmlwriter_start_element($xml, 'arg'.$arg_num);
    xmlwriter_start_attribute($xml, 'type');
    xmlwriter_text($xml, $arg_type);
    xmlwriter_end_attribute($xml);
    xmlwriter_write_raw($xml, xml_prohibited_symbols($arg));
    xmlwriter_end_element($xml);
}

function check_header($xml) {
    $header = "/\.IPPcode21/i";
    $header_presents = FALSE;
    while($line_preview = fgets(STDIN)) {
        $line_pre = explode ("#", $line_preview, 2);
        $line = preg_split("/\s+/", trim($line_pre[0], "/ \n\r\t\v\0/"));
        if ($line[0] == "") {
            continue;
        }

        if (!preg_match($header, trim($line[0], "/s+/"))) {
            exit(21);
        } elseif (isset($line[1])) {
            exit(21);
        }
        $header_presents = TRUE;
        xmlwriter_start_attribute($xml, 'language');
        xmlwriter_text($xml, 'IPPcode21');
        xmlwriter_end_attribute($xml);
        return;
    }
    if ($header_presents == FALSE) {
        exit(21);
    }
}

function parse_cli_args($argc, $argv, &$stats_flag) {
    $stats = FALSE;
    $too_many_stats_types = FALSE;
    $options = getopt(NULL,
        ["help"]//, "stats::", "loc", "comments", "jumps", "fwjumps", "backjumps", "badjumps"]
    );
    foreach (array_keys($options) as $opt) switch ($opt) {
        case "help":
            echo("$ \"parse.php\" - parser for IPPcode21\n");
            echo("php7.4 parse.php <filename \n\n");
            echo("--help    Prints this help.\n");
            exit(0);
            break;
        // case "stats":
        //     $stats = TRUE;
        //     break;
        // case "loc" || "comments" || "jumps" || "fwjumps" || "backjumps" || "badjumps":
        //     if ($stats == FALSE) {
        //         exit(10);
        //     }
        //     if ($too_many_stats_types) {
        //         exit(12);
        //     }
        //     $too_many_stats_types = TRUE;
        //     $stats_flag = $opt;
        //     break;
        default:
            exit(10);
    }

    if ($argc > 1) {
        exit(10);
    }
}

function main($argc, $argv) {
    $stats_flag = "";
    parse_cli_args($argc, $argv, $stats_flag);

    $stats = array(
        "comments"=>0,
        "loc"=>0,
        "labels"=>0,
        "jumps"=>0,
        "fwjumps"=>0,
        "backjumps"=>0,
        "badjumps"=>0
    );

    $labels = array();
    $jumps = array();

    $int = "int@[\-\+]?\d+";
    $bool = "bool@(true|false){1}";
    $str = "string@(\\\\[0-9]{3}|\w|[_\-\$\&%\*\!\?@\'\"\<\>])*$";
    $nil = "nil@nil";
    $spec_symb = "[_\-\$\&%\*\!\?]";
    $label = "/".$spec_symb."|[a-z]|[A-Z](".$spec_symb."|\w)*/";
    $var = "/(GF|TF|LF){1}@".trim($label, "/")."{1}/";
    $symb = "(".$int."|".$bool."|".$str."|".$nil."|(GF|TF|LF){1}@(".$spec_symb."|[a-z]|[A-Z])(".$spec_symb."|\w)*){1}";
    $type = "/^(int|string|nil|bool|float){1}$/";

    $op_w0 = "/^(CREATEFRAME|PUSHFRAME|POPFRAME|RETURN|BREAK){1}$/i";
    $op_w1_symb = "/^(PUSHS|WRITE|EXIT|DPRINT){1}$/i";
    $op_w1_var = "/^(DEFVAR|POPS){1}$/i";
    $op_w1_label = "/^(CALL|LABEL|JUMP){1}$/i";
    $op_w2_var_symb = "/^(MOVE|INT2CHAR|STRLEN|TYPE|NOT){1}$/i";
    $op_w2_var_type = "/^(READ){1}$/i";
    $op_w3_var_symb1_symb2 = "/^(ADD|SUB|MUL|IDIV|LT|GT|EQ|AND|OR|STRI2INT|CONCAT|GETCHAR|SETCHAR){1}$/i";
    $op_w3_label_symb1_symb2 = "/^(JUMPIFEQ|JUMPIFNEQ){1}$/i";

    $xml = xmlwriter_open_memory();
    xmlwriter_set_indent($xml, 1);
    $res = xmlwriter_set_indent_string($xml, '    ');
    xmlwriter_start_document($xml, '1.0', 'UTF-8');
    xmlwriter_start_element($xml, 'program');

    check_header($xml);

    $order = 0;
    $line = "";

    while($line_pre = fgets(STDIN)) {
        $line_pre = explode ("#", $line_pre, 2);
        if (isset($line_pre[1])) {
            $stats["comments"]++;
        }
        $line = preg_split("/\s+/", trim($line_pre[0], "/ \n\r\t\v\0/"));

        if ($line[0] == "") {
            continue;
        }

        $order = $order + 1;
        if (preg_match($op_w0, $line[0])) {
            if (isset($line[1])) {
                fwrite(STDERR, $line[0], "should not have arguments\n");
                exit(23);
            }
            xmlwriter_start_element($xml, 'instruction');
            xmlwriter_start_attribute($xml, 'order');
            xmlwriter_text($xml, $order);
            xmlwriter_end_attribute($xml);
            xmlwriter_start_attribute($xml, 'opcode');
            xmlwriter_text($xml, $line[0]);
            xmlwriter_end_attribute($xml);
            xmlwriter_end_element($xml);
            $stats["loc"]++;
            continue;
        }
        elseif (preg_match($op_w1_symb, $line[0])) {
            if (isset($line[1]) && preg_match('/'.$symb.'/', $line[1])) {
                if (!isset($line[2])) {
                    xmlwriter_start_element($xml, 'instruction');
                    xmlwriter_start_attribute($xml, 'order');
                    xmlwriter_text($xml, $order);
                    xmlwriter_end_attribute($xml);
                    xmlwriter_start_attribute($xml, 'opcode');
                    xmlwriter_text($xml, $line[0]);
                    xmlwriter_end_attribute($xml);
                    print_xml_element($xml, 'symb', '1', $line[1]);
                    xmlwriter_end_element($xml);
                    $stats["loc"]++;
                    continue;
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w1_var, $line[0])) {
            if (isset($line[1]) && preg_match("/(GF|TF|LF){1}@([_\-$\&%\*\!\?]|[a-z]|[A-Z])([_\-$\&%\*\!\?]|\w)*/", $line[1])) {
                if (!isset($line[2])) {
                    xmlwriter_start_element($xml, 'instruction');
                    xmlwriter_start_attribute($xml, 'order');
                    xmlwriter_text($xml, $order);
                    xmlwriter_end_attribute($xml);
                    xmlwriter_start_attribute($xml, 'opcode');
                    xmlwriter_text($xml, $line[0]);
                    xmlwriter_end_attribute($xml);
                    print_xml_element($xml, 'var', '1', $line[1]);
                    xmlwriter_end_element($xml);
                    $stats["loc"]++;
                    continue;
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w1_label, $line[0])) {
            if (isset($line[1]) && preg_match("/([_\-$\&%\*\!\?]|[a-z]|[A-Z])([_\-$\&%\*\!\?]|\w)*/", $line[1])) {
                if (!isset($line[2])) {
                    xmlwriter_start_element($xml, 'instruction');
                    xmlwriter_start_attribute($xml, 'order');
                    xmlwriter_text($xml, $order);
                    xmlwriter_end_attribute($xml);
                    xmlwriter_start_attribute($xml, 'opcode');
                    xmlwriter_text($xml, $line[0]);
                    xmlwriter_end_attribute($xml);
                    print_xml_element($xml, 'label', '1', $line[1]);
                    xmlwriter_end_element($xml);
                    $stats["loc"]++;
                    if (strtoupper($line[0]) == "LABEL") {
                        $labels[$line[1]] = $stats["loc"];
                        $stats["labels"]++;
                    }
                    elseif (strtoupper($line[0]) == "JUMP") {
                        $jumps[$stats["loc"]] = $line[1];
                        $stats["jumps"]++;
                    }
                    continue;
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w2_var_symb, $line[0])) {
            if (isset($line[1]) && preg_match("/(GF|TF|LF){1}@([_\-$\&%\*\!\?]|[a-z]|[A-Z])([_\-$\&%\*\!\?]|\w)*/", $line[1])) {
                if (isset($line[2]) && preg_match('/'.$symb.'/', $line[2])) {
                    if (!isset($line[3])) {
                        xmlwriter_start_element($xml, 'instruction');
                        xmlwriter_start_attribute($xml, 'order');
                        xmlwriter_text($xml, $order);
                        xmlwriter_end_attribute($xml);
                        xmlwriter_start_attribute($xml, 'opcode');
                        xmlwriter_text($xml, $line[0]);
                        xmlwriter_end_attribute($xml);
                        print_xml_element($xml, 'var', '1', $line[1]);
                        print_xml_element($xml, 'symb', '2', $line[2]);
                        xmlwriter_end_element($xml);
                        $stats["loc"]++;
                        continue;
                    }
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w2_var_type, $line[0])) {
            if (isset($line[1]) && preg_match("/(GF|TF|LF){1}@([_\-$\&%\*\!\?]|[a-z]|[A-Z])([_\-$\&%\*\!\?]|\w)*/", $line[1])) {
                if (isset($line[2]) && preg_match("/(int|string|bool|float){1}/", $line[2])) {
                    if (!isset($line[3])) {
                        xmlwriter_start_element($xml, 'instruction');
                        xmlwriter_start_attribute($xml, 'order');
                        xmlwriter_text($xml, $order);
                        xmlwriter_end_attribute($xml);
                        xmlwriter_start_attribute($xml, 'opcode');
                        xmlwriter_text($xml, $line[0]);
                        xmlwriter_end_attribute($xml);
                        print_xml_element($xml, 'var', '1', $line[1]);
                        print_xml_element($xml, 'type', '2', $line[2]);
                        xmlwriter_end_element($xml);
                        $stats["loc"]++;
                        continue;
                    }
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w3_var_symb1_symb2, $line[0])) {
            if (isset($line[1]) && preg_match("/([_\-$\&%\*\!\?]|[a-z]|[A-Z])([_\-$\&%\*\!\?]|\w)*/", $line[1])) {
                if (isset($line[2]) && preg_match('/'.$symb.'/', $line[2])) {
                    if (isset($line[3]) && preg_match('/'.$symb.'/', $line[3])) {
                        if (!isset($line[4])) {
                            xmlwriter_start_element($xml, 'instruction');
                            xmlwriter_start_attribute($xml, 'order');
                            xmlwriter_text($xml, $order);
                            xmlwriter_end_attribute($xml);
                            xmlwriter_start_attribute($xml, 'opcode');
                            xmlwriter_text($xml, $line[0]);
                            xmlwriter_end_attribute($xml);
                            print_xml_element($xml, 'var', '1', $line[1]);
                            print_xml_element($xml, 'symb', '2', $line[2]);
                            print_xml_element($xml, 'symb', '3', $line[3]);
                            xmlwriter_end_element($xml);
                            $stats["loc"]++;
                            continue;
                        }
                    }
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w3_label_symb1_symb2, $line[0])) {
            if (isset($line[1]) && preg_match("/([_\-$\&%\*\!\?]|[a-z]|[A-Z])([_\-$\&%\*\!\?]|\w)*/", $line[1])) {
                if (isset($line[2]) && preg_match('/'.$symb.'/', $line[2])) {
                    if (isset($line[3]) && preg_match('/'.$symb.'/', $line[3])) {
                        if (!isset($line[4])) {
                            xmlwriter_start_element($xml, 'instruction');
                            xmlwriter_start_attribute($xml, 'order');
                            xmlwriter_text($xml, $order);
                            xmlwriter_end_attribute($xml);
                            xmlwriter_start_attribute($xml, 'opcode');
                            xmlwriter_text($xml, $line[0]);
                            xmlwriter_end_attribute($xml);
                            print_xml_element($xml, 'label', '1', $line[1]);
                            print_xml_element($xml, 'symb', '2', $line[2]);
                            print_xml_element($xml, 'symb', '3', $line[3]);
                            xmlwriter_end_element($xml);
                            $stats["loc"]++;
                            $stats["jumps"]++;
                            $jumps[$stats["loc"]] = $line[1];
                            continue;
                        }
                    }
                }
            }
            exit(23);
        }
        else {
            exit(22);
        }
    }

    foreach ($jumps as $num => $label_name) {
        if (array_key_exists($label_name, $labels)) {
            if ($num < $labels[$label_name]) {
                $stats["fwjumps"]++;
            }
            else {
                $stats["backjumps"]++;
            }
        }
        else {
            $stats["badjumps"]++;
        }
    }

    xmlwriter_end_element($xml);
    xmlwriter_end_document($xml);
    echo xmlwriter_output_memory($xml);
    xmlwriter_flush($xml);
    // if ($stats_flag != "") {
    //     echo $stats[$stats_flag]."\n";
    // }
}

main($argc, $argv);
?>