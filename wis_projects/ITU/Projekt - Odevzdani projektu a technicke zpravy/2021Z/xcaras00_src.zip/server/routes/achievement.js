const Router = require('express')
const router = new Router()
const achievement_controller = require('../controllers/achievement')

router.post('/update_state', achievement_controller.update_state)
router.post('/get_user_achievments', achievement_controller.get_user_achievments)

module.exports = router