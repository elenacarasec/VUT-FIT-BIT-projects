
import React from "react";
import {Row, Col, Button, Divider, message} from 'antd'
import styles from "./results.module.sass"
import axios from 'axios';

 

export default class Results extends React.Component {
    constructor(props) {
        super(props);
        let station_from = this.props.route.route.find((el) => el.stationId === this.props.station_from)
        let station_to   = this.props.route.route.find((el) => el.stationId === this.props.station_to  )
        this.state = {
            loggedUser: null,
            station_from: station_from,
            station_to: station_to,
            is_reserved: false,
            reservation_number: null
        }
    }

    reserve = () => {
        let authToken = localStorage.getItem('authToken')
        if (authToken === null) {
            message.open({
                type: 'error',
                content: 'For creating reservations you have to log in',
                duration: 3,
                style: {marginTop: '40vh'}
            })
        } else {
            axios({
                method: "POST",
                url: "https://iis-public-transport.herokuapp.com/api/ticket/create_ticket",
                data: {
                    connectionId: this.props.route.route[0].station.connectionId,
                    station_from: this.state.station_from.station_name,
                    station_to: this.state.station_to.station_name,
                    price: this.props.route.price
                },
                headers: {
                    'Authorization': 'Bearer ' + authToken
                }
            }).then(
                res => {
                    console.log(res)
                    this.setState({reservation_number: res.data.id, is_reserved: true})
                    message.open({
                        type: 'success',
                        content: 'Reservation was successfully created',
                        duration: 3,
                        style: {marginTop: '40vh'}
                    })
                },
                err => {
                    console.log(err)
                    message.open({
                        type: 'error',
                        content: 'Something went wrong',
                        duration: 3,
                        style: {marginTop: '40vh'}
                    })
                }
            )
        }
    }
    render() {
        console.log("State: ", this.state)
        return (
            <div className={styles.resultBody}>
                <div align='center' className={styles.header}>
                    {this.props.route.route[0].station_name} - {this.props.route.route[this.props.route.route.length - 1].station_name} by {this.props.route.carrier}
                </div>
                <Divider/>
                <Row style={{marginBottom: '1em'}}>
                    <Col span={12}>
                        Departure from <span className={styles.stationName}> {this.state.station_from.station_name} </span>
                        <br/>
                        <span className={styles.time}>
                            {this.state.station_from.station.arrival_time}
                        </span>
                    </Col>

                    <Col span={12}>
                        Arrival to <span className={styles.stationName}> {this.state.station_to.station_name} </span>
                        <br/>
                        <span className={styles.time}>
                            {this.state.station_to.station.arrival_time}
                        </span>
                        
                    </Col>
                </Row>
                
                <div>
                    {!this.state.is_reserved ?
                    <Button onClick={this.reserve} type='primary' size='large'>
                        Reserve for ${this.props.route.price}
                    </Button>
                    :
                    <span style={{color: 'green'}}> Reserved </span>}
                </div>
                {this.state.reservation_number &&
                <div>
                    Reservation number: {this.state.reservation_number}
                </div>
                }

            </div>
        )
    }
}