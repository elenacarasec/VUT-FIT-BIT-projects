const Router = require('express')
const router = new Router()
const vehicle_controller = require('../controllers/vehicle')
const auth_middleware = require('../middleware/auth_middleware')
const role_middleware = require('../middleware/role_middleware')

router.post('/add_new', vehicle_controller.add_new)
router.post('/update', vehicle_controller.update)
router.post('/delite', vehicle_controller.delite)
router.get('/list_all', vehicle_controller.list_all)

module.exports = router