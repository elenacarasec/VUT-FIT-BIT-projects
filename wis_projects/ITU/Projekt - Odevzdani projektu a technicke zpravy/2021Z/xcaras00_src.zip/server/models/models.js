const sequelize = require('../db')
const {DataTypes} = require('sequelize')

const User = sequelize.define('user', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    name: {type: DataTypes.STRING},
    password: {type: DataTypes.STRING},
    email: {type: DataTypes.STRING, unique: true,},
    age: {type: DataTypes.INTEGER},
    gender: {type: DataTypes.STRING},
    points: {type: DataTypes.INTEGER},
    weight_self: {type: DataTypes.INTEGER, defaultValue: 0},
    weight_social: {type: DataTypes.INTEGER, defaultValue: 0},
    weight_relatives: {type: DataTypes.INTEGER, defaultValue: 0},
})

const UserTask = sequelize.define('user_task', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    resolved: {type: DataTypes.INTEGER, defaultValue: 0},
})

const Task = sequelize.define('task', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    header: {type: DataTypes.STRING},
    description: {type: DataTypes.STRING},
    points: {type: DataTypes.INTEGER},
    weight_self: {type: DataTypes.INTEGER},
    weight_social: {type: DataTypes.INTEGER},
    weight_relatives: {type: DataTypes.INTEGER},
    category: {type: DataTypes.INTEGER},
})

const UserAchievement = sequelize.define('user_achievement', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    has: {type: DataTypes.BOOLEAN, defaultValue: false},
})

const Achievement = sequelize.define('achievement', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    header: {type: DataTypes.STRING},
    description: {type: DataTypes.STRING},
    points: {type: DataTypes.INTEGER},
})

User.hasMany(UserTask)
UserTask.belongsTo(User)

Task.hasMany(UserTask)
UserTask.belongsTo(Task)

User.hasMany(UserAchievement)
UserAchievement.belongsTo(User)

Achievement.hasMany(UserAchievement)
UserAchievement.belongsTo(Achievement)

module.exports = {
    User,
    UserTask,
    Task,
    Achievement,
    UserAchievement,
}