import React, {useState} from "react";
import {connect} from "react-redux";
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, Input, Select, Button, message} from 'antd';
import CarrierHeader from '../../components/header/carrier_header';
import AdminHeader from '../../components/header/forms/adminHeader'
const { Option } = Select;

import styles from '../../styles/index.module.scss';

import Router from 'next/router';
import axios from 'axios';

import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";


class CarrierPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userToken: null,
            loggedUser: "loading",
            connections: 'loading'
        }
        axios({
            method: "get",
            url: "https://iis-public-transport.herokuapp.com/api/connection/list_all",
        })
        .then(res => {
            this.setState({connections: res.data.map(el => el.id)})
        })
        .catch(err => message.info('No vehicles found'))
    }

    componentDidMount = () => {
    
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user})
        }
    }
    
    handleFinish = (data) => {
        console.log(data)
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/vehicle/add_new",
            data: data
        })
        .then(res => 
                Router.push('/carrier/vehicle')
            )
        .catch(err => console.log(err));
    }

    render() {
        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && (this.state.loggedUser.role === 'CARRIER' || this.state.loggedUser.role === 'ADMIN')) {
        return (
            <div>
		        <Header style={{padding: '0',}}>
                    {this.state.loggedUser.role === 'CARRIER' ?
                     <CarrierHeader/>
                     : <AdminHeader/>
                  } 
		        </Header>  
                <Row align='center' style={{marginTop: '128px'}}>
                  
                    <Col align='center' xs={22} sm={11} md={10} lg={7} xl={6} xxl={6}>
                        <Form onFinish={this.handleFinish}
                            scrollToFirstError='True'
                            className={styles.forms} >
                            {this.state.connections === 'loading' ?
                            <div align='center'>
                                <LoadingOutlined style={{fontSize: '2em'}}/>
                            </div>
                            :
                            <Form.Item name="connectionId" align='left'>
                                <Select placeholder={'Connection ID'} align='left' required optionFilterProp="children" size='large'>
                                    {this.state.connections.map(el => {
                                        return (
                                            <Option key={el} value={el}>{el}</Option>
                                        )
                                    })}
                                </Select>
                            </Form.Item>
                            }
                            <Form.Item name="model">
                                <Input placeholder='Model' required
                                    className={styles.forms}
                                    size='large'/>                      
                            </Form.Item>
                            <Form.Item name="description">
                                <Input placeholder='Description' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="license_plate">
                                <Input placeholder='License plate' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="number">
                                <Input placeholder='Number' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="number_of_seats">
                                <Input placeholder='Number of seats' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item>
                            <div align='center'>
                                <Button type='primary' size='large' htmlType='submit' className={styles.buttonLog}> Add </Button>
                            </div>
                            </Form.Item>
                            </Form>
                    </Col>
                </Row> 

            </div>
        )}
        else if ((this.state.loggedUser && (this.state.loggedUser.role !== 'CARRIER' && this.state.loggedUser.role !== 'ADMIN'))) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (CarrierPage);
