import React from "react";
import {Row, Col, Anchor, Button} from 'antd';
import styles from './header.module.scss'
import  Router from "next/router";


export default class StaffHeader extends React.Component {
	handleLogout = () => {
        localStorage.removeItem('authToken')
        Router.push('/')
    }
    render() {
        return (   
            <Row align='center' gutter={[0, 5]} style={{ position: "relative"}}>
				<Col align='center' onClick={() => {Router.push('/')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={6} xs={24}>
					HOME 
				</Col>
				<Col align='center' className={styles.headerButtonsCol + ' ' + styles.liningElement} onClick={() => {Router.push('/staff/ticketsList')}} sm={6} xs={24}>
					TICKETS
				</Col>
				<Col align='center' className={styles.headerButtonsCol + ' ' + styles.liningElement} onClick={() => {Router.push('/location/connectionLocation')}} sm={6} xs={24}>
					CONNECTIONS
				</Col>
				<Col onClick={this.handleLogout} align='center' className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={6} xs={24}>
					LOGOUT
				</Col>
            </Row>
        )
    }
}




