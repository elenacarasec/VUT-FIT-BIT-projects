#include <getopt.h>
#include <stddef.h>
#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <unistd.h>

using namespace std;

#define BUFSIZE 1024

/**
 * @brief Command line arguments.
 * 
 */
struct CLI {
    string login;
    string password;
    string recipient;
    string subject;
    string body;
    string id;
    string command;
};

/*
* Base64 encoding/decoding (RFC1341)
* Copyright (c) 2005-2011, Jouni Malinen <j@w1.fi>
*
* This software may be distributed under the terms of the BSD license.
* See README for more details.
*/

// 2016-12-12 - Gaspard Petit : Slightly modified to return a std::string 
// instead of a buffer allocated with malloc.
static const unsigned char base64_table[65] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/**
* @brief base64_encode - Base64 encode
* @src: Data to be encoded
* @len: Length of the data to be encoded
* @out_len: Pointer to output length variable, or %NULL if not used
* Returns: Allocated buffer of out_len bytes of encoded data,
* or empty string on failure
*
* https://stackoverflow.com/questions/342409/how-do-i-base64-encode-decode-in-c
*/
string base64_encode(const unsigned char *src, size_t len)
{
    unsigned char *out, *pos;
    const unsigned char *end, *in;

    size_t olen;

    olen = 4*((len + 2) / 3); /* 3-byte blocks to 4-byte */

    if (olen < len)
        return std::string(); /* integer overflow */

    std::string outStr;
    outStr.resize(olen);
    out = (unsigned char*)&outStr[0];

    end = src + len;
    in = src;
    pos = out;
    while (end - in >= 3) {
        *pos++ = base64_table[in[0] >> 2];
        *pos++ = base64_table[((in[0] & 0x03) << 4) | (in[1] >> 4)];
        *pos++ = base64_table[((in[1] & 0x0f) << 2) | (in[2] >> 6)];
        *pos++ = base64_table[in[2] & 0x3f];
        in += 3;
    }

    if (end - in) {
        *pos++ = base64_table[in[0] >> 2];
        if (end - in == 1) {
            *pos++ = base64_table[(in[0] & 0x03) << 4];
            *pos++ = '=';
        }
        else {
            *pos++ = base64_table[((in[0] & 0x03) << 4) |
                (in[1] >> 4)];
            *pos++ = base64_table[(in[1] & 0x0f) << 2];
        }
        *pos++ = '=';
    }

    return outStr;
}

/**
 * @brief Print program usage.
 * 
 */
void print_help() {
    cout << "\
usage: client [ <option> ... ] <command> [<args>] ...\n\n\
<option> is one of\n\n\
  -a <addr>, --address <addr>\n\
     Server hostname or address to connect to\n\
  -p <port>, --port <port>\n\
     Server port to connect to\n\
  --help, -h\n\
     Show this help\n\
  --\n\
     Do not treat any remaining argument as a switch (at this level)\n\n\
 Multiple single-letter switches can be combined after\n\
 one `-`. For example, `-h-` is the same as `-h --`.\n\
 Supported commands:\n\
   register <username> <password>\n\
   login <username> <password>\n\
   list\n\
   send <recipient> <subject> <body>\n\
   fetch <id>\n\
   logout\n";
}


/**
 * @brief Parse command line arguments.
 * 
 * @param argc Number of arguments
 * @param argv Command line arguments
 * @param server_addr Server network address
 * @param port_number Server port number
 * @param cli Structure to keep command line arguments
 * @return int 
 */
int test_param(int argc, char **argv, string *server_addr, int *port_number, struct CLI *cli) {
    *server_addr = "127.0.0.1";
    *port_number = 32323;
    bool a = false;
    bool p = false;

    if (argc == 1) {
        cout << "client: expects <command> [<args>] ... on the command line, given 0 arguments\n";
        return 0;
    }
    
    static struct option long_options[] = {
        {"address", optional_argument, 0, 'a'},
        {"port", optional_argument, 0, 'p'},
        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0}
    };

    int option_index = 0;
    int getoption = 0;
    while ((getoption = getopt_long(argc, argv, "a:p:h", long_options, &option_index)) != -1) {
        if (getoption < 0) {
            cout << "getopt_long() has failed\n";
            return 1;
        }

        char *endptr = nullptr;
        switch (getoption) {
            case 0:
                return 1;
            case 'a':
                a = true;
                *server_addr = optarg;
                break;
            case 'p':
                p = true;
                *port_number = strtol(optarg, &endptr, 10);
                if (*endptr) {
                    cout << "Port number is not a string\n";
                    return 1;
                }
                break;
            case 'h':
                print_help();
                exit(0);
            case '?':
                return 1;
            default:
                return 1;
        }
    }

    int idx = 0;
    if (!a && !p) {
        idx = 1;
    } else if ((!a && p) || (a && !p)) {
        if (argc <= 3) {
            cout << "client: expects <command> [<args>] ... \
on the command line, given 0 arguments\n";
        }
        idx = 3;
    } else {
        if (argc <= 5) {
            cout << "client: expects <command> [<args>] ... \
on the command line, given 0 arguments\n";
        }
        idx = 5;
    }

    cli->command = argv[idx];
    if (!strcmp(argv[idx], "register")) {
        if (argc != idx + 3) {
            cout << "register <username> <password>" << endl;
            return 1;
        }
        cli->login = argv[idx + 1];
        cli->password = argv[idx + 2];

    } else if (!strcmp(argv[idx], "login")) {
        if (argc != idx + 3) {
            cout << "login <username> <password>" << endl;
            return 1;
        }
        cli->login = argv[idx + 1];
        cli->password = argv[idx + 2];
            
    } else if (!strcmp(argv[idx], "list")) {
        if (argc != idx + 1) {
            cout << "list" << endl;
            return 1;
        }
            
    } else if (!strcmp(argv[idx], "send")) {
        if (argc != idx + 4) {
            cout << "send <recipient> <subject> <body>" << endl;
            return 1;
        }
        cli->recipient = argv[idx + 1];
        cli->subject = argv[idx + 2];
        cli->body = argv[idx + 3];
            
    } else if (!strcmp(argv[idx], "fetch")) {
        if (argc != idx + 2) {
            cout << "fetch <id>" << endl;
            return 1;
        }
        char *endptr = nullptr;
        strtol(argv[idx + 1], &endptr, 10);
        if (*endptr) {
            cout << "ERROR: id " << argv[idx + 1] << " is not a number" << endl;
                return 1;
        } else {
            cli->id = argv[idx + 1];
        }
            
    } else if (!strcmp(argv[idx], "logout")) {
        if (argc != idx + 1) {
            cout << "logout" << endl;
            return 1;
        }

    } else {
        cout << "unknown command\n";
        return 1;
    }

    return 0;
}

/**
 * @brief Generate client request message.
 * 
 * @param cli Structure with command line arguments
 * @return string Client message
 */
string generate_request(struct CLI *cli) {
    if (!cli->command.compare("register") || !cli->command.compare("login")) {
        string pwd_encoded = base64_encode(
            (const unsigned char *)(cli->password.c_str()), cli->password.length());
        return "(" + cli->command + " \"" + cli->login + "\" \"" + pwd_encoded + "\")";

    } else if (!cli->command.compare("send") || 
        !cli->command.compare("list") ||
        !cli->command.compare("logout") ||
        !cli->command.compare("fetch")){
        string login_token;
        ifstream login_token_file("login-token");
        if (login_token_file.is_open()) {
            getline(login_token_file, login_token);
            login_token_file.close();

            if (!cli->command.compare("send")) {
                return "(" + cli->command + " " 
                    + login_token + " \"" + cli->recipient + "\" \""
                    + cli->subject + "\" \"" + cli->body + "\")";
            } else if (!cli->command.compare("list") || !cli->command.compare("logout")) {
                return "(" + cli->command + " " + login_token + ")";
            } else {
                return "(" + cli->command + " " + login_token + " " + cli->id + ")";
            }
        } else {
            cout << "Not logged in" << endl;
            exit(1);
        }
    }
    return "";
}


/**
 * @brief Parse response from server
 * 
 * @param response Response message from server
 * @param cli Structure with command line arguments
 */
void parse_response(string response, struct CLI cli) {
    if (!cli.command.compare("register") || !cli.command.compare("send")) {
        if (response.find("ok") == 1) {
            cout << "SUCCESS: ";
        }
        else {
            cout << "ERROR: ";
        }
        response = response.erase(0, response.find("\"") + 1);
        cout << response.substr(0, response.find("\"")) << endl;
    }
    else if (!cli.command.compare("login")) {
        if (response.find("ok") == 1) {
            cout << "SUCCESS: ";
            response = response.erase(0, response.find("\"") + 1);
            cout << response.substr(0, response.find("\"")) << endl;
            response = response.erase(0, response.find("\"") + 3);
            string login_token = "\"" + response.substr(0, response.find("\"")) + "\"";
            ofstream login_token_file;
            login_token_file.open ("login-token");
            login_token_file << login_token;
            login_token_file.close();
            }
        else {
            cout << "ERROR: ";
            response = response.erase(0, response.find("\"") + 1);
            cout << response.substr(0, response.find("\"")) << endl;
        }
    }
    else if (!cli.command.compare("list")) {
        if (response.find("ok") == 1) {
            cout << "SUCCESS: " << endl;
            response = response.erase(0, response.find(" ") + 2);
            string msg = response.substr(0, response.find(")"));
            while (msg.compare("")) {
                string number = response.substr(1, response.find(" ") - 1);
                response = response.erase(0, response.find(" ") + 2);
                string from = response.substr(0, response.find("\""));
                response = response.erase(0, response.find("\"") + 3);
                string subject = response.substr(0, response.find("\""));
                cout << number << ":" << endl;
                cout << "  From: " << from << endl;
                cout << "  Subject: " << subject << endl;
                response = response.erase(0, response.find("\"") + 3);
                msg = response.substr(0, response.find(")"));
            }
        }
        else {
            cout << "ERROR: ";
            response = response.erase(0, response.find("\"") + 1);
            cout << response.substr(0, response.find("\"")) << endl;
        }
    }
    else if (!cli.command.compare("fetch")) {
        if (response.find("ok") == 1) {
            cout << "SUCCESS: " << endl;
            response = response.erase(0, response.find("\"") + 1);
            string user = response.substr(0, response.find("\""));
            cout << endl << "From: " << user << endl;
            response = response.erase(0, response.find("\"") + 1);
            response = response.erase(0, response.find("\"") + 1);
            string subject = response.substr(0, response.find("\""));
            cout << "Subject: " << subject << endl << endl;
            response = response.erase(0, response.find("\"") + 1);
            response = response.erase(0, response.find("\"") + 1);
            string body = response.substr(0, response.find("\""));
            cout << body << endl;
        } else {
            cout << "ERROR: ";
            response = response.erase(0, response.find("\"") + 1);
            cout << response.substr(0, response.find("\"")) << endl;
        }
    }
    else if (!cli.command.compare("logout")) {
        if (response.find("ok") == 1) {
            cout << "SUCCESS: " << endl;
            remove("login-token");
        } else {
            cout << "ERROR: ";
        }
        response = response.erase(0, response.find("\"") + 1);
        cout << response.substr(0, response.find("\"")) << endl;
    }
}

/**
 * @brief Main function with TCP connection.
 * 
 * @param argc 
 * @param argv 
 * @return int 
 */
int main(int argc, char *argv[]) {
    int port_number, client_socket;
    string server_addr;
    struct sockaddr_in server_address;
    struct sockaddr_in6 server_address6;
    struct CLI cli;
    char buf[BUFSIZE];

    bzero((char *) &buf, sizeof(buf));
    bzero((char *) &server_address, sizeof(server_address));
    bzero((char *) &server_address6, sizeof(server_address6));

    int ret = test_param(argc, argv, &server_addr, &port_number, &cli);
    if (ret != 0)
        return 1;

    if (inet_pton(AF_INET, server_addr.c_str(), &(server_address.sin_addr)) > 0) {
        if ((client_socket = socket(AF_INET, SOCK_STREAM, 0)) <= 0) {
            perror("ERROR: socket\n");
            exit(EXIT_FAILURE);
        }

        server_address.sin_family = AF_INET;
        server_address.sin_port = htons(port_number);

        if (connect(client_socket, (const struct sockaddr *) &server_address, sizeof(server_address)) != 0) {
            perror("ERROR: connect\n");
            exit(EXIT_FAILURE);        
        }
    }
    else if (inet_pton(AF_INET6, server_addr.c_str(), &(server_address6.sin6_addr)) > 0) {
        if ((client_socket = socket(AF_INET6, SOCK_STREAM, 0)) <= 0) {
            perror("ERROR: socket\n");
            exit(EXIT_FAILURE);
        }

        server_address6.sin6_family = AF_INET6;
        server_address6.sin6_port = htons(port_number);
        if (connect(client_socket, (const struct sockaddr *)&server_address6, sizeof(server_address6)) != 0) {
            perror("ERROR: connect\n");
            exit(EXIT_FAILURE);        
        }
    }
    else {
        cerr << "tcp-connect: host not found" << endl;
        cerr << "hostname: " << server_addr << endl;
        cerr << "port: " << port_number << endl;
        exit(1);
    }

    string client_request = generate_request(&cli);

    /* sending request to server */
    int bytestx = send(client_socket, client_request.c_str(), client_request.length(), 0);
    if (bytestx < 0) {
        cerr << "ERROR in sendto";
        close(client_socket);
        exit(EXIT_FAILURE);
    }

    string response;
    /* receiving response from client */
    while ((ret = recv(client_socket, buf, BUFSIZE, 0)) > 0) {
        response = response + buf;
    }
    if (ret < 0) {
        cerr << "ERROR in sendto";
        close(client_socket);
        exit(EXIT_FAILURE);
    }
    else {
        parse_response(response, cli);
    }
 
    close(client_socket);

    return 0;
}