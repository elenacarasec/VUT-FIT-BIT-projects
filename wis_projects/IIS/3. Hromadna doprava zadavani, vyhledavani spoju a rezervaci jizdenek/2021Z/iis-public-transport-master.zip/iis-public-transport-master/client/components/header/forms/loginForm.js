
import React from "react";
import Link from 'next/link'
import {Button, Form, Input, Checkbox, message} from 'antd'; 
import {UserOutlined} from '@ant-design/icons';
import Router from 'next/router';
import axios from 'axios';
import jwt_decode from "jwt-decode";

import styles from '/styles/forms.module.scss' // Styles 


export default class LoginForm extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loggedUser: null
        }
    }

    componentDidMount = () => {
        let authToken = localStorage.getItem('authToken')
        if (authToken !== null) {
            let decodedUser = jwt_decode(authToken);
            this.setState({loggedUser: decodedUser})
        }
    }

    
    handleFinish = (data) => {
        console.log('This is my data!!!', data)
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/user/login",
            data: data,
        })
            .then(res => 
                    {
                        let authToken = res.data;
                        localStorage.setItem('authToken', authToken)
                        let decodedUser = jwt_decode(authToken);
                        this.setState({loggedUser: decodedUser})
                          
                    }
                    
                )
            .catch(err => {
                message.info('Incorrect e-mail or password')
            });
                
    
    }

    render()
    {
        return (
            <>
            <div align='center' style={{marginBottom: '1.6em'}}>
                <UserOutlined style={{fontSize: '60px', color: '#a9a9a9'}}/>
            </div>
            {this.state.loggedUser === null ?
            <Form onFinish={this.handleFinish}>
                <Form.Item name="email">
                    <Input className={styles.forms} placeholder='Input your email' required size='large'/>
                </Form.Item>
                <Form.Item name="password">
                    <Input.Password
                        className={styles.forms} placeholder={'Input your password'} required size='large'/>
                </Form.Item>
                <Checkbox style={{fontSize: '20px'}}> Remember me </Checkbox>
                <Form.Item>
                    <div align='center'>
                        <Button type='primary' className={styles.buttonLog} size='large' htmlType='submit' style={{marginTop: '1vh',}} > LOGIN </Button>
                    </div>
                </Form.Item>
                <Link href='/registration'>   
                    <a>Not registered yet?</a>
                </Link>          
            </Form>
            :
            <div>
                <div align='center' style={{marginBottom: '1em', fontSize: '2em'}}>
                    {this.state.loggedUser.email}
                </div>
                <div align='center' style={{marginBottom: '2em'}}>
                    
                    {
                        this.state.loggedUser.role === "STAFF" &&
                        <Link href='/staff/ticketsList'>
                            <Button type='primary' style={{width: '200px',marginTop:'1em'}}>
                                Staff Page
                            </Button>
                        </Link>
                    }
                    {
                        this.state.loggedUser.role === "CARRIER" &&
                        <Link href='/carrier/connectionList'>
                            <Button type='primary' style={{width: '200px',marginTop:'1em'}}>
                                Carrier Page
                            </Button>
                        </Link>
                    }
                    {
                        this.state.loggedUser.role === "ADMIN" &&
                        <Link href='/admin'>
                            <Button type='primary' style={{width: '200px',marginTop:'1em'}}>
                                Admin Panel
                            </Button>
                        </Link>
                    }
                    <Link href='/location/connectionLocation'>
                            <Button style={{width: '200px',marginTop:'1em'}}>
                                Connections location
                            </Button>
                        </Link>

                    <Link href='/reservation'>
                        <Button style={{width: '200px',marginTop:'1em'}}>
                            My reservations
                        </Button>
                    </Link>
                </div>
            </div>
            }
            </>
        )
    }
}
