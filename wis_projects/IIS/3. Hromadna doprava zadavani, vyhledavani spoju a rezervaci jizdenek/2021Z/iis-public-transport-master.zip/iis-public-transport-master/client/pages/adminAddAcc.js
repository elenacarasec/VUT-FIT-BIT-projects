
import React, {useState} from "react";
import Head from 'next/head';
import Link from 'next/link'
import { Header } from "antd/lib/layout/layout";
import axios from 'axios';
import {Button, Row, Col, Form, Select, message } from 'antd'; 
import AdminHeader from '../components/header/forms/adminHeader';

import styles from '../styles/index.module.scss'
import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";
import Router from 'next/router';

const {Option} = Select;
export default class AdminAddAcc extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loggedUser: 'loading',
            connections: 'loading'
        }
        axios({
            method: "get",
            url: "https://iis-public-transport.herokuapp.com/api/user/list_all",
        })
        .then(res => {
            this.setState({connections: res.data.map(el => el.email)})
        })
        .catch(err => message.info('No user found'))
    }

    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            console.log(user);
            this.setState({loggedUser: user})
        }
    }

    handleFinish = (values) => {
        Router.push({pathname: "/adminPage", query : {email:values.email}})
    }

    render() { 

        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && this.state.loggedUser.role === 'ADMIN') {
        return (
            <div>
                <Head>
                    <title>Admin</title>
                </Head>     
                
                <Header style={{padding: '0'}}>
                    <AdminHeader/>
                </Header>
                <Row  style={{marginTop: '180px'}} align='center'>
                    <Col xs={22} sm={11} md={10} lg={6} xl={6} xxl={8}>
                        <Form onFinish={this.handleFinish} 
                        scrollToFirstError='True'
                            className={styles.forms} >
                          {this.state.connections === 'loading' ?
                            <div align='center'>
                                <LoadingOutlined style={{fontSize: '2em'}}/>
                            </div>
                            :
                            <Form.Item name="email" style={{ width: '70%'}}>
                                <Select placeholder={' User email'} required optionFilterProp="children" size='large'>
                                    {this.state.connections.map(el => {
                                        return (
                                            <Option key={el} value={el}>{el}</Option>
                                        )
                                    })}
                                </Select>
                            </Form.Item>
                            }
                            <Form.Item style={{display: 'inline-block', float: 'right'}}>
                                <Button type='primary' size='large' htmlType='submit'>SEARCH </Button>
                            </Form.Item>
                        </Form>
                        
                        <h2>
                            - OR -
                        </h2>
                        
                        <span>
                            <Link href='/registrationUser'> 
                                <Button type='primary' htmlType='submit' style={{width:'10%'}}>Create new user account </Button>
                            </Link>
                        </span>

                    </Col>                    
                </Row> 

            </div>
        )}
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'ADMIN')) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
