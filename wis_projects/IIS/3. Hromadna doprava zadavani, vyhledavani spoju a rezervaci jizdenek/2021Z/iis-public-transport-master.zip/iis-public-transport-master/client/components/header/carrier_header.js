import React from "react";

import {Row, Col} from 'antd';
import styles from './header.module.scss'
import Router from "next/router";


export default class StaffHeader extends React.Component {
	handleLogout = () => {
        localStorage.removeItem('authToken')
        Router.push('/')
    }
    render() {
		
        return (   
            <Row align='center' gutter={[0, 5]} style={{ position: "relative"}}>
				<Col align='center' onClick={() => {Router.push('/')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
					HOME 
				</Col>
				<Col align='center' onClick={() => {Router.push('/carrier/connectionList')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
					CONNECTIONS
				</Col>
				<Col align='center' onClick={() => {Router.push('/carrier/stationTable')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
					STATIONS
				</Col>
				<Col align='center' onClick={() => {Router.push('/carrier/vehicle')}}  className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
					VEHICLE				
				</Col>
                <Col align='center' onClick={() => {Router.push('/carrier/staff')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
					STAFF
				</Col>
				<Col align='center' onClick={this.handleLogout} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}> 
					LOGOUT
				</Col>
            </Row>
        )
    }
}