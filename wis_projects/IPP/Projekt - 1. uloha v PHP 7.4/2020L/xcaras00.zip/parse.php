<?php
//
// Author: Elena Carasec (xcaras00)
// Date: 2021.03.17
//

// ini_set('display_errors', 'stderr');

// Transform special XML symbols to their equivalents.
function xml_prohibited_symbols($arg) {
    return str_replace(
        array("&", "<", ">", '"', "'"),
        array("&amp;", "&lt;", "&gt;", "&quot;", "&apos;"), 
        $arg);
}

// Create XML element.
// $xml - instance of XMLWriter class
// $arg_type - value of type attribute
// $arg_num - number of the XML arg element
// $arg - text of the XML arg element
//
function print_xml_element($xml, $arg_type, $arg_num, $arg) {
    xmlwriter_start_element($xml, 'arg'.$arg_num);
    xmlwriter_start_attribute($xml, 'type');
    xmlwriter_text($xml, $arg_type);
    xmlwriter_end_attribute($xml);
    xmlwriter_write_raw($xml, xml_prohibited_symbols($arg));
    xmlwriter_end_element($xml);
}

// Check presence of ".IPPcode21" header.
function check_header($xml) {
    $header = "/\.IPPcode21/i";
    $header_presents = FALSE;
    while($line_preview = fgets(STDIN)) {
        $line_pre = explode ("#", $line_preview, 2);
        $line = preg_split("/\s+/", trim($line_pre[0], "/ \n\r\t\v\0/"));
        if ($line[0] == "") {
            continue;
        }

        if (!preg_match($header, trim($line[0], "/s+/"))) {
            exit(21);
        } elseif (isset($line[1])) {
            exit(21);
        }
        $header_presents = TRUE;
        xmlwriter_start_attribute($xml, 'language');
        xmlwriter_text($xml, 'IPPcode21');
        xmlwriter_end_attribute($xml);
        return;
    }
    if ($header_presents == FALSE) {
        exit(21);
    }
}

// Print the text of help message.
function print_help() {
    echo "\"parse.php\" - parser for IPPcode21.
        \r$ php7.4 parse.php <filename \n
        \r--help         - Prints this help.\n
        \r--stats=<file> - Prints statistics of input file with code to the output file. 
        \rThe groups of statistics to print should be declared after this parameter.
        \rTo print different groups of statistics to different files use this parameter many times.\n
        \rStatistics types:
        \r--loc         - Number of lines of code
        \r--comments    - Number of comments.
        \r--jumps       - Number if jumps, function calls and returns.
        \r--fwjumps     - Number of forward jumps.
        \r--backjumps   - Number of backward jumps.
        \r--badjumps    - Number of jumps to undefined label.\n";
}

// Parse command-line arguments and fill-in array $stats
// with filenames and types of required statistics.
function parse_cli_args($argv, &$stats) {
    $curr_filename;
    $stats_flag = FALSE;
    $other_params = FALSE;
    $help_param = FALSE;

    foreach ($argv as $arg) switch ($arg) {
        case "--help":
            if ($other_params) {
                exit(10);
            }
            $help_param = TRUE;

            break;
        case "--loc":
        case "--comments":
        case "--jumps":
        case "--fwjumps":
        case "--backjumps":
        case "--badjumps":
            $other_params = TRUE;
            if ($help_param) {
                exit(10);
            }
            if ($stats_flag == FALSE) {
                exit(10);
            }
            $stats[$curr_filename][] = trim($arg, "-");
            break;
        default:
            if ($arg == $argv[0]) {
                break;
            }
            elseif ($help_param) {
                exit(10);
            }
            elseif (preg_match("/^\-\-stats\=*/", $arg)) {
                $stats_flag = TRUE;
                $curr_filename = preg_replace("/^\-\-stats\=/", "", $arg);
                if (array_key_exists($curr_filename, $stats)) {
                    exit(12);
                }
                $other_params = TRUE;
                break;
            }
            else {
                exit(10);
            }
    }

    if ($help_param) {
        print_help();
        exit(0);
    }
}

// Scanner and parser for IPPcode21 programs.
// Detects lexical and semantic errors and collects statistics.
function main($argc, $argv) {
    $stats_files = array();
    parse_cli_args($argv, $stats_files);

    $stats = array(
        "comments"=>0,
        "loc"=>0,
        "labels"=>0,
        "jumps"=>0,
        "fwjumps"=>0,
        "backjumps"=>0,
        "badjumps"=>0
    );

    $labels = array();
    $jumps = array();

    $int = "int@[\+\-]?\d";
    $bool = "bool@(true|false){1}";
    $str = "string@(\\\\[0-9]{3}|\w|[_\+\-\*\,\.\/\$\&%\*\!\?@\'\"\<\>\[\]\(\)\{\}\^\=\:\;\`\|\~])*$";
    $nil = "nil@nil";
    $spec_symb = "[_\-\$\&%\*\!\?]";
    $label = "/".$spec_symb."|[a-z]|[A-Z](".$spec_symb."|\w)*/";
    $var = "/(GF|TF|LF){1}@(".$spec_symb."|[a-z]|[A-Z])(".$spec_symb."|\w)*/u";
    $symb = "(".$int."|".$bool."|".$str."|".$nil."|(GF|TF|LF){1}@(".$spec_symb."|[a-z]|[A-Z])(".$spec_symb."|\w)*){1}";
    $type = "/^(int|string|nil|bool){1}$/";

    $op_w0 = "/^(CREATEFRAME|PUSHFRAME|POPFRAME|RETURN|BREAK){1}$/i";
    $op_w1_symb = "/^(PUSHS|WRITE|EXIT|DPRINT){1}$/i";
    $op_w1_var = "/^(DEFVAR|POPS){1}$/i";
    $op_w1_label = "/^(CALL|LABEL|JUMP){1}$/i";
    $op_w2_var_symb = "/^(MOVE|INT2CHAR|STRLEN|TYPE|NOT){1}$/i";
    $op_w2_var_type = "/^(READ){1}$/i";
    $op_w3_var_symb1_symb2 = "/^(ADD|SUB|MUL|IDIV|LT|GT|EQ|AND|OR|STRI2INT|CONCAT|GETCHAR|SETCHAR){1}$/i";
    $op_w3_label_symb1_symb2 = "/^(JUMPIFEQ|JUMPIFNEQ){1}$/i";

    $xml = xmlwriter_open_memory();
    xmlwriter_set_indent($xml, 1);
    $res = xmlwriter_set_indent_string($xml, '    ');
    xmlwriter_start_document($xml, '1.0', 'UTF-8');
    xmlwriter_start_element($xml, 'program');

    check_header($xml);

    $order = 0;
    $line = "";

    while($line_pre = fgets(STDIN)) {
        $line_pre = explode ("#", $line_pre, 2);
        if (isset($line_pre[1])) {
            $stats["comments"]++;
        }
        $line = preg_split("/\s+/", trim($line_pre[0], "/ \n\r\t\v\0/"));

        if ($line[0] == "") {
            continue;
        }

        $order = $order + 1;
        if (preg_match($op_w0, $line[0])) {
            if (isset($line[1])) {
                fwrite(STDERR, $line[0], "should not have arguments\n");
                exit(23);
            }
            xmlwriter_start_element($xml, 'instruction');
            xmlwriter_start_attribute($xml, 'order');
            xmlwriter_text($xml, $order);
            xmlwriter_end_attribute($xml);
            xmlwriter_start_attribute($xml, 'opcode');
            xmlwriter_text($xml, $line[0]);
            xmlwriter_end_attribute($xml);
            xmlwriter_end_element($xml);
            if (strtoupper($line[0]) == "RETURN") {
                $stats["jumps"]++;
            }
            $stats["loc"]++;
            continue;
        }
        elseif (preg_match($op_w1_symb, $line[0])) {
            if (isset($line[1]) && preg_match('/'.$symb.'/u', $line[1])) {
                if (!isset($line[2])) {
                    xmlwriter_start_element($xml, 'instruction');
                    xmlwriter_start_attribute($xml, 'order');
                    xmlwriter_text($xml, $order);
                    xmlwriter_end_attribute($xml);
                    xmlwriter_start_attribute($xml, 'opcode');
                    xmlwriter_text($xml, $line[0]);
                    xmlwriter_end_attribute($xml);
                    $curr_symb = explode("@", $line[1], 2);
                    if (preg_match("/(GF|LF|TF){1}/", $curr_symb[0])) {
                        print_xml_element($xml, 'var', '1', $line[1]);
                    }
                    else {
                        print_xml_element($xml, $curr_symb[0], '1', $curr_symb[1]);
                    }
                    xmlwriter_end_element($xml);
                    $stats["loc"]++;
                    continue;
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w1_var, $line[0])) {
            if (isset($line[1]) && preg_match($var, $line[1])) {
                if (!isset($line[2])) {
                    xmlwriter_start_element($xml, 'instruction');
                    xmlwriter_start_attribute($xml, 'order');
                    xmlwriter_text($xml, $order);
                    xmlwriter_end_attribute($xml);
                    xmlwriter_start_attribute($xml, 'opcode');
                    xmlwriter_text($xml, $line[0]);
                    xmlwriter_end_attribute($xml);
                    print_xml_element($xml, 'var', '1', $line[1]);
                    xmlwriter_end_element($xml);
                    $stats["loc"]++;
                    continue;
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w1_label, $line[0])) {
            if (isset($line[1]) && preg_match($label, $line[1])) {
                if (!isset($line[2])) {
                    xmlwriter_start_element($xml, 'instruction');
                    xmlwriter_start_attribute($xml, 'order');
                    xmlwriter_text($xml, $order);
                    xmlwriter_end_attribute($xml);
                    xmlwriter_start_attribute($xml, 'opcode');
                    xmlwriter_text($xml, $line[0]);
                    xmlwriter_end_attribute($xml);
                    print_xml_element($xml, 'label', '1', $line[1]);
                    xmlwriter_end_element($xml);
                    $stats["loc"]++;
                    if (strtoupper($line[0]) == "LABEL") {
                        $labels[$line[1]] = $stats["loc"];
                        $stats["labels"]++;
                    }
                    elseif (strtoupper($line[0]) == "JUMP" || strtoupper($line[0]) == "CALL") {
                        $jumps[$stats["loc"]] = $line[1];
                        $stats["jumps"]++;
                    }
                    continue;
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w2_var_symb, $line[0])) {
            if (isset($line[1]) && preg_match($var, $line[1])) {
                if (isset($line[2]) && preg_match('/'.$symb.'/u', $line[2])) {
                    if (!isset($line[3])) {
                        xmlwriter_start_element($xml, 'instruction');
                        xmlwriter_start_attribute($xml, 'order');
                        xmlwriter_text($xml, $order);
                        xmlwriter_end_attribute($xml);
                        xmlwriter_start_attribute($xml, 'opcode');
                        xmlwriter_text($xml, $line[0]);
                        xmlwriter_end_attribute($xml);
                        print_xml_element($xml, 'var', '1', $line[1]);
                        $curr_symb = explode("@", $line[2], 2);
                        if (preg_match("/(GF|LF|TF){1}/", $curr_symb[0])) {
                            print_xml_element($xml, 'var', '2', $line[2]);
                        }
                        else {
                            print_xml_element($xml, $curr_symb[0], '2', $curr_symb[1]);
                        }
                        xmlwriter_end_element($xml);
                        $stats["loc"]++;
                        continue;
                    }
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w2_var_type, $line[0])) {
            if (isset($line[1]) && preg_match($var, $line[1])) {
                if (isset($line[2]) && preg_match($type, $line[2])) {
                    if (!isset($line[3])) {
                        xmlwriter_start_element($xml, 'instruction');
                        xmlwriter_start_attribute($xml, 'order');
                        xmlwriter_text($xml, $order);
                        xmlwriter_end_attribute($xml);
                        xmlwriter_start_attribute($xml, 'opcode');
                        xmlwriter_text($xml, $line[0]);
                        xmlwriter_end_attribute($xml);
                        print_xml_element($xml, 'var', '1', $line[1]);
                        print_xml_element($xml, 'type', '2', $line[2]);
                        xmlwriter_end_element($xml);
                        $stats["loc"]++;
                        continue;
                    }
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w3_var_symb1_symb2, $line[0])) {
            if (isset($line[1]) && preg_match($var, $line[1])) {
                if (isset($line[2]) && preg_match('/'.$symb.'/u', $line[2])) {
                    if (isset($line[3]) && preg_match('/'.$symb.'/u', $line[3])) {
                        if (!isset($line[4])) {
                            xmlwriter_start_element($xml, 'instruction');
                            xmlwriter_start_attribute($xml, 'order');
                            xmlwriter_text($xml, $order);
                            xmlwriter_end_attribute($xml);
                            xmlwriter_start_attribute($xml, 'opcode');
                            xmlwriter_text($xml, $line[0]);
                            xmlwriter_end_attribute($xml);
                            print_xml_element($xml, 'var', '1', $line[1]);
                            $curr_symb = explode("@", $line[2], 2);
                            if (preg_match("/(GF|LF|TF){1}/", $curr_symb[0])) {
                                print_xml_element($xml, 'var', '2', $line[2]);
                            }
                            else {
                                print_xml_element($xml, $curr_symb[0], '2', $curr_symb[1]);
                            }
                            $curr_symb = explode("@", $line[3], 2);
                            if (preg_match("/(GF|LF|TF){1}/", $curr_symb[0])) {
                                print_xml_element($xml, 'var', '3', $line[3]);
                            }
                            else {
                                print_xml_element($xml, $curr_symb[0], '3', $curr_symb[1]);
                            }
                            xmlwriter_end_element($xml);
                            $stats["loc"]++;
                            continue;
                        }
                    }
                }
            }
            exit(23);
        }
        elseif (preg_match($op_w3_label_symb1_symb2, $line[0])) {
            if (isset($line[1]) && preg_match($label, $line[1])) {
                if (isset($line[2]) && preg_match('/'.$symb.'/u', $line[2])) {
                    if (isset($line[3]) && preg_match('/'.$symb.'/u', $line[3])) {
                        if (!isset($line[4])) {
                            xmlwriter_start_element($xml, 'instruction');
                            xmlwriter_start_attribute($xml, 'order');
                            xmlwriter_text($xml, $order);
                            xmlwriter_end_attribute($xml);
                            xmlwriter_start_attribute($xml, 'opcode');
                            xmlwriter_text($xml, $line[0]);
                            xmlwriter_end_attribute($xml);
                            print_xml_element($xml, 'label', '1', $line[1]);
                            $curr_symb = explode("@", $line[2], 2);
                            if (preg_match("/(GF|LF|TF){1}/", $curr_symb[0])) {
                                print_xml_element($xml, 'var', '2', $line[2]);
                            }
                            else {
                                print_xml_element($xml, $curr_symb[0], '2', $curr_symb[1]);
                            }
                            $curr_symb = explode("@", $line[3], 2);
                            if (preg_match("/(GF|LF|TF){1}/", $curr_symb[0])) {
                                print_xml_element($xml, 'var', '3', $line[3]);
                            }
                            else {
                                print_xml_element($xml, $curr_symb[0], '3', $curr_symb[1]);
                            }
                            xmlwriter_end_element($xml);
                            $stats["loc"]++;
                            $stats["jumps"]++;
                            $jumps[$stats["loc"]] = $line[1];
                            continue;
                        }
                    }
                }
            }
            exit(23);
        }
        else {
            exit(22);
        }
    }

    foreach ($jumps as $num => $label_name) {
        if (array_key_exists($label_name, $labels)) {
            if ($num < $labels[$label_name]) {
                $stats["fwjumps"]++;
            }
            else {
                $stats["backjumps"]++;
            }
        }
        else {
            $stats["badjumps"]++;
        }
    }

    foreach($stats_files as $filename => $arr) {
        $file;
        if(($file = fopen($filename, "w", TRUE)) == FALSE) {
            exit(11);
        }
        foreach($arr as $num => $option) {
            if(fwrite($file, $stats[$option]."\n") == FALSE) {
                exit(12);
            }
        }
        fclose($file);
    }

    xmlwriter_end_element($xml);
    xmlwriter_end_document($xml);
    echo xmlwriter_output_memory($xml);
    xmlwriter_flush($xml);
}

main($argc, $argv);
?>
