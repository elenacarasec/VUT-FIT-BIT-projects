
import React from "react";
import {Row, Col, Button, Divider, message, Form, Select} from 'antd'
import styles from "./listOfRidesItem.module.sass"
import axios from 'axios';
import {LoadingOutlined} from '@ant-design/icons';
const {Option} = Select;


export default class ListOfRidesItem extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            stations: 'loading',
        }
    }

    componentDidMount = () => {
        axios({
            method: "POST",
            url: "https://iis-public-transport.herokuapp.com/api/ride/get_connection",
            data: {connectionId: this.props.item.id}
        })
        .then (
            res => {
                this.setState({
                    stations: res.data,

                })
            },
        )
        .catch ( err => {
                // Connection NOT FOUND
                console.log('Error in response', err)
                message.error(err, 3)
            }
        )
    }

    onChangeCurrentPosition = (pos) => {
     //   console.log(pos)

        axios({
            method: "POST",
            url: "https://iis-public-transport.herokuapp.com/api/ride/change_current_pozition",
            data: {connectionId: this.props.item.id, stationId: pos}
        })
        .then (
            res => {
                console.log('Success')
                message.open({
                    type: 'success',
                    duration: 3,
                    content: 'Current position was successfully changed',
                })
            },
        )
        .catch ( err => {
                console.log('Error in response', err)
                message.open({
                    type: 'error',
                    duration: 3,
                    content: 'Something went wrong, please, repeat your attempt or contact service provider',
                })
            }
        )
    }
    
    render() {
        return (
            <div className={styles.body}>
                <Row style={{marginBottom: '0em'}}>
                    <Col span={8}>
                        <div className={styles.description}>
                            {this.props.item.description}
                        </div>
                    </Col>

                    <Col span={6}>
                        <div className={styles.carrier}>
                        {this.props.item.carrier}
                        </div>
                    </Col>
                    <Col span={10} >
                        {(this.state.stations === 'loading') ?
                        <div align='center'>
                            <LoadingOutlined/>
                        </div> 
                        :
                        ((this.props.loggedUser.role === 'STAFF' || this.props.loggedUser.role === 'ADMIN') ?
                            <Form 
                            initialValues={{stationId: (this.state.stations !== "null" && this.state.stations.find(el => el.current_position === 1)) ? this.state.stations.find(el => el.current_position === 1).stationId : null}}>
                                <Form.Item name={'stationId'} style={{marginBottom: 0, paddingLeft: '2em'}}>
                                    <Select placeholder={'Curren position'} 
                                        style={{padding: 0, width: "150px"}}
                                        optionFilterProp="children"
                                        onChange={this.onChangeCurrentPosition}
                                        >
                                        {this.state.stations !== "null" && this.state.stations.map(st => {
                                            return (
                                                <Option key={st.station} value={st.stationId}>{st.station}</Option>
                                            )
                                        })}
                                    </Select>
                                </Form.Item>
                            </Form>
                        :
                        <div align='right' className={styles.position}>
                            {console.log("STATIONS", this.state.stations)}
                            {this.state.stations !== "null" && this.state.stations.find(el => el.current_position === 1) && this.state.stations.find(el => el.current_position === 1).stationId}
                        </div>
                        )    
                        }
                    </Col>
                </Row>
            </div>
        )
    }
}