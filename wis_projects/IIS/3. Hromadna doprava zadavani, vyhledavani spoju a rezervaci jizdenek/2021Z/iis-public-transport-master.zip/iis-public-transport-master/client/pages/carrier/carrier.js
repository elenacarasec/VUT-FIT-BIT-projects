import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, Input, Select, Radio, Space, Typography} from 'antd';
const { Option } = Select;
const { Text } = Typography;
import CarrierHeader from '../../components/header/carrier_header';
import styles from '../../styles/index.module.scss';
import staffStyles from '../../styles/staff.module.scss';
import carrierStyles from '../../styles/carrier.module.scss';
import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";
import Router from "next/router";




class CarrierPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {loggedUser: "loading"}
    }

    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user})
        }
    }

    handleFinish = (data) => {
        console.log('This is my data!!!', data)
        
        // sendToServer(data).then(
        //     (res) => {

        //     },
        //     (err) => {

        //     }
        // )
    }

    render() {
        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && this.state.loggedUser.role === 'CARRIER') {
        return (
            <div>
                <Head>
                    <title>Carrier</title>
                </Head>
		        <Header style={{padding: '0',}}>
                	<CarrierHeader/>
		        </Header>  
                
                <Row align='center' className={styles.centerdBlock}>
                    <Col>
                        <Row align='center'>
                        <Form >
                            <Form.Item className={staffStyles.forms} name="connection">                   
                                <Select showSearch placeholder={<span>Connections</span>}
                                            optionFilterProp="children">
                                    <Option value='1'>CN34567 Brno-Královo Pole -&gt; Pardubice-Pardubičky</Option>
                                    <Option value='2'>CN34532 Brno-Hl.nadrazi -&gt; Praha-Hl.nadrazi</Option>
                                </Select>
                            </Form.Item>
                        </Form>
                        </Row>
                        
                    </Col>
			        
                </Row>
            </div>
        )}
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'CARRIER')) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }

    }
}



const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (CarrierPage);