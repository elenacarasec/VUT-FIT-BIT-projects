
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import Router from 'next/router';
import Link from "next/link"; 
import axios from 'axios';

import styles from '../styles/index.module.scss' // Styles 
import MenuItem from "antd/lib/menu/MenuItem";
const {Option} = Select;
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, Input, Select, Button, Space, Typography} from 'antd';
import AdminHeader from '../components/header/forms/adminHeader';

const prefixSelector = (
    <Form.Item name="prefix" noStyle>
      <Select style={{ width: 70 }}>
        <Option value="420">+420</Option>
      </Select>
    </Form.Item>
  );

class CarrierPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            customer: {
                role: "USER",
                name: null,
                password: null,
                phone_number: null,
                email: null,
                company: null
            },
            userToken: null,
        }
    }


    handleFinish = (data) => {
        data.company = null
        console.log('This is my data!!!', data)
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/user/registration",
            data: data
        })
            .then(res => 
                    Router.push('/admin')
                )
            .catch(err => alert("This e-mail is already used"));

    }

    render() {
        return (
            <div>
                <Head>
                    <title>Admin</title>
                </Head>     
                <Header style={{padding: '0'}}>
                    <AdminHeader/>
                </Header>
                <Row align='center' style={{marginTop: '128px'}}>
                    <Col align='center' xs={22} sm={11} md={10} lg={7} xl={6} xxl={6}>
                        <Form onFinish={this.handleFinish}
                            scrollToFirstError='True'
                            className={styles.forms} >
                            <Form.Item name="name">
                                <Input placeholder='Name' required
                                    className={styles.forms}
                                    size='large'/>                      
                            </Form.Item>
                            <Form.Item name="password">
                                <Input.Password placeholder='Password' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="phone_number">
                                <Input addonBefore={prefixSelector}
                                placeholder='Phone'className={styles.forms} size='large'/>
                            </Form.Item>
                            <Form.Item name="email">
                                <Input placeholder='E-mail' required
                                    type="email" className={styles.forms} size='large'/>
                            </Form.Item>
                            <Form.Item name="role"  rules={[{ required: true, message: 'Choose a role'}]}>
                                <Select showSearch size='large'required
                                 placeholder={
                                        <span>
                                            User role
                                        </span>}
                                    style={{padding: 0}}
                                    className={styles.forms}
                                    optionFilterProp="children">
                                        <Option value="ADMIN">ADMIN</Option>
                                        <Option value="CARRIER">CARRIER</Option>
                                        <Option value="STAFF">STAFF</Option>
                                        <Option value="USER">USER</Option>
                                    </Select>
                            </Form.Item>
                            {/* <Link href='/index'> */}
                            <div align='center'>
                                <Button type='primary' size='large' htmlType='submit' className={styles.buttonLog}> Register </Button>
                            </div>

                        </Form>
                    </Col>
                </Row> 

            </div>
        )
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (CarrierPage);

