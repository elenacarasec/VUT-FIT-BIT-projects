const ApiError = require('../error/api_error')
const {Ticket, Connection, Vehicle} = require('../models/models')

class TicketController {
    async create_ticket(req, res, next) {
        const {connectionId, station_from, station_to, price} = req.body
        if (!connectionId || !station_from || !station_to) {
            return next(ApiError.bad_request('missing data to create reservation'))
        }
        const vehicle = await Vehicle.findOne({where: {connectionId}})
        if (!vehicle) {
            return next(ApiError.internal('vehicle is missing for that connection'))
        }
        console.log('```````````', connectionId, station_from, station_to, '```````````')
        console.log('```````````', req.user.email, req.user.id, station_to, '```````````')
        const number_of_bought_tickets = await Connection.findOne({where: {id: connectionId}})
        if (!number_of_bought_tickets) {
            return next(ApiError.internal('missng data of bought tickets'))
        }
        const vehicle_capacity = vehicle.number_of_seats - number_of_bought_tickets.passengers
        if (vehicle_capacity === 0) {
            return next(ApiError.internal('there is no tickets left for that connection'))
        }
        const connection_upd = await Connection.update({passengers: number_of_bought_tickets.passengers+1}, {where: {id: connectionId}})
        const created_ticket = await Ticket.create({
            price_category : '-',
            from : station_from,
            to : station_to,
            reserved : 0,
            paid	 : 0,
            verified : 0,
            seat : 0,
            price : price,
            email: req.user.email,
            userId : req.user.id,
            connectionId : connectionId
        })
        return res.json(created_ticket)
    }
        
    async approve_reservation(req, res, next) {
        const {id} = req.body
        if (!id) {
            return next(ApiError.bad_request('there is no ticket id'))      
        }
        const update = await Ticket.update({reserved : 1}, {where: {id : id}})
        return res.json(update)
    }

    async approve_purchase(req, res, next) {
        const {id} = req.body
        if (!id) {
            return next(ApiError.bad_request('there is no ticket id'))      
        }
        const update = await Ticket.update({paid : 1}, {where: {id : id}})
        return res.json(update)
    }

    async verify(req, res, next) {
        const {id} = req.body
        if (!id) {
            return next(ApiError.bad_request('there is no ticket id'))      
        }
        const update = await Ticket.update({verified : 1}, {where: {id : id}})
        return res.json(update)
    }

    async tickets_to_verify(req, res, next) {
        const {connectionId} = req.body
        if (!connectionId) {
            return next(ApiError.bad_request('missng connectionId'))
        }
        const candidate = await Ticket.findAll({where: {reserved : 1, connectionId : connectionId}})
        return res.json(candidate)
    }

    async tickets_to_approve_reservation(req, res, next) {
        const candidate = await Ticket.findAll({where: {reserved : 0}})
        return res.json(candidate)
    }

    async list_all (req, res, next) {
        const candidate = await Ticket.findAll()
        return res.json(candidate)
    }

    async get_ticket_list (req, res, next) {
        const tickets = await Ticket.findAll({where: {userId: req.user.id}})
        return res.json(tickets)
    }
}

module.exports = new TicketController()