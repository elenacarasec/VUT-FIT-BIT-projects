###################################################################
##                                                               ##
##      Author: Elena Carasec (xcaras00@stud.fit.vutbr.cz)       ##
##      Date:   2021.03.27                                       ##
##      Name:   IPK project1                                     ##
##                                                               ##
###################################################################


import socket
import argparse
from re import compile
from sys import exit
from os import mkdir, getcwd, chdir
from os.path import isdir


def parse_arguments():
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('-n', required=True, help='IP address and port number')
    arg_parser.add_argument('-f', required=True, help='fsp://<server_name>/<filename>')
    args = arg_parser.parse_args()

    dest_addr = args.n.split(':', 1)
    try:
        socket.inet_aton(dest_addr[0])
    except socket.error:
        exit('Invalid IP address')

    try:
        if not dest_addr[1].isnumeric() or int(dest_addr[1]) > 65535:
            raise ValueError
    except (ValueError, IndexError):
        print(dest_addr[1])
        exit('Invalid port number')

    path = args.f.split('//', 1)
    if path[0] != 'fsp:':
        exit('Invalid protocol')
    dest_path = path[1].split('/', 1)

    try:
        reg=compile('^[\w\.\-]+$')
        if reg.match(dest_path[0]) == False:
            raise ValueError
    except ValueError:
        exit('Nameserver contains unexpected symbols')

    return dest_addr[0], int(dest_addr[1]), dest_path[0], dest_path[1]


def parse_index_file(index):
    files = index.split('\r\n\r\n', 1)
    return files[1].split('\r\n')


def put_in_dir(MKDIR):
    if MKDIR:
        curr_dir = getcwd()
        try:
            mkdir(f'{curr_dir}/tmpdir', 0o777)
        except FileExistsError:
            pass

    if isdir(f'{getcwd()}/tmpdir'):
        chdir('tmpdir')


def get_socket(server_ip, port_num, l4_flag):
    sock = None
    for res in socket.getaddrinfo(server_ip, port_num, socket.AF_UNSPEC, l4_flag):
        addr_family, socktype, proto, _, sock_addr = res
        try:
            sock = socket.socket(addr_family, socktype, proto)
        except OSError:
            sock = None
            continue

        try:
            sock.connect(sock_addr)
        except OSError:
            sock.close()
            sock = None
            continue
        break

    if sock is None:
        exit('Could not open socket')
    else:
        return sock


def udp_socket(server_ip, port_num, server_name):
    s = get_socket(server_ip, port_num, socket.SOCK_DGRAM)

    msg = f'WHEREIS {server_name}\r\n\r\n'

    with s:
        s.sendall(msg.encode())
        try:
            data = s.recv(1024)
        except ConnectionRefusedError:
            exit('Connection refused')
        s.close()

    response = data.decode().split(' ')
    if response[0] == "OK":
        new_ip = (response[1].split(":"))[0] 
        new_port = (response[1].split(":"))[1]
        return new_ip, int(new_port)
    else:
        exit(data.decode())


def communicate_with_server(s, msg):
    response = b''
    with s:
        s.sendall(msg.encode())
        while True:
            try:
                data = s.recv(1024)
            except ConnectionRefusedError:
                exit('Connection refused')
            if not data:
                break
            response += data
        s.close()
    return response


def tcp_socket(server_ip, port_num, server_name, path, GET_ALL, MKDIR=True):
    s = get_socket(server_ip, port_num, socket.SOCK_STREAM)

    msg = f'GET {path} FSP/1.0\r\nHostname: {server_name}\r\nAgent: xcaras00\r\n\r\n'
    response = communicate_with_server(s, msg)

    put_in_dir(MKDIR)
    if path == 'index' and GET_ALL:
        server_files = parse_index_file(response.decode())
        for filename in server_files:
            if filename == '':
                break
            tcp_socket(server_ip, port_num, server_name, filename, GET_ALL, MKDIR=False)

    file_contents = response.split(b'\r\n\r\n', 1)
    num_of_bytes = (file_contents[0].split(b':'))[1]

    if (file_contents[0].split(b' '))[1][:7] != b'Success':
        exit(file_contents[1].decode())

    path = path.split('/')[-1]

    f = open(path, 'wb')
    f.write(file_contents[1])
    f.close()


def __main__():
    server_ip, port_num, server_name, path = parse_arguments()
    new_server_ip, new_port_num = udp_socket(server_ip, port_num, server_name)
    GET_ALL = False
    if path == '*':
        path = 'index'
        GET_ALL = True
    tcp_socket(new_server_ip, new_port_num, server_name, path, GET_ALL)


__main__()
