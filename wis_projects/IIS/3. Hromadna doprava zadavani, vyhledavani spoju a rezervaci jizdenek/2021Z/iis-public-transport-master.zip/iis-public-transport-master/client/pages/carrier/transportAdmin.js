import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, Button, Select, Table, Space, Typography} from 'antd';
const { Option } = Select;
const { Text } = Typography;
const { Column, ColumnGroup } = Table;
import AdminHeader from '../../components/header/forms/adminHeader';
import styles from '../../styles/index.module.scss';
import staffStyles from '../../styles/staff.module.scss';
import carrierStyles from '../../styles/carrier.module.scss';

class CarrierPage extends React.Component {
    dataSource = [
    {
        key: '1',
        model: 'BUS123',
        lpn: 'gfdgd45h',
        description: '10 Downing Street',
        seats: 50,
    },
    {
        model: 'BUS 466',
        lpn: 'c xx 45h',
        description: '10 hes Downing Street',
        seats: 45,
    },
    ];

    columns = [
    {
        title: 'Model',
        dataIndex: 'model',
        key: 'model',
    },
    {
        title: 'Licence plate number',
        dataIndex: 'lpn',
        key: 'lpn',
    },
    {
        title: 'Description',
        dataIndex: 'description',
        key: 'description',
    },
    {
        title: 'Number of seats',
        dataIndex: 'seats',
        key: 'seats',
    },
    ];

    constructor(props) {
        super(props);
        this.state = {}
    }

    handleFinish = (data) => {
        console.log('This is my data!!!', data)
        
        // sendToServer(data).then(
        //     (res) => {

        //     },
        //     (err) => {

        //     }
        // )
    }

    render() {

        return (
            <div>
                <Head>
                    <title>Transport</title>
                </Head>
		        <Header style={{padding: '0',}}>
                	<AdminHeader/>
		        </Header>  
                
                
                <Row align='center' className={styles.centerdBlock}>
                    <Col>
                        <Row align='center' style={{padding: '0 0 2em 0'}}>
                            <Button href="/carrier/newVehicle" type='primary' size='large' htmlType='submit'>ADD NEW VEHICLE</Button>
                        </Row>
                        <Row>
                            <Table dataSource={this.dataSource}>
                                <Column title="Model" dataIndex="model" key="model" />
                                <Column title="Licence Plate Number" dataIndex="lpn" key="lpn" />
                                <Column title="Description" dataIndex="description" key="description" />
                                <Column title="Number of seats" dataIndex="seats" key="seats" />
                                <Column title="Action" key="action"
                                    render={() => (
                                        <Space size="middle">
                                        <a>Edit</a>
                                        <a>Delete</a>
                                        </Space>
                                    )}
                                />
                            </Table>
                        </Row>
                    </Col>
                </Row>
            </div>
        )
    }
}



const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (CarrierPage);