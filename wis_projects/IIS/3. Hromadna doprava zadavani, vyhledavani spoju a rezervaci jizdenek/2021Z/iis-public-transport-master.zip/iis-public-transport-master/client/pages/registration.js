
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import Calendar from 'react-calendar';

import Router from 'next/router';
import Link from "next/link"; 
import axios from 'axios';
// import { applyAuthTokenInterceptor } from 'axios-jwt';

import {Button, Row, Col, Form, Input, Avatar, Select, Checkbox} from 'antd'; 
import {UserOutlined} from '@ant-design/icons';
const {Option} = Select;

import styles from '../styles/index.module.scss' // Styles 
import MenuItem from "antd/lib/menu/MenuItem";
import { message } from 'antd';


const prefixSelector = (
    <Form.Item name="prefix" noStyle>
      <Select style={{ width: 70 }}>
        <Option value="+420">+420</Option>
      </Select>
    </Form.Item>
  );


class IndexPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userToken: null,
        }
    }

    handleFinish = (data) => {
        data.phone_number = data.prefix + data.phone_number
        data.role = "USER";
        console.log('This is my data!!!', data)
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/user/registration",
            data: data
        })
            .then(res => {
                    // const accessToken = response.data.accessToken;
                    // const refreshToken = response.data.refreshToken; // new

                    // storeAccessTokenInLocalStorage(accessToken);
                    // storeRefreshTokenInLocalStorage(refreshToken);   // new
                    Router.push('/');
                    }
                    
                )
            .catch(err => message.info(err.message))
    }

    render() {
        return (
            <div>
                <Head>
                    <title>Sign-up</title>
                </Head>     
                
                <Row align='center' style={{marginTop: '128px'}}>
                  
                    <Col align='center' xs={22} sm={11} md={10} lg={7} xl={6} xxl={6}>
                        <Form onFinish={this.handleFinish}
                            scrollToFirstError='True'
                            className={styles.forms} >
                            <Form.Item name="name">

                                <Input placeholder='Name' required
                                    className={styles.forms}
                                    size='large'/>                    
                            </Form.Item>
                            {/* <Form.Item name="surname">
                                <Input placeholder='Surname' className={styles.forms} size='large'/>                      
                            </Form.Item> */}
                            <Form.Item name="password">
                                <Input.Password placeholder='Password' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="phone_number">
                                <Input addonBefore={prefixSelector}
                                placeholder='Phone'className={styles.forms} size='large'/>
                            </Form.Item>
                            <Form.Item name="email">
                                <Input placeholder='E-mail' required
                                    type="email" className={styles.forms} size='large'/>
                            </Form.Item>
                            {/* <Link href='/index'> */}
                            <div align='center'>
                                <Button type='primary' size='large' htmlType='submit' className={styles.buttonLog}> Register </Button>
                            </div>

                        </Form>
                    </Col>
                </Row> 

            </div>
        )
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (IndexPage);
