const ApiError = require('../error/api_error')
const {Ride, Connection, Station} = require('../models/models')

function calcCrow(lat1, lat2, lon1, lon2) {
    var R = 6371
    var dLat = toRad(lat2-lat1)
    var dLon = toRad(lon2-lon1)
    var lat1 = toRad(lat1)
    var lat2 = toRad(lat2)
  
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2);
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    var d = R * c
    d = Math.round(d%10)
    return d.toString()
}
  
function toRad(Value) {
    return Value * Math.PI / 180
}

class RideController {
    async search(req, res, next) {
        const {date, station_from, station_to} = req.body
        if (!date || !station_from || !station_to) {
            return next(ApiError.bad_request('essential data for search are missing'))
        }
        console.log("SEARCH INPUT: ", station_from, station_to)
        const d = new Date(date)
        const week_day = d.getDay()
        const connection = await Connection.findAll({where: {week_day}})
        var found_connections = []
        for (let found_connection_order = 0; found_connection_order < connection.length; found_connection_order++) {
            const st_from_id = await Station.findOne({where : {id : station_from}})
            const st_from = await Ride.findOne({where: {connectionId : connection[found_connection_order].id, stationId : st_from_id.id}})
            const st_to_id = await Station.findOne({where : {id : station_to}})
            const st_to = await Ride.findOne({where: {connectionId : connection[found_connection_order].id, stationId : st_to_id.id}})

            if ((!!st_from && !!st_to) && (st_from.order_number < st_to.order_number)) {
                var found_connection = []
                for (let st_order = st_from.order_number; st_order <= st_to.order_number; st_order++) {
                    console.log(connection[found_connection_order].id, st_order)
                    var found = await Ride.findOne({where: {connectionId : connection[found_connection_order].id, order_number : st_order}})
                    var stations = await Station.findOne({where: {id : found.stationId}})
                    found_connection.push({station : found, station_name : stations.label, stationId: stations.id})
                }
                const ticket_price = calcCrow(parseFloat(st_from_id.latitude), parseFloat(st_to_id.latitude),
                                               parseFloat(st_from_id.longtitude), parseFloat(st_to_id.longtitude))
                found_connections.push({route : found_connection, carrier : connection[0].carrier, price : ticket_price})
            }
        }
        console.log("FOUND:")
        console.log(found_connections)
        console.log("--------------")
        if (found_connections.length == 0) {
            return next(ApiError.bad_request('connections was not found'))
        }
        return res.json(found_connections)
    }

    async add_new(req, res, next) {
        const {id, stations} = req.body
        if (!id || !stations) {
            return next(ApiError.bad_request('required ride info was not found'))
        }
        for (let station = 0; station < stations.length; station++) {
            var date_array = stations[station].arrival_time.split("T");
            var station_time = date_array[1].slice(0 ,8)
            console.log("name: ", stations[station].stationName, "  id: ", stations[station].stationId)
            var st_id
            if (/^\d+$/.test(stations[station].stationName)) {
                st_id = Number(stations[station].stationName)
            } else {
                st_id = stations[station].stationId
            }

            console.log({arrival_time: station_time,
                order_number: station,
                current_position: 0,
                stationId: st_id,
                connectionId: id})
            const station_to_connection = await Ride.create({arrival_time: station_time,
                                                            order_number: station+1,
                                                            current_position: 0,
                                                            stationId: st_id,
                                                            connectionId: id
                                                            })
        }
        return res.json(id)
    }

    async add_new_between(req, res, next) {
        const {connectionId, station_from, station_new,  arrival_time,} = req.body
        const rides = await Ride.findAll({where : {connectionId : connectionId}, order : [['order_number', 'ASC']]})
        const station_to_add = await Station.findOne({where: {station_new}})
        for (let order = 0; order < rides.length; order++) {
            if (rides[order].label === station_from) {
                const order_to_set = order++
            }    
            else if (rides[order].label > station_from) {
                const update_ride = await Ride.update({order_number : order+1}, {where: {connectionId : connectionId, id : rides[order].id}})
            }
        }
        const new_ride = await Ride.create({arrival_time : arrival_time, order_number : order_to_set, current_position : 0,
                                            stationId : station_to_add.id, connectionId : connectionId})
        return res.json(new_ride)
    }

    async delite(req, res, next) {
        const {id} = req.body
        if (!id) {
            return next(ApiError.bad_request('required ride info was not found'))
        }
        const candidate = await Ride.destroy({where: {connectionId : id}})
        return res.json(candidate)
    }
    
    async change_current_pozition(req, res, next) {
        const {connectionId, stationId} = req.body
        if (!connectionId || !stationId) {
            return next(ApiError.bad_request('required ride info was not found'))
        } 
        const reset_pozitions = await Ride.update({current_position: 0}, {where: {connectionId}})
        const change_pozition = await Ride.update({current_position: 1}, {where: {connectionId: connectionId, stationId: stationId}})
        return res.json(change_pozition)
    }

    async list_all(req, res, next) {
        const ride = await Ride.findAll()
        console.log(ride)
        return res.json(ride)
    }

    async get_connection(req, res, next) {
        const {connectionId} = req.body
        console.log(connectionId)
        if (!connectionId) {
            return next(ApiError.bad_request('required ride info was not found'))
        }
        const rides = await Ride.findAll({where : {connectionId : connectionId}, order : [['order_number', 'ASC']]})
        var result = []
        if (rides == null ||  rides.length == 0) {
            return res.json("null")
        }
        for (let ind = 0; ind < rides.length; ind++) {
            console.log("lllll ", connectionId, rides[ind].dataValues.stationId, " lllll")
            var current_station = await Station.findOne({where: {id: rides[ind].dataValues.stationId}});
            result.push({arrival_time: rides[ind].arrival_time, current_position: rides[ind].dataValues.current_position, station: current_station.label, stationId: rides[ind].dataValues.stationId, city: current_station.city})
        }
        return res.json(result)
    }
}

module.exports = new RideController()