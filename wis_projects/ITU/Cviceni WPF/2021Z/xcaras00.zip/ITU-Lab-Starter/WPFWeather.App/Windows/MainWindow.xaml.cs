﻿using System.Windows;
using WPFWeather.App.Services;
using WPFWeather.App.ViewModels;

namespace WPFWeather.App.Windows
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            WeatherViewModel viewmodel = new WeatherViewModel(new WeatherDiskService());
            viewmodel.DownloadWeatherCommand.Execute(CitySelectComboBox.SelectedValue);
            DataContext = viewmodel;
        }

        private void CitySelectComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            
        }
    }
}