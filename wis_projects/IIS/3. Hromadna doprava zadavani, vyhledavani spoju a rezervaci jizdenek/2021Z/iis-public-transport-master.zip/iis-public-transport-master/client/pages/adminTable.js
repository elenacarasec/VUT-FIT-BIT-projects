import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import { Header } from "antd/lib/layout/layout";

import {Row, Col, Form, Table, Tag, Space } from 'antd'; 
import AdminHeader from '../components/header/forms/adminHeader'

import axios from 'axios';
import Router from 'next/router';

import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";

export default class AdminTable extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          loggedUser: 'loading',
          data : []
        }
        axios({
          method: "get",
          url: "https://iis-public-transport.herokuapp.com/api/station/list_proposed",
          // data: this.state.userCredentials
      })
          .then(res => {
            console.log(res.data)
            this.setState({data:res.data})
          }
                  // Router.push('/registered')
              )
          .catch(err => console.log(err));
    }

    componentDidMount = () => {
      let token = localStorage.getItem('authToken')
      if (token === null) {
          Router.push('/')
      } else {
          let user = jwt_decode(token)
          this.setState({loggedUser: user})
      }
  }

    handleApprove = (data) => {
      axios({
        method: "post",
        url: "https://iis-public-transport.herokuapp.com/api/station/approve",
        // data: this.state.userCredentials
        data: {
          id: data.id,
        }
      })
        .then(res => {
          console.log(res.data);
          this.setState({data:res.data});
          window.location.reload(false);
          message.info('Station was successfully aproved.', 3)
        }
            )
        .catch(err => console.log(err));
  
    }

    render() {
      const columns = [
        {
          title: 'ID',
          dataIndex: 'id',
          key: 'id',
          render: text => <a>{text}</a>,
        },
        {
          title: 'Title',
          dataIndex: 'label',
          key: 'label',
        },

        {
          title: 'City',
          dataIndex: 'city',
          key: 'city',
        },
    
        {
            title: 'Geolocation latitude',
            dataIndex: 'latitude',
            key: 'latitude',
          },
        {
          title: 'Geolocation longtitude',
          dataIndex: 'longtitude',
          key: 'longtitude',
        },
          {
            title: 'Approve',
            key: 'Approve',
            render: (text, record) => (
              <Space size="middle">
                <a onClick={() => {this.handleApprove(record)}}>Approve</a>
              </Space>
            ),
          },
    
      ];
      if (this.state.loggedUser === 'loading') {
        return (
            <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                <LoadingOutlined/>
            </div>
        )
    } else if (this.state.loggedUser && this.state.loggedUser.role === 'ADMIN') {
        return (
          <>
          {this.state.data.length > 0 ?
            <div>
                <Head>
                    <title>Admin</title>
                </Head>     
                
                <Header style={{padding: '0'}}>
                    <AdminHeader/>
                </Header>
                <Row  style={{marginTop: '18em'}}>
                <Col xs={0} sm={1} md={3} lg={4} xl={4}>
                </Col>
                    <Col align='right' xs={0} sm={6} md={14} lg={15} xl={15}>
                    <Table columns={columns} dataSource={this.state.data} />
                    </Col>
                </Row> 

            </div>
            : null
          }
          </>
        ) }
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'ADMIN')) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
