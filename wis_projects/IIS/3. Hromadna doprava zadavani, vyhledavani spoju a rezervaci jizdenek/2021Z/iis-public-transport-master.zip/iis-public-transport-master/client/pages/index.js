
import React from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import LoginForm from "../components/header/forms/loginForm";
import FindRoute from "../components/header/forms/findRoute";
import {Row, Col, Divider} from 'antd'; 

import styles from '../styles/index.module.scss' // Styles 



class IndexPage extends React.Component {
    render() {
        return (
            <div>
                <Head>
                    <title>Transport</title>
                </Head>     
                
                <Row align='center' style={{marginTop: '128px'}}>
                    <Col align='center' xs={22} sm={11} md={10} lg={7} xl={8} xxl={8}>
                        <h2>
                            Find your route
                        </h2>
                        <Divider/>
                        <FindRoute {...this.props} type={'admin'}/>                        
                    </Col>                    <>
                    <Col xs={0} sm={1} md={2} lg={4} xl={6}>
                    </Col>

                    <Col align='center' xs={22} sm={11} md={8} lg={6} xl={5} xxl={4} >
                        <div className={styles.centerdBlock}>
                            <LoginForm {...this.props}/>
                        </div>
                    </Col>
                    </>
                </Row>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (IndexPage);
