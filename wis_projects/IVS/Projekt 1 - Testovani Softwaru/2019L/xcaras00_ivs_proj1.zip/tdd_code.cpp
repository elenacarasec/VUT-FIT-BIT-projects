//======== Copyright (c) 2020, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Test Driven Development - priority queue code
//
// $NoKeywords: $ivs_project_1 $tdd_code.cpp
// $Author:     Elena Carasec <xcaras00@stud.fit.vutbr.cz>
// $Date:       $2020-02-29
//============================================================================//
/**
 * @file tdd_code.cpp
 * @author Elena Carasec
 * 
 * @brief Implementace metod tridy prioritni fronty.
 */

#include <stdlib.h>
#include <stdio.h>

#include "tdd_code.h"

PriorityQueue::PriorityQueue()
{
    root = NULL;
}

PriorityQueue::~PriorityQueue()
{
    Element_t *tmp = new Element_t();
    while (root != NULL){
        tmp = root->pNext;
        delete root;
        root = tmp;
    }
    delete tmp;
}

void PriorityQueue::Insert(int value)
{
    Element_t *node = new Element_t();
    node->value = value;
    node->pPrev = NULL;
    node->pNext = NULL;

    root = GetHead();

    if (root == NULL){
        root = node;
    }
    else{
        Element_t *tmp = new Element_t();
        tmp = GetHead();

        if (value <= tmp->value){

            //Inserting node in the beginning of the list
            node->pNext = tmp;
            tmp->pPrev = node;
            root = node;
        }
        else{
            while (value > tmp->value && tmp->pNext != NULL){
                tmp = tmp->pNext;
            }
            if (value <= tmp->value || tmp->pNext != NULL){
                //Inserting node in the middle of the list
                node->pNext = tmp;
                node->pPrev = tmp->pPrev;
                tmp->pPrev->pNext = node;
                tmp->pPrev = node;
            }
            else{
                //Inserting node in the end of the list
                tmp->pNext = node;
                node->pPrev = tmp;
            }
        }
    }    
    return;
}


bool PriorityQueue::Remove(int value)
{
    Element_t *tmp = new Element_t();
    tmp = Find(value);
    root = GetHead();

    if (tmp != NULL){
        if(tmp == root){
            //Deleting first node
            root = root->pNext;
            if(root != NULL){
                root->pPrev = NULL;
            }
        }
        else if(tmp->pNext != NULL){
            //Deleting node from the middle
            tmp->pNext->pPrev = tmp->pPrev;
            tmp->pPrev->pNext = tmp->pNext;
        }
        else{
            //Deleting last node
            tmp->pPrev->pNext = NULL;
        }
        delete tmp;
        return true;
    }
    return false;
}

PriorityQueue::Element_t *PriorityQueue::Find(int value)
{
    Element_t *tmp = new Element_t();
    tmp = GetHead();
    while(tmp != NULL){
        if(tmp->value == value){
            return tmp;
        }
        tmp = tmp->pNext;
    
    }
    return NULL;
}

PriorityQueue::Element_t *PriorityQueue::GetHead()
{
    return root;
}

/*** Konec souboru tdd_code.cpp ***/
