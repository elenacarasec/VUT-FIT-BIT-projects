
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import { Header } from "antd/lib/layout/layout";
import axios from 'axios';
import Router from 'next/router'  

import {Button, Row, Col, Form, Input, Avatar, Select, Checkbox} from 'antd'; 
const {Option} = Select;

import CarrierHeader from '../../components/header/carrier_header';
import AdminHeader from '../../components/header/forms/adminHeader'
import StaffHeader from '../../components/header/staff_header';
import styles from '../../styles/index.module.scss' // Styles 

import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";

class IndexPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            customer: {
                id:this.props.id,
                label: this.props.label,
                city: this.props.city,
                longtitude: this.props.longtitude,
                latitude: this.props.latitude,
                proposed: 1
            },
            userToken: null,
            loggedUser: 'loading',
        }
        
    }

    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user})
        }
    }

    static async getInitialProps({query}) {
        let id = query.id
        let label = query.label
        let city = query.city
        let longtitude = query.longtitude
        let latitude = query.latitude
        

        return {id,label, city, longtitude, latitude}
    }

    handleFinish = (data) => {
        console.log('This is my data!!!', data)
    }

    handleSend = (data) => {
        console.log('This is my data!!!', data);
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/station/update",
            data: data
        })
            .then(res => 
                    Router.push('/carrier/stationTable')
                )
            .catch(err => console.log(err));
    }

    handleDelete = (data) => {
        console.log('This is my data!!!', data);
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/station/delite",
            data: data
        })
            .then(res => 
                    Router.push('/carrier/stationTable')
                )
            .catch(err => console.log(err));
    }

    render() {
        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && (this.state.loggedUser.role === 'CARRIER' || this.state.loggedUser.role === 'ADMIN' )) {
        return (
            <div>
                <Head>
                    <title>Sign-up</title>
                </Head>     
                <Header style={{padding: '0'}}>
                {this.state.loggedUser.role === 'CARRIER' ?
                     <CarrierHeader/>
                     : <AdminHeader/>
                  }
                </Header>
                <Row align='center' style={{marginTop: '128px'}}>
                  
                    <Col align='center' xs={22} sm={11} md={10} lg={7} xl={6} xxl={6}>
                        <Form onFinish={this.handleSend} className={styles.forms}
                            initialValues = {{
                                'id':this.props.id,
                                'label': this.props.label,
                                'city': this.props.city,
                                'longtitude': this.props.longtitude,
                                'latitude': this.props.latitude,

                            }}
                        >
                        <Form.Item name="label">
                                <Input placeholder='Title'  
                                 className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="city">
                                <Input placeholder='City'
                                 className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="longtitude">
                                <Input placeholder='Geolocation longtitude'
                                className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="latitude">
                                <Input placeholder='Geolocation latitude'
                                  className={styles.forms} size='large'/>
                            </Form.Item>
                            <Form.Item >
                                <div  align='center'style={{marginTop:'10px'}} >
                                <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'40%'}}>SEND </Button>
                                </div>  
                            </Form.Item>        

                        </Form>
                        <Form onFinish={this.handleDelete} className={styles.forms}
                            initialValues = {{
                                'id':this.props.id,
                                'label': this.props.label,
                                'city': this.props.city,
                                'longtitude': this.props.longtitude,
                                'latitude': this.props.latitude,

                            }}>
                        <div  align='center'>
                                <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'40%'}}>DELETE STATION </Button>
                        </div> 
                        </Form>
                    </Col>
                </Row> 

            </div>
        ) }
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'CARRIER' && this.state.loggedUser.role !== 'ADMIN')) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (IndexPage);
