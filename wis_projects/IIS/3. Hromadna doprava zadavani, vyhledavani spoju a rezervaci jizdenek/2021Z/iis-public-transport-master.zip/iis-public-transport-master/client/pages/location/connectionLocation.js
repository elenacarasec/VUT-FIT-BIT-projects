
import React from "react";
import {connect} from "react-redux";
import {Row, Col, message} from 'antd';
import axios from 'axios';


import styles from '../../styles/index.module.scss' // Styles 
import {LoadingOutlined} from '@ant-design/icons';

import Router from "next/router"

import jwt_decode from "jwt-decode";

import ListOfRidesItem from "../../components/listrides/listOfRidesItem";

class ConnLocation extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loggedUser: 'loading',
            rides: 'loading',
        }
    }

    componentDidMount = () => { 
        let authToken = localStorage.getItem('authToken')
       
        if (authToken === null) {
            console.log("No token")
            Router.push('/')
            
            
        } else {
            console.log("TOKEN ", authToken)
            let myuser = jwt_decode(authToken)
            

            this.setState({loggedUser: myuser})
            console.log("user: ", myuser)
            console.log("logged user", this.state.loggedUser)

            axios({
                method: "GET",
                url: "https://iis-public-transport.herokuapp.com/api/connection/list_all",
                headers: {
                    'Authorization': 'Bearer ' + authToken
                }
            })
            .then (
                res => {
                    console.log('rides res is', res.data)
                    this.setState({rides: res.data})
                },
            )
            .catch ( err => {
                    // Connection NOT FOUND
                    console.log('res2 is', err)
                    message.error(err, 3)
                    this.setState({rides: 'error'})
                }
            )
        }
    }

    render() {
        return (
            <div style={{paddingTop: '2em'}}>
                <Row align='center'>
                    <Col xl={10} xxl={8}>
                        <h2>
                            Current rides
                        </h2>
                        {!(this.state.loggedUser === 'loading' || this.state.rides === 'loading') ? 
                        this.state.rides.map(el => {
                            return (
                                <div key={el.createdAt}>
                                    <ListOfRidesItem loggedUser={this.state.loggedUser} item={el}/>
                                </div>
                            )
                        })
                        :
                        <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                            <LoadingOutlined/>
                        </div>
                        }
                    </Col>
                </Row>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (ConnLocation);
