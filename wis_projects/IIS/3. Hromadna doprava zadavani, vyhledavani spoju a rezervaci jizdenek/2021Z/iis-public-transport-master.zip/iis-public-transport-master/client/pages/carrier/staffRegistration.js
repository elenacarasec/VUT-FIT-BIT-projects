
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import Link from "next/link"; 
import axios from 'axios';

import styles from '../../styles/index.module.scss' // Styles 
import MenuItem from "antd/lib/menu/MenuItem";
const {Option} = Select;
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, Input, Select, Button, Space, Typography} from 'antd';
import CarrierHeader from '../../components/header/carrier_header';

import Router from "next/router";
import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";

const prefixSelector = (
    <Form.Item name="prefix" noStyle>
      <Select style={{ width: 70 }}>
        <Option value="420">+420</Option>
      </Select>
    </Form.Item>
  );

class CarrierPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userToken: null,
            loggedUser: "loading",
        }
    }

    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user})
        }
    }

    handleFinish = (data) => {
        data.role = "STAFF"
        data.company = loggedUser.name
        console.log('This is my data!!!', data)
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/user/registration",
            data: data
        })
            .then(res => 
                    Router.push('/carrier/staff')
                )
            .catch(err => alert("This e-mail is already used"));
    
    }

    render() {
        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && this.state.loggedUser.role === 'CARRIER') {


        return (
            <div>
                <Head>
                    <title>Carrier</title>
                </Head>     
                <Header style={{padding: '0'}}>
                    <CarrierHeader/>
                </Header>
                <Row align='center' style={{marginTop: '128px'}}>
                  
                    <Col align='center' xs={22} sm={11} md={10} lg={7} xl={6} xxl={6}>
                        <Form onFinish={this.handleFinish}
                            scrollToFirstError='True'
                            className={styles.forms} >
                            <Form.Item name="name">

                                <Input placeholder='Name' required
                                    className={styles.forms}
                                    size='large'/>                      
                            </Form.Item>
                            <Form.Item name="password">
                                <Input.Password placeholder='Password' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="phone_number">
                                <Input addonBefore={prefixSelector}
                                placeholder='Phone'className={styles.forms} size='large'/>
                            </Form.Item>
                            <Form.Item name="email">
                                <Input placeholder='E-mail' required
                                    type="email" className={styles.forms} size='large'/>
                            </Form.Item>
                            <div align='center'>
                                <Button type='primary' size='large' htmlType='submit' className={styles.buttonLog}> Register </Button>
                            </div>
                        </Form>
                    </Col>
                </Row> 

            </div>
        )}
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'CARRIER')) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (CarrierPage);

