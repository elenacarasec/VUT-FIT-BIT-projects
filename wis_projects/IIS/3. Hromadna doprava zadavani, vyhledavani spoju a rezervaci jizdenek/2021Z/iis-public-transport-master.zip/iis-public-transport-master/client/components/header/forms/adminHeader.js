
import React from "react";

import {Row, Col, Menu, Dropdown} from 'antd'; 
import Router from 'next/router';
import styles from '../header.module.scss'

export default class Header extends React.Component {
    constructor(props) {
        super(props);
        this.state = {}
    }


    handleLogout = () => {
        localStorage.removeItem('authToken')
        Router.push('/')
    }

    render() {
        return (   
            <Row align='center' gutter={[0, 5]} style={{ position: "relative"}}>
                <Col align='center' onClick={() => {Router.push('/')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={5} xs={24}>
					HOME 
				</Col>
                <Col align='center' className={styles.headerButtonsCol} sm={5} xs={24}>
                    <Dropdown overlay={
                        <Menu className={styles.dropDown}>
                            <Menu.Item className={styles.menuItem} onClick={() => {Router.push('/adminTable')}} key="1"> Stations</Menu.Item>
                            <Menu.Item className={styles.menuItem} onClick={() => {Router.push('/adminAddAcc')}} key="2">User accounts</Menu.Item>
                        </Menu>}>
                        <div style={{color: 'white'}} onClick={() => {Router.push('/admin')}}>
                            ADMIN
                        </div>
                    </Dropdown>
                </Col>
                <Col align='center' className={styles.headerButtonsCol} sm={5} xs={24}>
                    <Dropdown overlay={
                        <Menu className={styles.dropDown}>
                            <Menu.Item className={styles.menuItem} key="1T" onClick={() => {Router.push('/staff/ticketsList')}}>Tickets</Menu.Item>
                            <Menu.Item className={styles.menuItem} key="3O" onClick={() => {Router.push('/location/connectionLocation')}}>Connections</Menu.Item>
                        </Menu>}>
                        <div style={{color: 'white'}}>
                            STAFF
                        </div>
                    </Dropdown>
                </Col>
                <Col align='center' className={styles.headerButtonsCol} sm={5} xs={24}>
                    <Dropdown overlay={
                        <Menu className={styles.dropDown}>
                            <Menu.Item className={styles.menuItem} key="1z" onClick={() => {Router.push('/carrier/connectionList')}}>Connections</Menu.Item>
                            <Menu.Item className={styles.menuItem} key="2z" onClick={() => {Router.push('/carrier/stationTable')}}> Stations</Menu.Item>
                            <Menu.Item className={styles.menuItem} key="3z" onClick={() => {Router.push('/carrier/vehicle')}}>Transport</Menu.Item>
                            {/* <Menu.Item className={styles.menuItem} key="4z" onClick={() => {Router.push('/staff/staffAdmin')}} key="4">Staff accounts</Menu.Item> */}
                            </Menu>}>
                    <div style={{color: 'white'}}>
                        CARRIER
                    </div>
                    </Dropdown>
                </Col>
                <Col onClick={this.handleLogout} align='center' className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24} style={{borderRight: 'none'}}>
                    LOGOUT
                </Col>
            </Row>
        )
    }
}




