
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import { Header } from "antd/lib/layout/layout";
import Link from "next/link"; 
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';

import {Row, Col, Form, Input, Select,Button, Table, Tag, Space } from 'antd'; 
import StaffHeader from '../../components/header/staff_header';
import MenuItem from "antd/lib/menu/MenuItem";
import styles from '../../styles/index.module.scss';
const { Option } = Select;
import Router from 'next/router' 
import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";

  const stations = [
    {station_name: 'Brno Hl N', station: {id: 1}},
    {station_name: 'Brno Zidenice', station: {id: 2}},
    {station_name: 'Praha Hl N', station: {id: 3}},
]

class IndexPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          loggedUser: 'loading'
        }
    }

    componentDidMount = () => {
      let token = localStorage.getItem('authToken')
      if (token === null) {
          Router.push('/')
      } else {
          let user = jwt_decode(token)
          this.setState({loggedUser: user})
      }
  }

    onFinish = values => {
      console.log('Received values of form:', values);
    };
  
    handleChange = () => {
      form.setFieldsValue({ sights: [] });
    };

    render() {
      if (this.state.loggedUser === 'loading') {
        return (
            <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                <LoadingOutlined/>
            </div>
        )
    } else if (this.state.loggedUser && this.state.loggedUser.role === 'STAFF') {
        return (
          <div>                 <Head>
          <title>Admin</title>
      </Head>     
      
      <Header style={{padding: '0'}}>
          <StaffHeader/>
      </Header>
            <div align='center' style={{marginTop: '4em'}}>
              
            <div style={{maxWidth: '500px'}}>
            <Form onFinish={this.onFinish} autoComplete="off" >
              <Form.List name="passengers">
                        {(fields, { add, remove }) => (
                        <>
                        {fields.map(({ key, name, fieldKey, ...restField }) => (

                        <div key={key} style={{ textAlign: 'left', display: 'block', marginBottom: 8, position: 'relative' }} align="baseline">
                            <Form.Item
                                {...restField}
                                name={[name, 'stationId']}
                                fieldKey={[fieldKey, 'stationId']}
                                rules={[{ required: true, message: 'Choose station' }]}
                                style={{ width: '50%', display: 'inline-block'}}
                                className={styles.forms}
                                >
                                    <Select showSearch size='large' placeholder={
                                        <span>
                                            
                                        </span>}
                                    style={{padding: 0}}
                                    className={styles.forms}
                                    optionFilterProp="children"
                                    
                                    >
                                        {stations && stations.map((el, key) => {
                                          return(
                                            <Option key={key} value={el.station.id}>{el.station_name}</Option>
                                          )
                                        })}
                                    </Select>
                            </Form.Item>
                            <Form.Item
                                {...restField}
                                name={[name, 'arrival_time']}
                                fieldKey={[fieldKey, 'arrival_time']}
                                rules={[{ required: true, message: 'Insert time' }]}
                                style={{ width: '40%', float: 'right', display: 'inline-block'}}
                                >
                                    <Input className={styles.forms} placeholder='hh:mm:ss' size='large'>
                                    </Input>
                            </Form.Item>
                            {fields.length > 2 &&
                            <MinusCircleOutlined style={{position: 'absolute', right: '-10%', top: '7%',  fontSize: '2.2em'}} onClick={() => remove(name)} />}
                        </div>
                        ))}

                        <Form.Item>
                            <Button type="dashed" style={{width: '60%'}}disabled={fields.length >= 7} onClick={() => {fields.length < 7 ? add() : null}}>
                                Add Stop
                            </Button>
                        </Form.Item>
                        </>
                        )}
                    </Form.List>
              <Form.Item>
                <Button type="primary" style={{width: '50%'}} htmlType="submit">
                  Submit
                </Button>
              </Form.Item>
            </Form>
            </div>
            </div>
            </div>
          ); }
          else if ((this.state.loggedUser && this.state.loggedUser.role !== 'STAFF')) {
              return (
                  <div align='center'>
                      You dont have enough priviligies to open this page
                  </div>
              )
          }
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (IndexPage);