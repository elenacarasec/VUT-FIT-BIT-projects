const Router = require('express')
const router = new Router()
const connection_controller = require('../controllers/connection')
const auth_middleware = require('../middleware/auth_middleware')

router.post('/add_new', connection_controller.add_new)
router.post('/delite', connection_controller.delite)
router.post('/update', connection_controller.update)
router.get('/list_all', connection_controller.list_all)

module.exports = router