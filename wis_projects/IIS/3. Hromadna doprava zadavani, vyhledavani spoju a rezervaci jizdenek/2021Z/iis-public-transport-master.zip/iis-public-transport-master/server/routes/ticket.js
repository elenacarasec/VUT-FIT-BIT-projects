const Router = require('express')
const router = new Router()
const ticket_controller = require('../controllers/ticket')
const auth_middleware = require('../middleware/auth_middleware')
const role_middleware = require('../middleware/role_middleware')


router.post('/create_ticket', role_middleware(['USER', 'ADMIN', 'CARRIER', 'STAFF']), ticket_controller.create_ticket)
router.post('/approve_reservation', ticket_controller.approve_reservation) 
router.post('/approve_purchase', ticket_controller.approve_purchase) 
router.post('/verify', ticket_controller.verify) 
router.post('/tickets_to_verify', ticket_controller.tickets_to_verify) 
router.get('/get_ticket_list', role_middleware(['USER', 'ADMIN', 'CARRIER', 'STAFF']), ticket_controller.get_ticket_list)
router.get('/tickets_to_approve_reservation', ticket_controller.tickets_to_approve_reservation) 
router.get('/list_all', ticket_controller.list_all)
module.exports = router