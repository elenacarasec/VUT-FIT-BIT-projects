const Router = require('express')
const user = require('./user')
const task = require('./task')
const achievement = require('./achievement')
const router = new Router()

router.use('/user', user)
router.use('/task', task)
router.use('/achievement', achievement)

module.exports = router