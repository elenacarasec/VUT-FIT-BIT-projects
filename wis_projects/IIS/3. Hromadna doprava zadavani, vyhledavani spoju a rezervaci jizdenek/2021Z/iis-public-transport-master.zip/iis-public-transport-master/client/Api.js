import axios from 'axios';

const URL = 'http://localhost:8000' // BackEnd address




// API class
export default class Api {
    constructor() {
       this.url = URL;
    }
    call({path, method, data}) {
            return axios({
                url: this.url + path,
                validateStatus: false,
                method: method,
                headers: {},
                json: true,
                data: data,
                withCredentials: true,
            }).then(result => {
                return result.data;
            }).catch (error => {
                console.log(error);
            }) ;
    }

}
