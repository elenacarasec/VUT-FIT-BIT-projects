import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, message, Select, Button, Typography} from 'antd';
const { Option } = Select;
const { Text } = Typography;
import CarrierHeader from '../../components/header/carrier_header';
import styles from '../../styles/index.module.scss';
import axios from 'axios';

import Router from "next/router";
import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";


class CarrierPage extends React.Component {
    constructor(props) {
        super(props);
            this.state = {loggedUser: "loading", connections: 'loading' }
    axios({
        method: "post",
        url: "https://iis-public-transport.herokuapp.com/api/user/list_staff",
        data: {role: "STAFF"}
    })
    .then(res => {
        this.setState({connections: res.data.map(el => el.email)})
    })
    .catch(err => message.info('No user found'))
}

    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user})
        }
    }

    handleFinish = (values) => {
        Router.push({pathname: "/carrier/staffEdition", query : {email:values.email}})
    }


    render() {
        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && this.state.loggedUser.role === 'CARRIER') {

        return (
            <div>
                <Head>
                    <title>Carrier</title>
                </Head>
		        <Header style={{padding: '0',}}>
                	<CarrierHeader/>
		        </Header>  
                
                <Row style={{paddingTop: '4em'}} align='center' className={styles.centerdBlock}>
                    <Col xs={22} sm={11} md={10} lg={5} xl={5} xxl={5}>
                        <Row>
                        <Form onFinish={this.handleFinish}    
                            scrollToFirstError='True'
                            className={styles.forms} >
                            {this.state.connections === 'loading' ?
                            <div align='center'>
                                <LoadingOutlined style={{fontSize: '2em'}}/>
                            </div>
                            :
                            <Form.Item name="email" style={{display: 'inline-block', width: '75%'}} size='large'>
                                <Select placeholder={' Staff email'} align='center' required optionFilterProp="children" size='large'>
                                    {this.state.connections.map(el => {
                                        return (
                                            <Option key={el} value={el}>{el}</Option>
                                        )
                                    })}
                                </Select>
                            </Form.Item>
                            }
                            <Form.Item style={{ display: 'inline-block', float: 'right', marginLeft: '8em',width: '75%'}}>
                                <Button type='primary' size='large' htmlType='submit'>SEARCH </Button>
                            </Form.Item>
                        </Form>
                            
                        </Row>
                        <Row align='center' style={{  marginLeft: '1em',width: '59%'}}>
                            <Text strong>OR</Text>
                        </Row>
                        <Row align='left' style={{paddingTop: '2em'}}>
                            <Button href='/carrier/staffRegistration' style={{padding: '0 3em',width:"100%"}}  type='primary' size='large' htmlType='submit' className={styles.button}>
                                CREATE NEW STAFF ACCOUNT
                            </Button>  
                        </Row>
                        
                    </Col>
			        
                </Row>
            </div>
        )}
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'CARRIER')) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}



const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (CarrierPage);