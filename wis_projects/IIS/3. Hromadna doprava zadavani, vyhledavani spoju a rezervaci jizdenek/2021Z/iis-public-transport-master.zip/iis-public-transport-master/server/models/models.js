const sequelize = require('../db')
const {DataTypes} = require('sequelize')

const User = sequelize.define('user', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    role: {type: DataTypes.STRING, defaultValue: "USER"},
    email: {type: DataTypes.STRING, unique: true,},
    name: {type: DataTypes.STRING},
    phone_number: {type: DataTypes.STRING, unique: true,},
    password: {type: DataTypes.STRING},
    company: {type: DataTypes.STRING},
    age: {type: DataTypes.INTEGER},
})

const Ticket = sequelize.define('ticket', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    price_category: {type: DataTypes.STRING},
    from: {type: DataTypes.STRING},
    to: {type: DataTypes.STRING},
    reserved: {type: DataTypes.BOOLEAN, defaultValue: false},
    paid: {type: DataTypes.BOOLEAN, defaultValue: false},
    verified: {type: DataTypes.BOOLEAN, defaultValue: false},
    seat: {type: DataTypes.INTEGER},
    price: {type: DataTypes.INTEGER},
    email: {type: DataTypes.STRING},
})

const Vehicle = sequelize.define('vehicle', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    model: {type: DataTypes.STRING},
    description: {type: DataTypes.STRING},
    license_plate: {type: DataTypes.STRING},
    number: {type: DataTypes.INTEGER},
    number_of_seats: {type: DataTypes.INTEGER},
})

const Station = sequelize.define('station', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    label: {type: DataTypes.STRING},
    city: {type: DataTypes.STRING},
    longtitude: {type: DataTypes.STRING},
    latitude: {type: DataTypes.STRING},
    proposed: {type: DataTypes.BOOLEAN, defaultValue: false},
    approved: {type: DataTypes.BOOLEAN, defaultValue: false},
})

const Connection = sequelize.define('connection', {
    id: {type: DataTypes.STRING, primaryKey: true, unique: true,},
    week_day: {type: DataTypes.INTEGER},
    passengers: {type: DataTypes.INTEGER},
    description: {type: DataTypes.STRING},
    carrier: {type: DataTypes.STRING},
})

const Ride = sequelize.define('ride', {
    id: {type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
    arrival_time: {type: DataTypes.TIME},
    order_number: {type: DataTypes.INTEGER},
    current_position: {type: DataTypes.INTEGER, defaultValue: 0},
})

User.hasMany(Ticket)
Ticket.belongsTo(User)

Connection.hasMany(Ticket)
Ticket.belongsTo(Connection)

Connection.hasOne(Vehicle)
Vehicle.belongsTo(Connection)

Station.hasMany(Ride)
Ride.belongsTo(Station)

Connection.hasMany(Ride)
Ride.belongsTo(Connection)

module.exports = {
    User,
    Ticket,
    Vehicle,
    Station,
    Connection,
    Ride
}