isa_proto = Proto("isa_proto", "ISA-3 protocol")

--[[
    Return string length until the necessary symbol

    buffer: payload
    init_num:  start position
    length: length of buffer
    symb: stop symbol
--]]
function loop_over_string(buffer, init_num, length, symb)
    for i = init_num, length - 1, 1 do
        if (buffer(i,1):string() == symb) then
            return i - init_num
        end
    end
end

-- The dissector function
function isa_proto.dissector(buffer, pinfo, tree)
    local length = buffer:len()
    if length == 0 then return end

    pinfo.cols.protocol = isa_proto.name
    local f = isa_proto.fields

    local subtree = tree:add(isa_proto, buffer(), "ISA-3 Protocol")

    if (buffer(1,2):string() == "ok") then
        subtree:add(f.status, buffer(1,2))

        if (buffer(4,1):string() == "(") then
            if (buffer(5,1):string() == ")") then
                -- empty list
                return
            elseif (buffer(5,1):string() == "\"") then
                -- fetch response
                local login_start = 6
                local login_len = loop_over_string(buffer, login_start, length, "\"")
                subtree:add(f.msgfrom, buffer(login_start, login_len))

                local topic_start = login_start + login_len + 3
                local topic_len = loop_over_string(buffer, topic_start, length, "\"")
                subtree:add(f.topic, buffer(topic_start, topic_len))

                local msgbody_start = topic_start + topic_len + 3
                local msgbody_len = loop_over_string(buffer, msgbody_start, length, "\"")
                subtree:add(f.msgbody, buffer(msgbody_start, msgbody_len))
            else
                -- non-empty list
                local next_sym = 5
                while (next_sym < length and buffer(next_sym,1):string() ~= ")") do
                    local num_start = next_sym + 1
                    local num_end = loop_over_string(buffer, num_start, length, " ")
                    subtree:add(f.msgnumber, buffer(num_start, num_end))

                    local from_start = num_start + num_end + 2
                    local from_len = loop_over_string(buffer, from_start, length, "\"")
                    subtree:add(f.msgfrom, buffer(from_start, from_len))

                    local topic_start = from_start + from_len + 3
                    local topic_len = loop_over_string(buffer, topic_start, length, "\"")
                    subtree:add(f.topic, buffer(topic_start, topic_len))
                    next_sym = topic_start + topic_len + 3
                end
            end
        elseif (buffer(5,4):string() == "user") then
            local msgbody_start = 5
            local msgbody_len = loop_over_string(buffer, msgbody_start, length, "\"")
            subtree:add(f.msgbody, buffer(msgbody_start, msgbody_len))

            local login_token_start = msgbody_start + msgbody_len + 3
            local login_token_len = loop_over_string(buffer, login_token_start, length, "\"")
            subtree:add(f.login_token, buffer(login_token_start, login_token_len))
        else
            local msgbody_start = 5
            local msgbody_len = loop_over_string(buffer, msgbody_start, length, "\"")
            subtree:add(f.msgbody, buffer(msgbody_start, msgbody_len))
        end

    elseif (buffer(1,3):string() == "err") then
        subtree:add(f.status, buffer(1,3))

        local msgbody_start = 6
        local msgbody_len = loop_over_string(buffer, msgbody_start, length, "\"")
        subtree:add(f.msgbody, buffer(msgbody_start, msgbody_len))

    elseif (buffer(1,4):string() == "send") then
        subtree:add(f.status, buffer(1,4))
        local login_token_start = 7
        local login_token_len = loop_over_string(buffer, login_token_start, length, "\"")
        subtree:add(f.login_token, buffer(login_token_start, login_token_len))

        local login_start = login_token_start + login_token_len + 3
        local login_len = loop_over_string(buffer, login_start, length, "\"")
        subtree:add(f.recipient, buffer(login_start, login_len))

        local topic_start = login_start + login_len + 3
        local topic_len = loop_over_string(buffer, topic_start, length, "\"")
        subtree:add(f.topic, buffer(topic_start, topic_len))

        local msgbody_start = topic_start + topic_len + 3
        local msgbody_len = loop_over_string(buffer, msgbody_start, length, "\"")
        subtree:add(f.msgbody, buffer(msgbody_start, msgbody_len))

    elseif (buffer(1,5):string() == "login") then
        subtree:add(f.status, buffer(1,5))

        local login_start = 8
        local login_len = loop_over_string(buffer, login_start, length, "\"")
        subtree:add(f.login, buffer(login_start, login_len))

        local pwd_start = login_start + login_len + 3
        local pwd_len = loop_over_string(buffer, pwd_start, length, "\"")
        subtree:add(f.password, buffer(pwd_start, pwd_len))

    elseif (buffer(1,6):string() == "logout") then
        subtree:add(f.status, buffer(1,6))

        local login_start = 9
        local login_len = loop_over_string(buffer, login_start, length, "\"")
        subtree:add(f.msgbody, buffer(login_start, login_len))

    elseif (buffer(1,4):string() == "list")  then
        subtree:add(f.status, buffer(1,4))

        local login_start = 7
        local login_len = loop_over_string(buffer, login_start, length, "\"")
        subtree:add(f.login_token, buffer(login_start, login_len))

    elseif (buffer(1,5):string() == "fetch") then
        subtree:add(f.status, buffer(1,5))

        local login_token_start = 8
        local login_token_len = loop_over_string(buffer, login_token_start, length, "\"")
        subtree:add(f.login_token, buffer(login_token_start, login_token_len))

        local id_start = login_token_start + login_token_len + 2
        local id_len = loop_over_string(buffer, id_start, length, ")")
        subtree:add(f.id, buffer(id_start, id_len))

    elseif (buffer(1,8):string() == "register") then
        subtree:add(f.status, buffer(1,8))

        local login_start = 11
        local login_len = loop_over_string(buffer, login_start, length, "\"")
        subtree:add(f.login, buffer(login_start, login_len))

        local pwd_start = login_start + login_len + 3
        local pwd_len = loop_over_string(buffer, pwd_start, length, "\"")
        subtree:add(f.password, buffer(pwd_start, pwd_len))
    end

end

-- Create the protocol fields
local f = isa_proto.fields
f.status = ProtoField.string("isa_proto.status", "Status", base.ASCII)
f.login_token = ProtoField.string ("isa_proto.login_token", "Login Token", base.ASCII)
f.login = ProtoField.string ("isa_proto.login", "Login", base.ASCII)
f.password = ProtoField.string ("isa_proto.password", "Encrypted Password", base.ASCII)
f.topic = ProtoField.string ("isa_proto.topic", "Subject", base.ASCII)
f.msgbody = ProtoField.string ("isa_proto.msgbody", "Message body", base.ASCII)
f.msgnumber = ProtoField.string ("isa_proto.msgnumber", "Message number", base.ASCII)
f.msgfrom = ProtoField.string ("isa_proto.msgfrom", "Sender", base.ASCII)
f.recipient = ProtoField.string ("isa_proto.recipient", "Recipient", base.ASCII)
f.id = ProtoField.string ("isa_proto.id", "ID", base.ASCII)

isa_proto:register_heuristic("tcp", isa_proto.dissector)