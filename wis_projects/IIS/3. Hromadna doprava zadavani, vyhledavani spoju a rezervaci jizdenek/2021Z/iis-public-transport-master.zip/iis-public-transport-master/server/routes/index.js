const Router = require('express')
const user = require('./user')
const station = require('./station')
const vehicle = require('./vehicle')
const connection = require('./connection')
const ride = require('./ride')
const ticket = require('./ticket')
const router = new Router()

router.use('/user', user)
router.use('/station', station)
router.use('/vehicle', vehicle)
router.use('/connection', connection)
router.use('/ride', ride)
router.use('/ticket', ticket)

module.exports = router