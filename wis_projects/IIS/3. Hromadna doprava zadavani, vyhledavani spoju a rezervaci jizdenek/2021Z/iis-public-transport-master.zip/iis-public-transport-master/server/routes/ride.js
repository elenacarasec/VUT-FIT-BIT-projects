const Router = require('express')
const router = new Router()
const ride_controller = require('../controllers/ride')
const auth_middleware = require('../middleware/auth_middleware')
const role_middleware = require('../middleware/role_middleware')


router.post('/search', ride_controller.search)
router.post('/add_new', ride_controller.add_new)
router.post('/add_new_between', ride_controller.add_new_between)
router.post('/delite', ride_controller.delite)
router.post('/change_current_pozition', ride_controller.change_current_pozition) 
router.post('/get_connection', ride_controller.get_connection) 
router.get('/list_all', ride_controller.list_all)

module.exports = router