#include "proj2.h"

// Generating random number in interval <0..max_time>
int generate_random_number(int time_to_wait){
    srand(time(NULL));
    time_to_wait = (rand() % (time_to_wait + 1));
    return time_to_wait * 1000;
}

int create_semaphores(){
    judge_is_inside = sem_open("/judge_is_inside", O_CREAT | O_EXCL, sem_mode, unlocked);
    if (judge_is_inside == SEM_FAILED){
        fprintf(stderr, "Semaphore \"judge_is_inside\" was not created\n");
        return 1;
    }  
    write_to_file = sem_open("/writing", O_CREAT | O_EXCL, sem_mode, unlocked);
    if (write_to_file == SEM_FAILED){
        fprintf(stderr, "Semaphore \"write_to_file\" was not created\n");
        return 1;
    }   
    judge_waits_for_check_in = sem_open("/judge_waits", O_CREAT | O_EXCL, sem_mode, locked);
    if (judge_waits_for_check_in == SEM_FAILED){
        fprintf(stderr, "Semaphore \"judge_waits\" was not created\n");
        return 1;
    }  
    imm_wants_conf = sem_open("/imm_wants_conf", O_CREAT | O_EXCL, sem_mode, locked);
    if (imm_wants_conf == SEM_FAILED){
        fprintf(stderr, "Semaphore \"imm_wants_conf\" was not created\n");
        return 1;
    } 
    return 0;
}

// Clearing all the data about semaphores
int destroy_semaphores(){
    if (sem_close(judge_is_inside) != 0){
        fprintf(stderr, "Semaphore judge_is_inside was not closed\n");
        return 1;
    }
    if (sem_unlink("/judge_is_inside") != 0){
        fprintf(stderr, "Semaphore judge_is_inside was not unlinked\n");
        return 1;
    }
    if (sem_close(write_to_file) != 0){
        fprintf(stderr, "Semaphore write_to_file was not closed\n");
        return 1;
    }
    if (sem_unlink("/writing") != 0){
        fprintf(stderr, "Semaphore write_to_file was not unlinked\n");
        return 1;
    }
    if (sem_close(judge_waits_for_check_in) != 0){
        fprintf(stderr, "Semaphore judge_waits_for_check_in was not closed\n");
        return 1;
    }
    if (sem_unlink("/judge_waits") != 0){
        fprintf(stderr, "Semaphore judge_waits_for_check_in was not unlinked\n");
        return 1;
    }
    if (sem_close(imm_wants_conf) != 0){
        fprintf(stderr, "Semaphore imm_wants_conf was not closed\n");
        return 1;
    }
    if (sem_unlink("/imm_wants_conf") != 0){
        fprintf(stderr, "Semaphore imm_wants_conf was not unlinked\n");
        return 1;
    }
    return 0;
}

// Printing immigrants' and judge's actions to file
void print_to_file(char *action){
    if (!strcmp(data_out->NAME, "IMM")){
        if (!strcmp(action, "starts")){
            fprintf(f_out, "%-7d : %s %-5d : %-25s\n", data_out->A, data_out->NAME, data_out->I, action);
        }
        else{
            fprintf(f_out, "%-7d : %s %-5d : %-25s : %-3d : %-3d : %-3d\n", data_out->A, data_out->NAME, data_out->I, action, data_out->NE, data_out->NC, data_out->NB);
        }
    }
    else{
        if((!strcmp(action, "wants to enter") || (!strcmp(action, "finishes")))){
            fprintf(f_out, "%-7d : %-9s : %-25s\n", data_out->A, data_out->NAME, action);
        }
        else{
             fprintf(f_out, "%-7d : %-9s : %-25s : %-3d : %-3d : %-3d\n", data_out->A, data_out->NAME, action, data_out->NE, data_out->NC, data_out->NB);
        }
    }
    fflush(f_out);
}

// -------Beginning of the block with functions for immigrant's life cykle -----------
void immigrant_starts(int imm_id){
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "IMM";
    data_out->I = imm_id;
    print_to_file("starts");
    sem_post(write_to_file);
}

void immigrant_enters(int imm_id){
    sem_wait(judge_is_inside);
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "IMM";
    data_out->I = imm_id;
    data_out->NE++;
    data_out->NB++;
    print_to_file("enters");
    sem_post(write_to_file);
    sem_post(judge_is_inside);  
}

// All the immigrants have to register before the judge starts confirmation
void immigrant_registers(int imm_id){
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "IMM";
    data_out->I = imm_id;
    data_out->NC++;
    print_to_file("checks");

    if (data_out->NE == data_out->NC && data_out->judge_waits_checkin){
        sem_post(judge_waits_for_check_in);
    }
    sem_post(write_to_file);
}

// Immigrants are asking for confirmation and waiting for getting it
void immigrant_wants_confirmation(int imm_id){
    sem_wait(imm_wants_conf);
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "IMM";
    data_out->I = imm_id;
    print_to_file("wants certificate");
    sem_post(write_to_file);

    if(hall_problem->IT > 0){
        int time_to_wait = generate_random_number(hall_problem->IT);
        usleep(time_to_wait);
    }
}

void immigrant_gets_confirmation(int imm_id){
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "IMM";
    data_out->I = imm_id;
    print_to_file("got certificate");
    sem_post(write_to_file);
}

void immigrant_leaves(int imm_id){
    sem_wait(judge_is_inside);
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "IMM";
    data_out->I = imm_id;
    data_out->NB--;
    print_to_file("leaves");
    sem_post(write_to_file); 
    sem_post(judge_is_inside);
}
// -------End of the block with functions for immigrant's life cykle -----------


// -------Beginning of the block with functions for judge's life cykle -----------
void judge_wants_to_enter(){
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "JUDGE";
    print_to_file("wants to enter");
    sem_post(write_to_file);

    // Judge sleeps before entering
    if (hall_problem->JG > 0){
        int time_to_wait = generate_random_number(hall_problem->JG);
        usleep(time_to_wait);
    }
}

void judge_enters(){  
    // Stoping immigrants from coming in and going out
    sem_wait(judge_is_inside);
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "JUDGE";
    print_to_file("enters");
    sem_post(write_to_file);
}

void judge_gives_confirmation(){  
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "JUDGE";
    print_to_file("starts confirmation");
    sem_post(write_to_file);

    // Judge sleeps before giving certificates
    if (hall_problem->JT > 0){
        int time_to_wait = generate_random_number(hall_problem->JT);
        usleep(time_to_wait);
    } 

    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "JUDGE";
    data_out->got_certificate = data_out->got_certificate + data_out->NC;
    while (data_out->NC > 0){
        sem_post(imm_wants_conf);
        data_out->NC--;
    }
    data_out->NE = 0;
    print_to_file("ends confirmation");

    sem_post(write_to_file);
}

// If any of immigrants have not registred, wait until all of them check in
void judge_waits_for_checkin(){
    sem_wait(write_to_file);
    if (data_out->NE > data_out->NC){
        data_out->A++;
        data_out->NAME = "JUDGE";
        print_to_file("waits for imm");
        data_out->judge_waits_checkin = true;
        sem_post(write_to_file);
        sem_wait(judge_waits_for_check_in);
    }
    else{
        sem_post(write_to_file);
    }
    data_out->judge_waits_checkin = false;
    judge_gives_confirmation();
}

// Judge leaves the building and lets immigrants go in and out
void judge_leaves(){
    if (hall_problem->JT > 0){
        int time_to_wait = generate_random_number(hall_problem->JT);
        usleep(time_to_wait);
    }

    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "JUDGE";
    print_to_file("leaves");
    sem_post(write_to_file);

    sem_post(judge_is_inside);
}

// Judge has given all the certificates and dies
void judge_finishes(){
    sem_wait(write_to_file);
    data_out->A++;
    data_out->NAME = "JUDGE";
    print_to_file("finishes");
    sem_post(write_to_file);
}
// -------End of the block with functions for judge's life cykle -----------


// Creating immigrants
int create_immigrant(int imm_id){
    pid_t immigrant;
    immigrant = fork();
    if (immigrant < 0){
        fprintf(stderr, "Process \"IMMIGRANT\" was not created\n");
        return -1;
    }
    else if (immigrant == 0) {      //Immigrant's life cykle
        immigrant_starts(imm_id);
        immigrant_enters(imm_id); 
        immigrant_registers(imm_id);
        immigrant_wants_confirmation(imm_id);
        immigrant_gets_confirmation(imm_id);
        immigrant_leaves(imm_id);
        exit(EXIT_SUCCESS);
    }
    return immigrant;
}

// Creating immigrant generaror, which will create immigrants
int create_immigrant_generator(){
    pid_t imm_generator;
    pid_t immigrant;
    imm_generator = fork();
    if (imm_generator < 0){
        fprintf(stderr, "Process \"IMMIGRANT GENERATOR\" was not created\n");
        return 1;
    }
    else if (imm_generator == 0) {      //Immigrant generator process
        int imm_to_generate = 0;
        while (imm_to_generate < hall_problem->PI){
            if (hall_problem->IG > 0){
                int time_to_wait = generate_random_number(hall_problem->IG);
                usleep(time_to_wait);
            }
            imm_to_generate++;
            immigrant = create_immigrant(imm_to_generate);  
            if (immigrant == -1){
                hall_problem->PI = 0;
                exit(EXIT_FAILURE);
            }         
        }
        waitpid(immigrant, NULL, 0);
        exit(EXIT_SUCCESS);
    }
    waitpid(imm_generator, NULL, 0);
    return 0;
}

/* Creating judge process and calling function for immigrant generator
creation from main process */
int create_judge_and_imm_generator(){
    pid_t judge;
    judge = fork();
    if (judge < 0){
        fprintf(stderr, "Process \"JUDGE\" was not created\n");
        return 1;
    }
    else if (judge == 0) {      //Judge's life cykle
        //Judge works until all the immigrants get certificates
        while(data_out->got_certificate < hall_problem->PI){ 
            judge_wants_to_enter();
            judge_enters();
            judge_waits_for_checkin();
            judge_leaves();
        }
        judge_finishes();
        exit(EXIT_SUCCESS);
    }
    else{   //Main process
        int ret = create_immigrant_generator();
        if (ret == 1){
            return 1;
        }
    }
    waitpid(judge, NULL, 0);
    return 0;
}

// Initialization of counters and flags
void data_out_init(){
    data_out->A = 0;
    data_out->got_certificate = 0;
    data_out->judge_waits_checkin = false;
    data_out->NE = 0;
    data_out->NC = 0;
    data_out->NB = 0;
}

// Mapping shared memory
int map_memory(){
    hall_problem = mmap(NULL, sizeof(struct current_hall_problem), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (hall_problem == MAP_FAILED){
        fprintf(stderr, "Shared memory was not created\n");
        return 1;
    }
    data_out = mmap(NULL, sizeof(struct d_out), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (data_out == MAP_FAILED){
        fprintf(stderr, "Shared memory was not created\n");
        return 1;
    }
    return 0;
}

// Freeing shared memory
int free_mem(){
    if (munmap(hall_problem, sizeof(struct current_hall_problem)) == -1){
        fprintf(stderr, "Shared memory was not unmapped\n");
        return 1;
    }
    if (munmap(data_out, sizeof(struct d_out)) == -1){
        fprintf(stderr, "Shared memory was not unmapped\n");
        return 1;
    }
    return 0;
}

// Freeing all the resourses
int clear_all(){
    fclose(f_out);
    if (destroy_semaphores()){
        return 1;
    }
    if (free_mem()){
        return 1;
    }
    return 0;
}

//Converting strings to integers and filling in the structure with data
void args_converter(char **argv){
    hall_problem->PI = atoi(argv[PI]);
    hall_problem->IG = atoi(argv[IG]);
    hall_problem->JG = atoi(argv[JG]);
    hall_problem->IT = atoi(argv[IT]);
    hall_problem->JT = atoi(argv[JT]);
}

//Checking if the arguments are integers
int is_integer(char *argument){
    unsigned int i = 0;
    while (i < strlen(argument)){
        if (isdigit(argument[i]) == 0){
            return 1;
        }
        i++;
    }
    return 0;
}

//Testing if the entered arguments are valid
int args_test(int argc, char **argv){
    if (argc != num_of_expected_arguments){
        fprintf(stderr, "Wrong number of arguments\n");
        return 1;
    }

    int i = 1;
    while (i < num_of_expected_arguments)
    {
        if (is_integer(argv[i]) != 0){
            fprintf(stderr, "Wrong arguments\n");
            return 1;
        }  
        i++;
    }
    
    if (strtol(argv[1], NULL , base) < 1){
        fprintf(stderr, "Number of immigrants cannot be less then 1\n");
        return 1;
    }

    i = IG; //Begin with the second argument
    while (i < num_of_expected_arguments){
        if (strtol(argv[i], NULL, base) > max_time){
            fprintf(stderr, "Wrong arguments\n");
            return 1;
        }
        i++;
    }
    return 0;
}

int main(int argc, char **argv){
    if(map_memory() != 0){
        return 1;
    }

    //Openning file for output data
    f_out = fopen("proj2.out", "w+");
    if (f_out == NULL){
        fprintf(stderr, "File was not opened\n");
        free_mem();
        return 1;
    }
    setbuf(f_out, NULL); 

    if(create_semaphores()){
        free_mem();
        fclose(f_out);
        return 1;
    }

    if (args_test(argc, argv) != 0){
        clear_all();
        return 1;
    }
    args_converter(argv);

    data_out_init();
    if (create_judge_and_imm_generator()){
        clear_all();
        return 1;
    }

    wait(NULL);
    if (clear_all()){
        return 1;
    }
    return 0;
}