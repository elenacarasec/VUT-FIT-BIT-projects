const ApiError = require('../error/api_error')
const {UserTask, Task} = require('../models/models')

class TaskController {  
    async get_user_tasks(req, res, next) {
        const {id} = req.body
        if (!id) {
            return next(ApiError.bad_request('missing user id'))
        }
        const tasks = await UserTask.findAll({where:{userId:id}})
        if (tasks.length == 0) {
            return res.json([])
        }
        var task_list = []
        for (let task = 0; task < tasks.length; task++) {
            var task_info = await Task.findOne({where:{id:tasks[task].id}})
            task_info.dataValues.resolved = tasks[task].resolved
            task_list.push(task_info)
        }
        return res.json({task_list})
    }

    async update_user_task(req, res, next) {
        const {userId, taskId, resolved} = req.body
        if (!userId || !taskId) {
            return next(ApiError.bad_request('missing iserId or taskId'))
        }
        const task = await UserTask.findOne({where:{userId:userId, taskId:taskId}})
        if (!task) {
            return next(ApiError.bad_request('invalid request'))
        }
        const updated_task = await UserTask.update({resolved:resolved}, {where:{userId:userId, taskId:taskId}})
        const get_updated_task = await UserTask.findOne({where:{userId:userId, taskId:taskId}})
        return res.json({get_updated_task})
    }
}

module.exports = new TaskController()