
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import { Header } from "antd/lib/layout/layout";
import axios from 'axios';
import Router from 'next/router'  

import {Button, Row, Col, Form, Text, Input, Select, message, TimePicker} from 'antd';
import moment from 'moment';
const {Option} = Select;
import CarrierHeader from '../../components/header/carrier_header';
import AdminHeader from '../../components/header/forms/adminHeader'
import styles from '../../styles/index.module.scss' // Styles 
import {LoadingOutlined, PlusOutlined, MinusCircleOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";

class VehicleEdit extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            userToken: null,
            loggedUser: "loading",
            stations: 'loading'
        }

        axios({
            method: "get",
            url: "https://iis-public-transport.herokuapp.com/api/station/list_all",
        })
        .then(res => {
            this.setState({stationsAll: res.data})
        })
        .catch(err => message.info('No stations found'))

       
    }

    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user}) 
            axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/ride/get_connection",
            data: {connectionId: this.props.id}
        })
        .then(res => {
            let result = res.data.map(el => {
                let newEl = {
                    arrival_time: moment('2022-02-27T'+ el.arrival_time + '.000Z'),
                    stationId: el.stationId,
                    stationName: el.city + " " + el.station
                }
                return newEl
            })
            this.setState({stations: result})
        })
        .catch(err => console.log('No stations found for this connection'))
        }
    }

    static async getInitialProps({query}) {
        let id= query.id
        let carrier = query.carrier
        let description = query.description
        let passengers = Number(query.passengers)
        let week_day = Number(query.week_day)

        return {id, carrier, description, passengers, week_day}
    }

    handleWeekday = (week_day) => {
        switch (week_day) {
            case 0:
                return "Sunday"
                break;
            case 1:
                return "Monday"
                break;
            case 2:
                return "Tuesday"
                break;
            case 3:
                return "Wednesday"
                break;
            case 4:
                return "Thursday"
                break;
            case 5:
                return "Friday"
                break;
            case 6:
                return "Saturday"
                break;
            default:
                break;
        }
    }

    handleSend = (data) => {
        console.log("UPDATE")
        data.id = this.props.id
        console.log("This is my data!!111", data)
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/connection/update",
            data: data
        })
            .then(res => 
                
                axios({
                    method: "post",
                    url: "https://iis-public-transport.herokuapp.com/api/ride/delite",
                    data: {id: data.id}
                })
                .then(res => {
                    console.log("Add new ", data)
                    axios({
                    method: "post",
                    url: "https://iis-public-transport.herokuapp.com/api/ride/add_new",
                    data: data
                    })
                        .then(res => 
                                Router.push('/carrier/connectionList')
                            )
                        .catch(err => console.log(err))
                })
                    )
                .catch(err => console.log(err))
                
            .catch(err =>  console.log(err));
    }

    handleDelete = () => {
        console.log(this.props.id,)
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/connection/delite",
            data: {id: this.props.id},

        })
            .then(res => {
                message.info('User was successfully deleted.', 3)
                Router.push('/carrier/connectionList')
            }
            )
                
            .catch(err => console.log(err));
    }

    render() {
        console.log("stations", this.state.stations)
        if (this.state.loggedUser === 'loading' || this.state.stations === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && (this.state.loggedUser.role === 'CARRIER' || this.state.loggedUser.role === 'ADMIN' )) {
        return (
            <div>
                <Head>
                    <title>Sign-up</title>
                </Head>     
                <Header style={{padding: '0'}}>
                    {this.state.loggedUser.role === 'CARRIER' ?
                     <CarrierHeader/>
                     : <AdminHeader/>
                    }
                </Header>
                <Row align='center' style={{marginTop: '128px'}}>
                    <Col  styles={{width: '50%', padding: '3em'}}>
                        <Row>
                            <h2>{this.props.id}</h2>
                        </Row>
                        <Row>
                            <Col>
                                <Form onFinish={this.handleSend} className={styles.forms}
                                    initialValues = {{
                                        'id':this.props.id,
                                        'carrier': this.props.carrier,
                                        'description': this.props.description,
                                        'passengers': Number(this.props.passengers),
                                        'week_day': this.handleWeekday(Number(this.props.week_day)),
                                        'stations': this.state.stations,
                                    }}
                                >
                                <Form.Item name="carrier">
                                        <Input placeholder='Carrier'  ></Input>                   
                                    </Form.Item>
                                    <Form.Item name="description">
                                        <Input placeholder='description'></Input>                     
                                    </Form.Item>
                                    <Form.Item
                                        name={'week_day'}
                                        rules={[{ required: true, message: 'Choose type of ticket' }]} 
                                        style={{ width: '100%', display: 'inline-block'}}>
                                            <Select showSearch size='large' placeholder={
                                                <span>
                                                    Day of week
                                                </span>}
                                            style={{padding: 0}}
                                            className={styles.forms}
                                            optionFilterProp="children">
                                                <Option value="0">Sunday</Option>
                                                <Option value="1">Monday</Option>
                                                <Option value="2">Tuesday</Option>
                                                <Option value="3">Wednesday</Option>
                                                <Option value="4">Thursday</Option>
                                                <Option value="5">Friday</Option>
                                                <Option value="6">Saturday </Option>
                                            </Select>
                                    </Form.Item>
                                    <Form.Item name="passengers">
                                        <Input placeholder='Passengers'/>
                                    </Form.Item>


                                    <Form.List name="stations">
                                    {(fields, { add, remove }) => (
                                    <>
                                    {fields.map(({ key, name, fieldKey, ...restField }) => (

                                    <div key={key} style={{ textAlign: 'left', display: 'block', marginBottom: 8, position: 'relative' }} align="baseline">
                                        <Form.Item
                                            
                                            {...restField}
                                            name={[name, 'stationId']}
                                            fieldKey={[fieldKey, 'stationId']}
                                            rules={[{ required: true, message: 'Choose station' }]}
                                            style={{ width: '60%', display: 'inline-block'}}
                                            // initialValue={this.state.stations && this.state.stations[fieldKey] ? this.state.stations[fieldKey].city + " " + this.state.stations[fieldKey].station : null}
                                            >
                                                <Select   showSearch size='large' placeholder={
                                                    <span>
                                                        
                                                    </span>}
                                                style={{padding: 0}}
                                                optionFilterProp="children"
                                                >
                                                {this.state.stationsAll && this.state.stationsAll.map((el, key) => {
                                                    return(
                                                        <Option
                                                        
                                                        key={key+"T"} value={el.id}>{el.city + ' ' + el.label}</Option>
                                                    )
                                                    })}
                                                </Select>
                          
                                        </Form.Item>
        
                                        <Form.Item
                                            {...restField}
                                            name={[name, 'arrival_time']}
                                            fieldKey={[fieldKey, 'arrival_time']}
                                            rules={[{ required: true, message: 'Insert time' }]}
                                            style={{ width: '40%', float: 'right', display: 'inline-block'}}
                                            // initialValue={this.state.stations && this.state.stations[fieldKey] ? moment('2022-02-27T'+this.state.stations[fieldKey].arrival_time+'.000Z') : null}
                                            >
                                                <TimePicker format={'HH:mm'} />
                                        </Form.Item>

                                        {/* <Form.Item
                                            
                                            {...restField}
                                            name={[name, 'stationId']}
                                            fieldKey={[fieldKey, 'stationId']}
                                            rules={[{  message: 'Choose station' }]}
                                            style={{ width: '0%', visibility: 'hidden', display: 'inline-block'}}
                                            // className={styles.forms}
                                            // initialValue={this.state.stations && this.state.stations[fieldKey] ? this.state.stations[fieldKey].stationId : null}
                                            >
                                                
                                                <Option key={"N" + fieldKey} value={this.state.stations && this.state.stations[fieldKey] ? this.state.stations[fieldKey].stationId : null}></Option>
                                        </Form.Item> */}
                                        {fields.length > 2 &&
                                        <MinusCircleOutlined style={{position: 'absolute', right: '-15%', top: '7%',  fontSize: '2.2em'}} onClick={() => remove(name)} />}
                                    </div>
                                    ))
                                    }

                                    <Form.Item>
                                        <Button type="dashed" style={{width: '100%'}} onClick={() => add()} block icon={<PlusOutlined />}>
                                            Add Stop
                                        </Button>
                                    </Form.Item>
                                    </>
                                    )}

                                </Form.List>

                                <Form.Item >
                                        <div  align='center'style={{marginTop:'10px'}} >
                                        <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'80%'}}>SEND </Button>
                                        </div>  
                                </Form.Item>
                                </Form>
                                <Form onFinish={this.handleDelete} className={styles.forms}>
                                <div  align='center'>
                                    <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'80%'}}>DELETE ROUTE </Button>
                                </div> 
                                </Form>
                            </Col>
                        </Row>
                    </Col>
                </Row> 
            </div>
        )
    }
    else if ((this.state.loggedUser && this.state.loggedUser.role !== 'CARRIER' && this.state.loggedUser.role !== 'ADMIN')) {
        return (
            <div align='center'>
                You dont have enough priviligies to open this page
            </div>
        )
    }
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (VehicleEdit);
