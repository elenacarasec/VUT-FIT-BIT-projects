const Router = require('express')
const router = new Router()
const user_controller = require('../controllers/user')

router.post('/registration', user_controller.registration)
router.post('/login', user_controller.login)
router.post('/update', user_controller.update)
router.post('/user_info', user_controller.user_info)
router.post('/user_friends', user_controller.user_friends)

module.exports = router