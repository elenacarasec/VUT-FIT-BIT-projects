/*
** Title:  IOS project 2, Faneuil Hall Problem
** Author: Elena Carasec (xcaras00)
** Date:   2020-05-05
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/mman.h>
#include <time.h>
#include <semaphore.h>
#include <fcntl.h>    
#include <stdbool.h>    
#include <sys/wait.h>    

#define num_of_expected_arguments 6
#define max_time 2000
#define base 10
#define sem_mode 0666
#define locked 0
#define unlocked 1

sem_t *judge_is_inside;             // Immigrants should not enter or leave while judge is inside
sem_t *write_to_file;               // All shared resourses are reachable only for one process at a time
sem_t *judge_waits_for_check_in;    // Judge cannot start confirmation until all immigrants have registred
sem_t *imm_wants_conf;              // Immigrants may ask for certificates after the judge has ended confirmation            

enum {PI = 1, IG, JG, IT, JT};      // Order of input arguments
FILE *f_out;                        // File for output

//Structure, which will be filled in with input data
struct current_hall_problem{
    int PI; //number of immigrants
    int IG; //max time to create an immigrant process (ms)
    int JG; //max time for judge to enter the building (ms)
    int IT; //max time to get the certificate (ms)
    int JT; //max time for judge to give answer (ms)
} *hall_problem;

//Structure, containing data about current state of program
struct d_out{
    int A;                      //current action number
    char *NAME;                 //category of process
    int I;                      //internal process ID
    int NE;                     //number of immigrants, who have entered the building (and have not got the certificate yet)
    int NC;                     //number of immigrants, who have registered (and have not got the certificate yet)
    int NB;                     //number of immigrants, who are actually in the building
    int got_certificate;        //number of immigrants, who have already got the certificate
    bool judge_waits_checkin;   //shows if judge should wait for immigrants to checkin
} *data_out;