This project was made using "Anaconda3". The libraries needed for this project are described in "requirements.txt".
