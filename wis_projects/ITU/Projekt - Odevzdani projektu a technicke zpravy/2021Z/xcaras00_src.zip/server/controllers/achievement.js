const ApiError = require('../error/api_error')
const {UserAchievement, Achievement} = require('../models/models')

class AchievementController {  
    async update_state(req, res, next) {
        const {userId, achievementId, has} = req.body
        if (!userId || !achievementId) {
            return next(ApiError.bad_request('missing iserId or achievementId'))
        }
        const achieve = await UserAchievement.findOne({where:{userId:userId, achievementId:achievementId}})
        if (!achieve) {
            return next(ApiError.bad_request('invalid request'))
        }
        const updated_task = await UserAchievement.update({has:has}, {where:{userId:userId, achievementId:achievementId}})
        return res.json({updated_task})
    }

    async get_user_achievments(req, res, next) {
        const {id} = req.body
        if (!id) {
            return next(ApiError.bad_request('missing user id'))
        }
        const achievements = await UserAchievement.findAll({where:{userId:id}})
        if (achievements.length == 0) {
            return res.json([])
        }
        var achievement_list = []
        for (let achieve = 0; achieve < achievements.length; achieve++) {
            var achievement = await Achievement.findOne({where:{id:achievements[achieve].achievementId}})
            achievement.dataValues.has = achievements[achieve].has
            achievement_list.push(achievement)
        }
        return res.json({achievement_list})
    }
}

module.exports = new AchievementController()