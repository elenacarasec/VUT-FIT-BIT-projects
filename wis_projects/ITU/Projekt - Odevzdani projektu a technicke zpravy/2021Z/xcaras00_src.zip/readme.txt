Server:
    1) npm install
    2) npm run start
Klient
    1) npm install -g expo-cli
    2) npm install
    3) npm start
    v tomto pripade na testovani lze pouzit mobilni aplikaci "Expo go", ktera se pripoji do lokalniho serveru
    nebo na spustenem serveru otevrit stranku kde je mozne si zvolit web variantu aplikaci
Klient mobilni telefon:
    1) npm install -g expo-cli
    2) npm install
    3) npm expo build:android
    4) expo build:ios