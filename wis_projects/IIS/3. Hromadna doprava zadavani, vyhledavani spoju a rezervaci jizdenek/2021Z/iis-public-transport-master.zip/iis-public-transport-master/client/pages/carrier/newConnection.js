import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, Input, Select, Button, message, TimePicker} from 'antd';
import moment from 'moment';
import Moment from 'moment';


import CarrierHeader from '../../components/header/carrier_header';
import AdminHeader from '../../components/header/forms/adminHeader'

import styles from '../../styles/index.module.scss';
import Router from 'next/router';
import axios from 'axios';

import {LoadingOutlined} from '@ant-design/icons';
import {PlusOutlined, MinusCircleOutlined} from '@ant-design/icons';

import jwt_decode from "jwt-decode";
const {Option} = Select;



class CarrierPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {

            userToken: null,
            loggedUser: "loading"
        }



    }

    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user})        
            axios({
            method: "get",
            url: "https://iis-public-transport.herokuapp.com/api/station/list_all",
                })
                .then(res => {
                    this.setState({stations: res.data})
                })
                .catch(err => message.info('No stations found'))
        }
    }

    handleFinish = (data) => {
        console.log(data);
       // data.passengers = 0
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/connection/add_new",
            data: data
        })
            .then(res => 
                    axios({
                        method: "post",
                        url: "https://iis-public-transport.herokuapp.com/api/ride/add_new",
                        data: data
                    })
                    .then(res => 
                            Router.push('/carrier/connectionList')
                        )
                    .catch(err => console.log(err))
                )
            .catch(err => console.log(err));
        
       
    }

    render() {
        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && (this.state.loggedUser.role === 'CARRIER' || this.state.loggedUser.role === 'ADMIN')) {
        return (
            <div>
		        <Header style={{padding: '0',}}>
                    {this.state.loggedUser.role === 'CARRIER' ?
                     <CarrierHeader/>
                     : <AdminHeader/>
                  } 
		        </Header>  
                <Row align='center' style={{marginTop: '128px'}}>
                  
                    <Col align='center' xs={22} sm={11} md={10} lg={7} xl={6} xxl={6}>
                        <Form onFinish={this.handleFinish}
                            scrollToFirstError='True'
                            className={styles.forms} >
                            <Form.Item name="id">
                                <Input placeholder='ID' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="carrier">
                                <Input placeholder='Carrier' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="description">
                                <Input placeholder='Description' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item name="passengers">
                                <Input placeholder='Passengers' required
                                    className={styles.forms} size='large'/>                      
                            </Form.Item>
                            <Form.Item
                                name={'week_day'}
                                rules={[{ required: true, message: 'Choose type of ticket' }]} 
                                style={{ width: '100%', display: 'inline-block'}}>
                                    <Select showSearch size='large' placeholder={
                                        <span>
                                            Day of week
                                        </span>}
                                    style={{padding: 0}}
                                    className={styles.forms}
                                    optionFilterProp="children">
                                        <Option key='0' value="0">Sunday</Option>
                                        <Option key='1' value="1">Monday</Option>
                                        <Option key='2' value="2">Tuesday</Option>
                                        <Option key='3' value="3">Wednesday</Option>
                                        <Option key='4' value="4">Thursday</Option>
                                        <Option key='5' value="5">Friday</Option>
                                        <Option key='6' value="6">Saturday </Option>
                                    </Select>
                            </Form.Item>

                            <Form.List name="stations">
                                    {(fields, { add, remove }) => (
                                    <>
                                    {fields.map(({ key, name, fieldKey, ...restField }) => (

                                    <div key={key} style={{ textAlign: 'left', display: 'block', marginBottom: 8, position: 'relative' }} align="baseline">
                                        <Form.Item
                                            {...restField}
                                            name={[name, 'stationId']}
                                            fieldKey={[fieldKey, 'stationId']}
                                            rules={[{ required: true, message: 'Choose station' }]}
                                            style={{ width: '60%', display: 'inline-block'}}
                                            className={styles.forms}
                                            >
                                                <Select showSearch size='large' placeholder={
                                                    <span>
                                                        
                                                    </span>}
                                                style={{padding: 0}}
                                                className={styles.forms}
                                                optionFilterProp="children"
                                                >
                                                {this.state.stations && this.state.stations.map((el, key) => {
                                                    return(
                                                        <Option key={"St"+key} value={el.id}>{el.city + ' ' + el.label}</Option>
                                                    )
                                                    })}
                                                </Select>
                                        </Form.Item>
                                        <Form.Item
                                            {...restField}
                                            name={[name, 'arrival_time']}
                                            fieldKey={[fieldKey, 'arrival_time']}
                                            rules={[{ required: true, message: 'Insert time' }]}
                                            style={{ width: '40%', float: 'right', display: 'inline-block'}}
                                            >
                                                <TimePicker 
                                                    defaultValue={moment('00:00', 'HH:mm')}
                                                    format={"HH:mm"}
                                                 />
                                        </Form.Item>
                                        {fields.length > 2 &&
                                        <MinusCircleOutlined style={{position: 'absolute', right: '-10%', top: '7%',  fontSize: '2.2em'}} onClick={() => remove(name)} />}
                                    </div>
                                    ))}

                                    <Form.Item>
                                        <Button type="dashed" style={{width: '100%'}} onClick={() => add()} block icon={<PlusOutlined />}>
                                            Add Stop
                                        </Button>
                                    </Form.Item>
                                    </>
                                    )}

                                </Form.List>

                            <Form.Item>
                            <div align='center'>
                                <Button type='primary' size='large' htmlType='submit' className={styles.buttonLog}> Add </Button>
                            </div>
                            </Form.Item>
                            </Form>
                    </Col>
                </Row> 

            </div>
        )}
        else if ((this.state.loggedUser && (this.state.loggedUser.role !== 'CARRIER' && this.state.loggedUser.role !== 'ADMIN'))) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (CarrierPage);
