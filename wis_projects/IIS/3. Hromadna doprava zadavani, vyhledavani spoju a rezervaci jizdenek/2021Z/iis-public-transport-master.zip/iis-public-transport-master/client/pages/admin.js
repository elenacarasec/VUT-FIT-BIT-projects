
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import { Header } from "antd/lib/layout/layout";

import {Button, Row, Col, Form} from 'antd';
import Link from "next/link"; 
import AdminHeader from '../components/header/forms/adminHeader';
import {LoadingOutlined} from '@ant-design/icons';


import styles from '../styles/index.module.scss' // Styles 
import MenuItem from "antd/lib/menu/MenuItem";
import jwt_decode from "jwt-decode";
import Router from "next/router";

class AdminPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {loggedUser: 'loading'}
    }

    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user})
        }
    }

    render() {
        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && this.state.loggedUser.role === 'ADMIN') {
            return (
                <div>
                    <Head>
                        <title>Admin</title>
                    </Head>     
                    
                    <Header style={{padding: '0'}}>
                        <AdminHeader/>
                    </Header>
                    <Row  style={{marginTop: '25em'}}>
                    <Col xs={0} sm={1} md={2} lg={3} xl={3}>
                        </Col>
                        <Col align='right' xs={22} sm={11} md={10} lg={6} xl={6} xxl={6}>
                        <div align='center'>
                            <Link href="/adminTable">
                                <Button type='primary' size='large' htmlType='submit'  className={styles.button}> Approve Stations</Button>
                            </Link>
                            </div>
                        </Col>
                        <Col xs={0} sm={1} md={2} lg={4} xl={5}>
                        </Col>
                        
                        <Col align='left' xs={22} sm={11} md={10} lg={6} xl={6} xxl={6} >
                        <Link href="/adminAddAcc">
                            <Button type='primary' size='large' htmlType='submit' className={styles.button}>Manage User Accounts </Button>
                        </Link>
                        </Col>
                    </Row> 

                </div>
        ) } else if ((this.state.loggedUser && this.state.loggedUser.role !== 'ADMIN')) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (AdminPage);
