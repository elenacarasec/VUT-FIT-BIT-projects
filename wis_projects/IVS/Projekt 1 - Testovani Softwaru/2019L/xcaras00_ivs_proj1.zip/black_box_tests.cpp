//======== Copyright (c) 2020, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     Red-Black Tree - public interface tests
//
// $NoKeywords: $ivs_project_1 $black_box_tests.cpp
// $Author:     Elena Carasec <xcaras00@stud.fit.vutbr.cz>
// $Date:       $2020-02-19
//============================================================================//
/**
 * @file black_box_tests.cpp
 * @author Elena Carasec
 * 
 * @brief Implementace testu binarniho stromu.
 */

#include <vector>

#include "gtest/gtest.h"

#include "red_black_tree.h"


class EmptyTree : public ::testing::Test{
    protected:
    BinaryTree tree1;
};

TEST_F(EmptyTree, InsertNode){
    //Inserting first node
    std::pair<bool, BinaryTree::Node_t *> p1 = tree1.InsertNode(1);
    BinaryTree::Node_t *InsertedNode1 = p1.second;
    
    ASSERT_TRUE(p1.first);
    ASSERT_NE(nullptr, InsertedNode1);

    //Inserting node with the same value
    std::pair<bool, BinaryTree::Node_t *> p2 = tree1.InsertNode(1);
    BinaryTree::Node_t *InsertedNode2 = p2.second; 

    ASSERT_FALSE(p2.first);
    ASSERT_EQ(InsertedNode1, InsertedNode2);

    //Inserting second node
    std::pair<bool, BinaryTree::Node_t *> p3 = tree1.InsertNode(-10);
    InsertedNode2 = p3.second;

    EXPECT_TRUE(p3.first);
    EXPECT_EQ(InsertedNode2->key, -10);
}

TEST_F(EmptyTree, FindNode){
    BinaryTree::Node_t *FoundNode1 = tree1.FindNode(1);
    EXPECT_EQ(nullptr, FoundNode1);

    BinaryTree::Node_t *FoundNode2 = tree1.FindNode(42);
    EXPECT_EQ(nullptr, FoundNode2);
}

TEST_F(EmptyTree, DeleteNode){
    EXPECT_FALSE(tree1.DeleteNode(1));
    EXPECT_FALSE(tree1.DeleteNode(3));
}

class NonEmptyTree : public ::testing::Test{
    protected:
        void SetUp(){
            tree2.InsertNode(5);
            tree2.InsertNode(7);
            tree2.InsertNode(15);
        }
        BinaryTree tree2;
};

TEST_F(NonEmptyTree, InsertNode){
    std::pair<bool, BinaryTree::Node_t *> p4 = tree2.InsertNode(1);
 
    ASSERT_TRUE(p4.first);
    EXPECT_NE(nullptr, p4.second);

    std::pair<bool, BinaryTree::Node_t *> p5 = tree2.InsertNode(1);
  
    ASSERT_FALSE(p5.first);
    EXPECT_EQ(p4.second, p5.second);

    std::pair<bool, BinaryTree::Node_t *> p6 = tree2.InsertNode(7);
   
    ASSERT_FALSE(p5.first);
}

TEST_F(NonEmptyTree, FindNode){
    EXPECT_NE(nullptr, tree2.FindNode(5));
    EXPECT_EQ(nullptr, tree2.FindNode(1));
    EXPECT_EQ(nullptr, tree2.FindNode(4));
}

TEST_F(NonEmptyTree, DeleteNode){
    EXPECT_TRUE(tree2.DeleteNode(5));
    EXPECT_FALSE(tree2.DeleteNode(5));
    EXPECT_FALSE(tree2.DeleteNode(1));
}

class TreeAxioms : public ::testing::Test{
    protected:
        void SetUp(){
            tree3.InsertNode(2);
            tree3.InsertNode(5);
            tree3.InsertNode(6);
            tree3.InsertNode(9);
            tree3.InsertNode(1);
            tree3.InsertNode(23);
            tree3.InsertNode(-12);
            tree3.InsertNode(24);
            tree3.InsertNode(52);
            tree3.InsertNode(-34);
            tree3.InsertNode(77);
            tree3.InsertNode(19);
            tree3.InsertNode(81);
            tree3.InsertNode(10);
            tree3.InsertNode(-5);
        }
        BinaryTree tree3;
};

//Axiom1: Every leaf (NULL) is black.
TEST_F(TreeAxioms, Axiom1){
    std::vector<BinaryTree::Node_t *> leafNodes;
    tree3.GetLeafNodes(leafNodes);

    for(int i = 0; i < leafNodes.size(); i++){
        ASSERT_EQ(nullptr, leafNodes[i]->pLeft);
        ASSERT_EQ(nullptr, leafNodes[i]->pRight);
        EXPECT_TRUE(leafNodes[i]->color == 1);  // 1 stands for black
    }
}

//Axiom2: If a node is red, then both its children are black.
TEST_F(TreeAxioms, Axiom2){
    std::vector<BinaryTree::Node_t *> nonLeafNodes;
    tree3.GetNonLeafNodes(nonLeafNodes);

    for(int i = 0; i < nonLeafNodes.size(); i++){
        if (nonLeafNodes[i]->color == 0){   //0 stands for red
            EXPECT_TRUE(nonLeafNodes[i]->pLeft->color == 1);
            EXPECT_TRUE(nonLeafNodes[i]->pRight->color == 1);
        }
    }
}

//Axiom3: Every simple path from a node to a descendant leaf contains the same number of black nodes.
TEST_F(TreeAxioms, Axiom3){
    Node_t *root = tree3.GetRoot();
    std::vector<BinaryTree::Node_t *> leafNodes;
    tree3.GetLeafNodes(leafNodes);
    Node_t *currentNode;
    int blackHeight[leafNodes.size()];

    for(int i = 0; i < leafNodes.size(); i++){
        currentNode = leafNodes[i];
        blackHeight[i] = 0;
        while(currentNode != root){
            if(currentNode->color == 1){
                blackHeight[i]++;
            }
            currentNode = currentNode->pParent;
        }
    }

    for(int i = 1; i < leafNodes.size(); i++){
        EXPECT_EQ(blackHeight[i - 1], blackHeight[i]);
    }
}

/*** Konec souboru black_box_tests.cpp ***/