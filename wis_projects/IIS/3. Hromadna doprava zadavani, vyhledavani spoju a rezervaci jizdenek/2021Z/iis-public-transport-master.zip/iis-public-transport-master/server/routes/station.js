const Router = require('express')
const router = new Router()
const station_controller = require('../controllers/station')
const role_middleware = require('../middleware/role_middleware')

// router.post('/add_new', role_middleware(['ADMIN', 'CARRIER']), station_controller.add_new)
router.post('/add_new', station_controller.add_new)
router.post('/update', station_controller.update)
router.post('/approve', station_controller.approve)
router.post('/delite', station_controller.delite)
router.post('/get_station', station_controller.get_station)
router.get('/list_proposed', station_controller.list_proposed)
router.get('/list_all', station_controller.list_all)

module.exports = router