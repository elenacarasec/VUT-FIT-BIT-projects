Packet sniffer is a program to capture packets, examine
and display info about them: timestamp and length of the packet.

The supported protocols are ARP, ICMP, TCP and UDP.
In case of capturing ARP packet, source and destination
MAC addresses will be diplayed.
In case of capturing ICMP or ICMPv6 packet source and destination
IP addressed will be displayed.
If an TCP or UDP packet is captured, source IP address and port
and destination IP address and port will be displayed.


The project contains the following files:
- README.md
- manual.pdf
- ipk-sniffer.cpp
- Makefile


Examples of use:
./ipk-sniffer
./ipk-sniffer -i
./ipk-sniffer -i eth0
./ipk-sniffer -i eth0 -p 11111
./ipk-sniffer -i eth0 --arp --tcp --udp
./ipk-sniffer -i eth0 -n 5