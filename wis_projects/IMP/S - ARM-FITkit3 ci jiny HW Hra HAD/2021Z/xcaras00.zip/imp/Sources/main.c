/**
*   IMP - Hra HAD
*   Autorka: Elena Carasec (xcaras00)
*/


/* Header file with all the essential definitions for a given type of MCU */
#include "MK60DZ10.h"


/* Macros for bit-level registers manipulation */
#define GPIO_PIN_MASK	0x1Fu
#define GPIO_PIN(x)		(((1)<<(x & GPIO_PIN_MASK)))

/* Buttons */
#define BTN_RIGHT 0x400     // Port E, bit 10
#define BTN_DOWN 0x1000    // Port E, bit 12
#define BTN_LEFT 0x8000000 // Port E, bit 27
#define BTN_UP 0x4000000 // Port E, bit 26

/* Constants specifying delay loop duration */
#define	tdelay1			3000
#define tdelay2 		1

/* Directions */
#define UP 0
#define DOWN 1
#define LEFT 2
#define RIGHT 3

/* Snake length */
#define LENGTH 7

/* Snake position */
struct snake_pos {
	unsigned int row[LENGTH];
	unsigned int col[LENGTH];
};

/* Start direction */
int direction = RIGHT;


/* Initialize the MCU - basic clock settings, turning the watchdog off */
void MCUInit(void)  {
    MCG_C4 |= ( MCG_C4_DMX32_MASK | MCG_C4_DRST_DRS(0x01) );
    SIM_CLKDIV1 |= SIM_CLKDIV1_OUTDIV1(0x00);
    WDOG_STCTRLH &= ~WDOG_STCTRLH_WDOGEN_MASK;
}

/* Configuration of the necessary MCU peripherals */
void SystemConfig() {
	/* Turn on all port clocks */
	SIM->SCGC5 = SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTE_MASK;

	/* Set corresponding PTA pins (column activators of 74HC154) for GPIO functionality */
	PORTA->PCR[8] = ( 0|PORT_PCR_MUX(0x01) );  // A0
	PORTA->PCR[10] = ( 0|PORT_PCR_MUX(0x01) ); // A1
	PORTA->PCR[6] = ( 0|PORT_PCR_MUX(0x01) );  // A2
	PORTA->PCR[11] = ( 0|PORT_PCR_MUX(0x01) ); // A3

	/* Set corresponding PTA pins (rows selectors of 74HC154) for GPIO functionality */
	PORTA->PCR[26] = ( 0|PORT_PCR_MUX(0x01) );  // R0
	PORTA->PCR[24] = ( 0|PORT_PCR_MUX(0x01) );  // R1
	PORTA->PCR[9] = ( 0|PORT_PCR_MUX(0x01) );   // R2
	PORTA->PCR[25] = ( 0|PORT_PCR_MUX(0x01) );  // R3
	PORTA->PCR[28] = ( 0|PORT_PCR_MUX(0x01) );  // R4
	PORTA->PCR[7] = ( 0|PORT_PCR_MUX(0x01) );   // R5
	PORTA->PCR[27] = ( 0|PORT_PCR_MUX(0x01) );  // R6
	PORTA->PCR[29] = ( 0|PORT_PCR_MUX(0x01) );  // R7

	/* Set corresponding PTE pins (output enable of 74HC154) for GPIO functionality */
	PORTE->PCR[28] = ( 0|PORT_PCR_MUX(0x01) ); // #EN
    PORTE->PCR[10] = ( 0|PORT_PCR_MUX(0x01)); // SW2
    PORTE->PCR[12] = ( 0|PORT_PCR_MUX(0x01)); // SW3
    PORTE->PCR[27] = ( 0|PORT_PCR_MUX(0x01)); // SW4
    PORTE->PCR[26] = ( 0|PORT_PCR_MUX(0x01)); // SW5

	/* Change corresponding PTA port pins as outputs */
	PTA->PDDR = GPIO_PDDR_PDD(0x3F000FC0);

	/* Change corresponding PTE port pins as outputs */
	PTE->PDDR = GPIO_PDDR_PDD( GPIO_PIN(28) &  GPIO_PIN(27) &  GPIO_PIN(26) &  GPIO_PIN(10) &  GPIO_PIN(12));
}


/* Turn off all rows at start */
void rows_off() {
	PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(26));
	PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(24));
	PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(9));
	PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(25));
	PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(28));
	PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(7));
	PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(27));
	PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(29));
}


/* Turn off one row */
void row_off(unsigned int row) {
	switch (row) {
		case 0:
			PTA->PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(26));
			break;
		case 1:
			PTA->PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(24));
			break;
		case 2:
			PTA->PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(9));
			break;
		case 3:
			PTA->PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(25));
			break;
		case 4:
			PTA->PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(28));
			break;
		case 5:
			PTA->PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(7));
			break;
		case 6:
			PTA->PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(27));
			break;
		case 7:
			PTA->PDOR &= ~GPIO_PDOR_PDO(GPIO_PIN(29));
			break;
		default:
			break;
	}
}


/* Turn on one row */
void row_on(unsigned int row) {
	switch (row) {
		case 0:
			PTA->PDOR |= GPIO_PDOR_PDO(GPIO_PIN(26));
			break;
		case 1:
			PTA->PDOR |= GPIO_PDOR_PDO(GPIO_PIN(24));
			break;
		case 2:
			PTA->PDOR |= GPIO_PDOR_PDO(GPIO_PIN(9));
			break;
		case 3:
			PTA->PDOR |= GPIO_PDOR_PDO(GPIO_PIN(25));
			break;
		case 4:
			PTA->PDOR |= GPIO_PDOR_PDO(GPIO_PIN(28));
			break;
		case 5:
			PTA->PDOR |= GPIO_PDOR_PDO(GPIO_PIN(7));
			break;
		case 6:
			PTA->PDOR |= GPIO_PDOR_PDO(GPIO_PIN(27));
			break;
		case 7:
			PTA->PDOR |= GPIO_PDOR_PDO(GPIO_PIN(29));
			break;
		default:
			break;
	}
}


/* Variable delay loop */
void delay(int t1, int t2)
{
	int i, j;

	for(i=0; i<t1; i++) {
		for(j=0; j<t2; j++);
	}
}


/* Conversion of requested column number into the 4-to-16 decoder control.  */
void column_select(unsigned int col_num)
{
	unsigned i, result, col_sel[4];

	for (i = 0; i < 4; i++) {
		result = col_num / 2;	  // Whole-number division of the input number
		col_sel[i] = col_num % 2;
		col_num = result;

		switch(i) {

			// Selection signal A0
		    case 0:
				((col_sel[i]) == 0) ? (PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(8))) : (PTA->PDOR |= GPIO_PDOR_PDO( GPIO_PIN(8)));
				break;

			// Selection signal A1
			case 1:
				((col_sel[i]) == 0) ? (PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(10))) : (PTA->PDOR |= GPIO_PDOR_PDO( GPIO_PIN(10)));
				break;

			// Selection signal A2
			case 2:
				((col_sel[i]) == 0) ? (PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(6))) : (PTA->PDOR |= GPIO_PDOR_PDO( GPIO_PIN(6)));
				break;

			// Selection signal A3
			case 3:
				((col_sel[i]) == 0) ? (PTA->PDOR &= ~GPIO_PDOR_PDO( GPIO_PIN(11))) : (PTA->PDOR |= GPIO_PDOR_PDO( GPIO_PIN(11)));
				break;

			// Otherwise nothing to do...
			default:
				break;
		}
	}
}


/* Default snake position */
void snake_init(struct snake_pos *snake) {
	for (int i = 0; i < LENGTH; i++) {
		snake->row[i] = 0;
		snake->col[i] = 0;
	}
}


/* Change snake position */
void snake_move(struct snake_pos *snake) {
	for (int i = LENGTH - 1; i > 0; i--) {
		snake->row[i] = snake->row[i-1];
		snake->col[i] = snake->col[i-1];
	}
}


/* Check if the snake hits itself and start the game again if true*/
int hit_myself(struct snake_pos *snake, int col, int row) {
	for (int c = 3; c < LENGTH; c++) {
		if ((snake->col[c] == col) && (snake->row[c] == row)) {
			snake_init(snake);
			direction = RIGHT;
			return 1;
		}
	}
	return 0;
}


/* Light on LEDs on snake's position */
void lights_on(struct snake_pos *snake) {
	for (int l=0; l < LENGTH; l++) {
		row_on(snake->row[l]);
		column_select(snake->col[l]);

		PTE->PDDR &= ~GPIO_PDDR_PDD( GPIO_PIN(28));
		delay(tdelay1, tdelay2);
		PTE->PDOR |= GPIO_PDOR_PDO( GPIO_PIN(28));

		row_off(snake->row[l]);
	}
}


/* Check if the snake should change direction */
int changed_direction(void) {
	if (direction == UP || direction == DOWN) {
		if (!(PTE->PDIR & BTN_LEFT)) {
			direction = LEFT;
			return 1;
		}
		else if (!(PTE->PDIR & BTN_RIGHT)) {
			direction = RIGHT;
			return 1;
		}
	}
	else {
		if (!(PTE->PDIR & BTN_UP)) {
			direction = UP;
			return 1;
		}
		else if (!(PTE->PDIR & BTN_DOWN)) {
			direction = DOWN;
			return 1;
		}
	}
	return 0;
}


/* Light on LEDs on the snake's position <timer> times
 * to make it visible for human eye */
int draw_snake(struct snake_pos *snake) {
	int timer = 16;
	for (int j=0; j < timer; j++) {
		if (changed_direction())
			return 1;
		lights_on(snake);
	}

	delay(tdelay1, tdelay2);
	return 0;
}


/* Move snake down */
void move_down(struct snake_pos *snake) {
	for (int i = (snake->col[0] + 1) % 16; i < 16; i++) {
		if (hit_myself(snake, i, snake->row[0]))
			return;

		snake_move(snake);
		snake->col[0] = i;

		if (draw_snake(snake))
			return;
	}
}


/* Move snake right */
void move_right(struct snake_pos *snake) {
	for (int i = (snake->row[0] - 1 + 8) % 8; i >= 0; i--) {
		if (hit_myself(snake, snake->col[0], i))
			return;

		snake_move(snake);
		snake->row[0] = i;
		if (draw_snake(snake))
			return;
	}
}


/* Move snake up */
void move_up(struct snake_pos *snake) {
	for (int i = (snake->col[0] - 1 + 16) % 16; i >= 0; i--) {
		if (hit_myself(snake, i, snake->row[0]))
			return;

		snake_move(snake);
		snake->col[0] = i;
		if (draw_snake(snake))
			return;
	}
}


/* Move snake left */
void move_left(struct snake_pos *snake) {
	for (int i = (snake->row[0] + 1) % 8; i < 8; i++) {
		if (hit_myself(snake, snake->col[0], i))
			return;

		snake_move(snake);
		snake->row[0] = i;
		if (draw_snake(snake))
			return;
	}
}


/* Describe snake's behavior */
void behavior(struct snake_pos *snake) {
	 for (;;) {
		if (direction == RIGHT) {
			move_right(snake);
		}
		else if (direction == LEFT) {
			move_left(snake);
		}
		else if (direction == UP) {
			move_up(snake);
		}
		else if (direction == DOWN) {
			move_down(snake);
		}
    }
}


int main(void)
{
	struct snake_pos snake;

    MCUInit();
	SystemConfig();

	rows_off();
	delay(tdelay1, tdelay2);

	snake_init(&snake);
	behavior(&snake);

    /* Never leave main */
    return 0;
}
