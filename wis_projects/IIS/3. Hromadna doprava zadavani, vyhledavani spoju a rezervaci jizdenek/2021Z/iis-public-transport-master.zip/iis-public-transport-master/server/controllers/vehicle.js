const ApiError = require('../error/api_error')
const {Vehicle} = require('../models/models')

class VehicleController {
    async add_new(req, res, next) {
        const {model, description, license_plate, number, number_of_seats, connectionId} = req.body
        if (!model || !description || !license_plate || !number || !number_of_seats) {
            return next(ApiError.bad_request('required vehicle info was not found'))
        }        
        const candidate = await Vehicle.findOne({where: {license_plate}})
        if (candidate) {
            return next(ApiError.bad_request('vehicle already exists'))
        }
        console.log('---- ', model, description, license_plate, number, number_of_seats, connectionId, " ----")
        const vehicle = await Vehicle.create({model, description, license_plate, number, number_of_seats, connectionId})
        return res.json(vehicle)
    }

    async update(req, res, next) {
        const {model, description, license_plate, number, number_of_seats, connectionId} = req.body
        if (!model || !description || !license_plate || !number || !number_of_seats) {
            return next(ApiError.bad_request('required vehicle info was not found'))
        }        
        const candidate = await Vehicle.findOne({where: {license_plate}})
        if (!candidate) {
            return next(ApiError.bad_request('vehicle already exists'))
        }
        console.log("TEST", model, description, license_plate, number, number_of_seats, connectionId)
        const vehicle = await Vehicle.update({model, description, license_plate, number, number_of_seats, connectionId}, {where:{id:candidate.id}})
        return res.json(vehicle)
    }

    async delite(req, res, next) {
        const {license_plate} = req.body
        if (!license_plate) {
            return next(ApiError.bad_request('required data for vehicle delite was not found'))
        }
        const candidate = await Vehicle.findOne({where: {license_plate}})
        if (!candidate) {
            return next(ApiError.bad_request('vehicle does not exists'))
        }        
        const candidate_delited = await Vehicle.destroy({where: {license_plate}})
        return res.json(candidate)
    }

    async list_all(req, res, next) {
        const candidates = await Vehicle.findAll()
        return res.json(candidates)
    }
}

module.exports = new VehicleController()