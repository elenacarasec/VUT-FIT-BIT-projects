
import React from "react";
import Router from 'next/router';
import {Row, Col, Menu, Dropdown,Anchor} from 'antd'; 
import styles from './header.module.scss'



export default class Header extends React.Component {
    constructor(props) {
        super(props);
        this.state = {}
    }
    handleLogout = () => {
        localStorage.removeItem('authToken')
        window.location.reload(false);
        Router.push('/')
    }

    render() {
        return (   
            <Row align='center' gutter={[0, 5]} style={{ position: "relative"}}>
                <Col align='center' onClick={() => {Router.push('/')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
                        HOME
                </Col>
                <Col align='center' onClick={() => {Router.push('/pending')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
                        INFORMATION
                </Col>
                <Col align='center' className={styles.headerButtonsCol} sm={4} xs={24}>
                    <Dropdown overlay={
                        <Menu className={styles.dropDown}>
                            <Menu.Item className={styles.menuItem} onClick={() => {Router.push('/pending')}} key="1a">Delay</Menu.Item>
                            <Menu.Item className={styles.menuItem} onClick={() => {Router.push('/pending')}} key="2a">Luggage</Menu.Item>
                            <Menu.Item className={styles.menuItem} onClick={() => {Router.push('/pending')}}  key="3a">Payments</Menu.Item>
                            <Menu.Item className={styles.menuItem} onClick={() => {Router.push('/pending')}} key="4a">Reservation</Menu.Item>
                            <Menu.Item className={styles.menuItem} onClick={() => {Router.push('/pending')}} key="5a">Vouchers</Menu.Item>
                            </Menu>}>
                    <div style={{color: 'white'}}>
                        HELP
                    </div>
                    </Dropdown>
                </Col>
                <Col align='center' onClick={() => {Router.push('/map')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
                    MAP
                </Col>
                <Col align='center'  onClick={() => {Router.push('/questions')}} className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
                    QUESTIONS
                </Col>
                <Col onClick={this.handleLogout} align='center' className={styles.headerButtonsCol + ' ' + styles.liningElement} sm={4} xs={24}>
					LOGOUT
				</Col>
            </Row>
        )
    }
}




