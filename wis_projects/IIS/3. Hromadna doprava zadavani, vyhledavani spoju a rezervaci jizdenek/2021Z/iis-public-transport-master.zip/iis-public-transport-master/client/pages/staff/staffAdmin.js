
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, Input, Select, Radio, Space, Typography} from 'antd';
const { Option } = Select;
const { Text } = Typography;
import AdminHeader from '../../components/header/forms/adminHeader';
import styles from '../../styles/index.module.scss';
import staffStyles from '../../styles/staff.module.scss';


class StaffPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    handleFinish = (data) => {
        console.log('This is my data!!!', data)
        
        // sendToServer(data).then(
        //     (res) => {

        //     },
        //     (err) => {

        //     }
        // )
    }

    render() {

        return (
            <div>
                <Head>
                    <title>Staff</title>
                </Head>
		        <Header style={{padding: '0',}}>
                	<AdminHeader/>
		        </Header>  
                
                <Row align='center' className={styles.centerdBlock} style={{padding: '4em 0 0 0'}}>
			        <Col>
                        <Row align='center'>
                        <Form >
                                <Form.Item className={staffStyles.forms} name="connection">                   
                                    <Select showSearch placeholder={<span>Connections</span>}
                                                optionFilterProp="children">
                                        <Option value='1'>CN34567 Brno-Královo Pole -&gt; Pardubice-Pardubičky</Option>
                                        <Option value='2'>CN34532 Brno-Hl.nadrazi -&gt; Praha-Hl.nadrazi</Option>
                                    </Select>
                                </Form.Item>
                            </Form>
                        </Row>
                        <Row align='center'>
                            <Text align='center' style={{padding: '0 3em 0 0'}}>Actual station:</Text>
                            <Radio.Group >
                                <Space direction="vertical">
                                    <Radio.Button value="s1" className={staffStyles.radioButton}>Brno - Kralovo Pole nadrazi</Radio.Button>
                                    <Radio.Button value="s2" className={staffStyles.radioButton}>Olomouc - Hlavni nadrazi</Radio.Button>
                                    <Radio.Button value="s3" className={staffStyles.radioButton}>Pardubice - Pardubičky</Radio.Button>
                                </Space>
                            </Radio.Group>
                        </Row>
			        </Col>
                </Row>
            </div>
        )
    }
}


const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (StaffPage);