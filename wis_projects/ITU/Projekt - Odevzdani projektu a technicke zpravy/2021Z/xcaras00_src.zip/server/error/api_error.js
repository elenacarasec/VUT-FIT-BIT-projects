class ApiError extends Error {
    constructor(status, msg) {
        super();
        this.status = status
        this.message = msg
    }

    static bad_request(message) {
        return new ApiError(404, message)
    }

    static internal(message) {
        return new ApiError(500, message)
    }

    static not_acceptable(message) {
        return new ApiError(406, message)
    }
}

module.exports = ApiError