const ApiError = require('../error/api_error')
const {Connection} = require('../models/models')

class ConnectionController {
    async add_new(req, res, next) {
        const {id, week_day, passengers, description, carrier} = req.body
        console.log('---', id, week_day, passengers, description, carrier, '---')
        if (!id || !week_day || !description | !carrier) {
            return next(ApiError.bad_request('missing data for connection update'))
        }        
        const week_day_number = Number(week_day)
        console.log('---', id, week_day_number, passengers, description, carrier, '---')
        const candidate = await Connection.findOne({where: {id}})
        if (candidate) {
            return next(ApiError.bad_request('connection already exists'))
        }
        const connection = await Connection.create({id, week_day: week_day_number, passengers, description, carrier})
        return res.json(connection)
    }

    async update(req, res, next) {
        const {id, week_day, passengers, description, carrier} = req.body     
        // const d = new Date(date)
        // const week_day = d.getDay()
        const week_day_number = Number(week_day)
        const candidate = await Connection.findOne({where: {id}})
        if (!candidate) {
            return next(ApiError.bad_request('connection does not exists'))
        }
        const connection = await Connection.update({id, week_day_number, passengers, description, carrier}, {where: {id: id}})
        return res.json(connection)
    }

    async delite(req, res, next) {
        const {id} = req.body
        console.log("!!! ", id, " !!!")
        if (!id) {
            return next(ApiError.bad_request('required data for connection delite was not found'))
        }
        const candidate = await Connection.findOne({where: {id}})
        if (!candidate) {
            return next(ApiError.bad_request('connection does not exists'))
        }        
        const candidate_delited = await Connection.destroy({where: {id}})
        return res.json(candidate_delited)
    }

    async list_all(req, res, next) {
        const candidates = await Connection.findAll()
        return res.json(candidates)
    }
}

module.exports = new ConnectionController()