import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import { Header } from "antd/lib/layout/layout";

import {Row, Col, message, Table, Space } from 'antd'; 
import AdminHeader from '../../components/header/forms/adminHeader'
import StaffHeader from '../../components/header/staff_header'

import axios from 'axios';
import Router from 'next/router';

import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";

export default class Ticket extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          loggedUser: 'loading',
          data : []
        }
        axios({
          method: "get",
          url: "https://iis-public-transport.herokuapp.com/api/ticket/tickets_to_approve_reservation",
      })
          .then(res => {
            console.log(res.data)
            this.setState({data:res.data})
          }
              )
          .catch(err => console.log(err));
    }

    componentDidMount = () => {
      let token = localStorage.getItem('authToken')
      if (token === null) {
          Router.push('/')
      } else {
          let user = jwt_decode(token)
          this.setState({loggedUser: user})
      }
  }

    handleApprove = (data) => {
        console.log(data);
      axios({
        method: "post",
        url: "https://iis-public-transport.herokuapp.com/api/ticket/approve_reservation",
        data: {
          id: data.id,
        }
      })
        .then(res => {
          console.log(res.data);
          this.setState({data:res.data});
          window.location.reload(false);
          message.info('Ticket was successfully aproved.', 3)
        }
            )
        .catch(err => console.log(err));
  
    }

    render() {
      const columns = [
        {
          title: 'ID',
          dataIndex: 'id',
          key: 'id',
          render: text => <a>{text}</a>,
        },
        {
          title: 'ConnectionId',
          dataIndex: 'connectionId',
          key: 'connectionId',
          },
        {
          title: 'From',
          dataIndex: 'from',
          key: 'from',
        },
        {
          title: 'To',
          dataIndex: 'to',
          key: 'to',
        },
    
        {
          title: 'Email',
          dataIndex: 'email',
          key: 'email',
          },

        {
          title: 'Price',
          dataIndex: 'price',
          key: 'price',
          },

          {
            title: 'Submit',
            key: 'submit',
            render: (text, record) => (
              <Space size="middle">
                <a onClick={() => {this.handleApprove(record)}}>Submit</a>
              </Space>
            ),
          },
    
      ];
      if (this.state.loggedUser === 'loading') {
        return (
            <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                <LoadingOutlined/>
            </div>
        )
    } else if (this.state.loggedUser && (this.state.loggedUser.role === 'ADMIN' || this.state.loggedUser.role === 'STAFF')) {
        return (
          <>
          {this.state.data.length > 0 ?
            <div>
                <Head>
                    <title>Ticket</title>
                </Head>     
                
                <Header style={{padding: '0'}}>
                {this.state.loggedUser.role === 'STAFF' ?
                    <StaffHeader/>
                     : <AdminHeader/>
                  }
                </Header>
                <Row  style={{marginTop: '10em'}}>
                <Col xs={0} sm={1} md={3} lg={4} xl={4}>
                </Col>
                    <Col align='right' xs={0} sm={6} md={14} lg={15} xl={15}>
                    <Table columns={columns} dataSource={this.state.data} />
                    </Col>
                </Row> 

            </div>
            : null
          }
          </>
        ) }
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'ADMIN' &&  this.state.loggedUser.role !== 'STAFF' )) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
