
import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import { Header } from "antd/lib/layout/layout";
import { MinusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import axios from 'axios';
import Router from 'next/router'  


import {Button, Row, Col, Form, Input, Avatar, Select, Checkbox} from 'antd'; 
import {UserOutlined} from '@ant-design/icons';
const {Option} = Select;

import CarrierHeader from '../../components/header/carrier_header';
import AdminHeader from '../../components/header/forms/adminHeader';

import styles from '../../styles/index.module.scss' // Styles 
import MenuItem from "antd/lib/menu/MenuItem";
import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";

class VehicleEdit extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            customer: {
                id: Number(this.props.id),
                connectionId:this.props.connectionId,
                model: this.props.model,
                description: this.props.description,
                license_plate: this.props.license_plate,
                number: Number(this.props.number),
                number_of_seats: Number(this.props.number_of_seats),
            },
            userToken: null,
            loggedUser: "loading",
            connections: 'loading'
        }


        axios({
            method: "get",
            url: "https://iis-public-transport.herokuapp.com/api/connection/list_all",
        })
        .then(res => {
            this.setState({connections: res.data.map(el => el.id)})
        })
        .catch(err => message.info('No vehicles found'))
        
    }
    componentDidMount = () => {
        let token = localStorage.getItem('authToken')
        if (token === null) {
            Router.push('/')
        } else {
            let user = jwt_decode(token)
            this.setState({loggedUser: user})
        }
    }

    static async getInitialProps({query}) {
        let id= Number(query.id)
        let connectionId= query.connectionId
        let model = query.model
        let description = query.description
        let license_plate = query.license_plate
        let number = Number(query.number)
        let number_of_seats = Number(query.number_of_seats)

        return {id,connectionId,model, description, license_plate,number,number_of_seats}
    }

    handleFinish = (data) => {
        console.log('This is my data!!!', data)
    }

    handleSend = (data) => {
        console.log('This is my data!!!', data);
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/vehicle/update",
            data: data
        })
            .then(res => 
                    Router.push('/carrier/vehicle')
                )
            .catch(err =>  console.log(err));//alert("This e-mail is already used"));
    }

    handleDelete = (data) => {
        console.log('This is my data!!!', data);
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/vehicle/delite",
            data: this.state.customer
        })
            .then(res => 
                    Router.push('/carrier/vehicle')
                )
            .catch(err => console.log(err));//alert("This e-mail is already used"));
    }

    render() {
        if (this.state.loggedUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        } else if (this.state.loggedUser && (this.state.loggedUser.role === 'CARRIER' || this.state.loggedUser.role === 'ADMIN' )) {
        return (
            <div>
                <Head>
                    <title>Sign-up</title>
                </Head>     
                <Header style={{padding: '0'}}>
                    {this.state.loggedUser.role === 'CARRIER' ?
                     <CarrierHeader/>
                     : <AdminHeader/>
                    }
                </Header>
                <Row align='center' style={{marginTop: '128px'}}>
                  
                    <Col align='center' xs={22} sm={11} md={10} lg={7} xl={6} xxl={6}>
 
                        <Form onFinish={this.handleSend}
                            initialValues = {{
                                'id':Number(this.props.id),
                                'connectionId':this.props.connectionId,
                                'model': this.props.model,
                                'description': this.props.description,
                                'license_plate': this.props.license_plate,
                                'number': Number(this.props.number),
                                'number_of_seats': Number(this.props.number_of_seats),

                            }}
                            scrollToFirstError='True'
                            className={styles.forms} >
                            {this.state.connections === 'loading' ?
                            <div align='center'>
                                <LoadingOutlined style={{fontSize: '2em'}}/>
                            </div>
                            :
                            <Form.Item name="connectionId" align='left'>
                                <Select placeholder={'Connection ID'} align='left' required optionFilterProp="children">
                                    {this.state.connections.map(el => {
                                        return (
                                            <Option key={el} value={el}>{el}</Option>
                                        )
                                    })}
                                </Select>
                            </Form.Item>
                            }
                            <Form.Item name="model">
                                <Input placeholder='Model'  ></Input>                  
                            </Form.Item>
                            <Form.Item name="description">
                                <Input placeholder='description'/>                      
                            </Form.Item>
                            <Form.Item name="license_plate">
                                <Input placeholder='license_plate'
                                />                      
                            </Form.Item>
                            <Form.Item name="number">
                                <Input placeholder='number'/>
                            </Form.Item>
                            <Form.Item name="number_of_seats">
                                <Input placeholder='number_of_seats'/>
                            </Form.Item>
                 
                            <Form.Item >
                                <div  align='center'style={{marginTop:'10px'}} >
                                <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'40%'}}>SEND </Button>
                                </div>  
                            </Form.Item>        

                        </Form>
                        <Form onFinish={this.handleDelete} className={styles.forms}>
                        <div  align='center'>
                                <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'40%'}}>DELETE STATION </Button>
                        </div> 
                        </Form>
                    </Col>
                </Row> 

            </div>
        )
    }
    else if ((this.state.loggedUser && this.state.loggedUser.role !== 'CARRIER' && this.state.loggedUser.role !== 'ADMIN')) {
        return (
            <div align='center'>
                You dont have enough priviligies to open this page
            </div>
        )
    }
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (VehicleEdit);
