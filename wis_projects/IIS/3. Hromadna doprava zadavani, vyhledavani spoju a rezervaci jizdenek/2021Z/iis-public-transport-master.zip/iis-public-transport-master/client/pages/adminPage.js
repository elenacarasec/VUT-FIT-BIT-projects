import React from "react";
import Head from 'next/head';
import { Header } from "antd/lib/layout/layout";
import {LoadingOutlined} from '@ant-design/icons';
import axios from 'axios';

import {Row, Col, Form, Select, Input, Button, message, Empty} from 'antd'; 
const {Option} = Select;

import AdminHeader from '../components/header/forms/adminHeader';
import styles from '../styles/index.module.scss'
import Router from 'next/router' 
import jwt_decode from "jwt-decode";
import Link from "next/link";

export default class AdminPg extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loggedUser: 'loading',
            searchUser: 'loading',
        }
    }

    static async getInitialProps({query}) {
        console.log('getInitialProps')
        let email = decodeURIComponent(query.email)
        return {email}
    }

    componentDidMount = () => { 
        let authToken = localStorage.getItem('authToken')
       
        if (authToken === null) {
            console.log("No token")
            Router.push('/')
            
            
        } else {
            let user = jwt_decode(authToken)
            this.setState({loggedUser: user})
            console.log("logged user", this.state.loggedUser)

            if (this.props.email !== undefined && this.props.email !== null) {
                console.log('this.props.emaaaaaaail', this.props.email)
                axios({
                    method: "POST",
                    url: "https://iis-public-transport.herokuapp.com/api/user/get_user",
                    data: {email: this.props.email},
                    headers: {
                        'Authorization': 'Bearer ' + authToken
                    }
                })
                .then (
                    (res) => {
                        console.log('res1 is', res)
                        
                        this.setState({searchUser: res.data})
                        console.log("search user", this.state.searchUser)

                    },
                )
                .catch (    (err) => {
                        // USER NOT FOUND
                        console.log('res2 is', err)
                        this.setState({searchUser: 'error'})
                    }
                )
            } else {
                this.setState({searchUser: 'error'})
            }
        }
    }





    handleFinish = (data) => {
        data.id = this.state.searchUser.id
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/user/user_update",
            data: data
        })
            .then(res => {
                message.info('User info was changed', 3)
                Router.push('/adminAddAcc')
            }
                    
                )
            .catch(err => console.log(err));
    }

    handleDelete = () => {
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/user/user_delite",
            data: {id: this.state.searchUser.id},
        })
            .then(res => {
                message.info('User was successfully deleted.', 3)
                Router.push('/adminAddAcc')
            }
                    
                )
            .catch(err => console.log(err));
    }

    

    render() {

        if (this.state.loggedUser === 'loading' || this.state.searchUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        }
        else if (this.state.searchUser === 'error') {
            return (
                <div>
                <Header style={{padding: '0',}}>
                    <AdminHeader />
                </Header>
                <Row align='center' style={{marginTop: '128px'}}>
                    <Empty
                        image="https://gw.alipayobjects.com/zos/antfincdn/ZHrcdLPrvN/empty.svg"
                        imageStyle={{
                        height: 200,
                        }}
                        description={
                        <span >
                                <div style={{fontSize: '3em', paddingTop: '2vh'}} align='center'>User not found</div>
                        </span>
                        }
                        >
                        <Link href="/adminAddAcc">
                            <Button type="primary">SEARCH AGAIN</Button>
                        </Link>
                    </Empty>
                </Row>
                </div>
            )
        }
        else if (this.state.loggedUser && this.state.loggedUser.role === 'ADMIN') {
            return (
                <div>
                    <Head>
                        <title>Sign-up</title>
                    </Head>     
                    <Header style={{padding: '0'}}>
                        <AdminHeader/>
                    </Header>
                    <Row align='center' style={{marginTop: '128px'}}>
                        {console.log('this.state.searchUser.email', this.state.searchUser.email)}
                        <Col align='center' xs={22} sm={11} md={10} lg={7} xl={6} xxl={6}>
                        <Form onFinish={this.handleFinish} className={styles.forms}
                                initialValues = {{
                                    'email': this.state.searchUser.email,   
                                    'name': this.state.searchUser.name,
                                    'phone_number': this.state.searchUser.phone_number,
                                    'role': this.state.searchUser.role,
                                }}>
                                <Form.Item name="name">
                                    <Input placeholder='Name' className={styles.forms} size='large'/>                      
                                </Form.Item>
                                <Form.Item name="phone_number">
                                    <Input placeholder='Phone'className={styles.forms} size='large'/>
                                </Form.Item>
                                <Form.Item name="email">
                                    <Input placeholder='Email' type="email" className={styles.forms} size='large'/>
                                </Form.Item>
                                {this.state.loggedUser.role === 'ADMIN' &&
                                <Form.Item name="role"  rules={[{ required: true, message: 'Choose a role'}]}>
                                <Select showSearch size='large' required
                                    style={{padding: 0}}
                                    className={styles.forms}
                                    optionFilterProp="children">
                                        <Option value="ADMIN">ADMIN</Option>
                                        <Option value="CARRIER">CARRIER</Option>
                                        <Option value="STAFF">STAFF</Option>
                                        <Option value="USER">USER</Option>
                                    </Select>
                                </Form.Item>
                                }
                                <Form.Item>
                                    <div  align='center'style={{marginTop:'10px'}} >
                                    <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'40%'}}>SEND </Button>
                                    </div>  
                                </Form.Item>        
                        </Form>
                        <Form onFinish={this.handleDelete} className={styles.forms}>
                                <div  align='center'>
                                    <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'40%'}}>DELETE ACCOUNT </Button>
                                </div> 
                        </Form>
                        </Col>
                    </Row> 

            </div>
        ) }
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'ADMIN')) {
            console.log(this.state.loggedUser);
            return (
                
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}
