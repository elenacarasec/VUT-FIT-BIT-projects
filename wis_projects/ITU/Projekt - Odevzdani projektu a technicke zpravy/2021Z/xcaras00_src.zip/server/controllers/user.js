const ApiError = require('../error/api_error')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const {User} = require('../models/models')
const {json} = require('sequelize/dist')

const generate_jwt = (id, email, role) => {
    return jwt.sign(
        {id, email},
        process.env.SECRET_KEY,
        {expiresIn: '635 days'}
    )
}

class UserController {
    async registration(req, res, next) {
        const {name, password, email, age, gender, points} = req.body
        if (!name || !password || !email) {
            return next(ApiError.bad_request('invalid username or password'))
        }
        
        const candidate = await User.findOne({where: {email}})
        if (candidate) {
            return next(ApiError.not_acceptable('user already exists'))
        }

        const hash_passwd = await bcrypt.hash(password, 3)
        const user = await User.create({name, password:hash_passwd, email, age, gender, points})
        const token = generate_jwt(user.id, user.email)
        return res.json({token:token})
    }

    async login(req, res, next) {
        const {email, password} = req.body
        const user = await User.findOne({where:{email}})
        if (!user) {
            return next(ApiError.bad_request('user does not exists'))
        }
        const compare_password = bcrypt.compareSync(password, user.password)
        if (!compare_password) {
            return next(ApiError.bad_request('wrong password or username'))
        }
        const token = generate_jwt(user.id, user.email)
        return res.json({token:token})
    }

    async update(req, res, next) {
        const {name, password, email, age, gender, points, weight_relatives, weight_self, weight_social} = req.body
        const user_to_change = await User.findOne({where: {email}})
        if (!user_to_change) {
            return next(ApiError.bad_request('user does not exists'))
        }
        const hash_passwd = await bcrypt.hash(password, 3)
        const change = await User.update({name:name, passwod:hash_passwd, email:email, age:age, gender:gender, points:points, weight_relatives:weight_relatives, weight_self:weight_self, weight_social:weight_social}, {where: {id : user_to_change.id}})
        return res.json(change)
    }

    async user_info(req, res, next) {
        const {email} = req.body
        if (!email) {
            return next(ApiError.bad_request('user email param is missing'))
        }
        const founded_user = await User.findOne({where:{email:email}})
        if (!founded_user) {
            return next(ApiError.internal('required user was not found'))
        }
        return res.json(founded_user)
    }

    async user_friends(req, res, next) {
        const {email} = req.body
        if (!email) {
            return next(ApiError.bad_request('user email param is missing'))
        }
        return res.json([{'id':2, 'name':'Caroline', 'points':1032}, {'id':2, 'name':'Vasilis', 'points':137}, {'id':2, 'name':'Alexa', 'points':656}])
    }
}

module.exports = new UserController()