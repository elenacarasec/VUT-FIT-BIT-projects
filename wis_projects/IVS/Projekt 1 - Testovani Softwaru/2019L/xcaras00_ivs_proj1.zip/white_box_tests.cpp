//======== Copyright (c) 2020, FIT VUT Brno, All rights reserved. ============//
//
// Purpose:     White Box - Tests suite
//
// $NoKeywords: $ivs_project_1 $white_box_code.cpp
// $Author:     Elena Carasec <xcaras00@stud.fit.vutbr.cz>
// $Date:       $2020-02-19
//============================================================================//
/**
 * @file white_box_tests.cpp
 * @author Elena Carasec
 * 
 * @brief Implementace testu prace s maticemi.
 */

#include "gtest/gtest.h"
#include "white_box_code.h"

class MatrixTest : public ::testing::Test{
    protected: 
        Matrix matrix;

        Matrix createMatrix1x1Empty(){
            matrix = Matrix();
            return matrix;
        }

        Matrix createMatrix1x1(){
            matrix = Matrix();
            matrix.set(std::vector<std::vector<double>>{
                {5}
            });
            return matrix;
        }

        Matrix createMatrix3x3(){
            matrix = Matrix(3, 3);
            matrix.set(std::vector<std::vector<double>> {
                {8.9, 3.008, -53},
                {-1.5, 24, 2},
                {-1, 8, 0}
            });
            return matrix;
        }

        Matrix createMatrix2x4(){
            matrix = Matrix(2,4);
            matrix.set(std::vector<std::vector<double>> {
                {56, 4.6, 1, 9},
                {1000, -6.00001, 7, 2}
            });
            return matrix;
        }

        Matrix createMatrix4x2(){
            matrix = Matrix(4, 2);
            matrix.set(std::vector<std::vector<double>> {
                {5, 1},
                {-3, 0},
                {3.76, 777},
                {42, -8.66}
            });
            return matrix;
        }
};

TEST_F(MatrixTest, Constructor){
    //Matrix construction with valid dimension
    ASSERT_NO_THROW(Matrix());
    ASSERT_NO_THROW(Matrix(1, 1));
    ASSERT_NO_THROW(Matrix(1, 3));
    ASSERT_NO_THROW(Matrix(4, 4));
    ASSERT_NO_THROW(Matrix(1000, 5));
    

    //Matrix construction with invalid dimension
    EXPECT_ANY_THROW(Matrix(0, 0));
    EXPECT_ANY_THROW(Matrix(0, 34));
    EXPECT_ANY_THROW(Matrix(5, 0));
    EXPECT_ANY_THROW(Matrix(-3, 3));
    EXPECT_ANY_THROW(Matrix(3, -3));
}

TEST_F(MatrixTest, SetValues1x1){
    createMatrix1x1Empty();

    //Setting values to existing nodes
    EXPECT_TRUE(matrix.set(0, 0, 5));
    EXPECT_TRUE(matrix.set(0, 0, 0));
    EXPECT_TRUE(matrix.set(0, 0, -5.987));
    EXPECT_TRUE(matrix.set(0, 0, 7.52));
    
    //Setting values to nodes out of the matrix
    EXPECT_FALSE(matrix.set(0, 1, 6));
    EXPECT_FALSE(matrix.set(1, 0, 1));
    EXPECT_FALSE(matrix.set(-2, 0, 3));
    EXPECT_FALSE(matrix.set(0, -7, 0));

}

TEST_F(MatrixTest, SetValues3x3){
    createMatrix3x3();

    //Setting values to existing nodes
    EXPECT_TRUE(matrix.set(0, 0, -99));
    EXPECT_TRUE(matrix.set(2, 1, 4.0006));
    EXPECT_TRUE(matrix.set(1, 2, -6.56));
    EXPECT_TRUE(matrix.set(2, 2, 22222));

    //Setting values to nodes out of the matrix
    EXPECT_FALSE(matrix.set(3, 3, 0));
    EXPECT_FALSE(matrix.set(4, 1, 23));
    EXPECT_FALSE(matrix.set(2, 9, -3));
    EXPECT_FALSE(matrix.set(34, -9, 89));
}

TEST_F(MatrixTest, SetValues2x4){
    createMatrix2x4();

    //Setting values to existing nodes
    EXPECT_TRUE(matrix.set(0, 1, 9));
    EXPECT_TRUE(matrix.set(1, 3, -7));
    EXPECT_TRUE(matrix.set(0, 2, -0.66));
    EXPECT_TRUE(matrix.set(1, 0, 3.1));

    //Setting values to nodes out of the matrix
    EXPECT_FALSE(matrix.set(2, 0, 0));
    EXPECT_FALSE(matrix.set(0, 4, 9));
    EXPECT_FALSE(matrix.set(-1, 2, 8));
    EXPECT_FALSE(matrix.set(2, 4, -32));
}

TEST_F(MatrixTest, SetValues4x2){
    createMatrix4x2();

    //Setting values to existing nodes
    EXPECT_TRUE(matrix.set(std::vector<std::vector<double>> {
        {4, 43}, 
        {-2, 0},
        {0.0000001, -6.3},
        {3231333, 34}
    }));

    //Setting values to nodes out of the matrix
    EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {
        {4, 43}, 
        {-2.0},
        {0.0000001, -6.3},
        {3231333, 34}
    }));
    EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {
        {4, 43}, 
        {-2, 898, 0},
        {0.0000001, -6.3},
        {3231333, 34}
    }));
    EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {
        {4, 43}, 
        {-2.0},
        {3231333, 34}
    }));
    EXPECT_FALSE(matrix.set(std::vector<std::vector<double>> {
        {4, 43}, 
        {-2.0},
        {0.0000001, -6.3},
        {3231333, 34},
        {0, 0}
    }));
}

TEST_F(MatrixTest, GetValues1x1){
    createMatrix1x1();

    //Getting valuses from existing nodes
    double value = matrix.get(0, 0);
    EXPECT_DOUBLE_EQ(value, 5);

    EXPECT_ANY_THROW(matrix.get(1, 0));
    EXPECT_ANY_THROW(matrix.get(0, 1));
    EXPECT_ANY_THROW(matrix.get(-1, 0.5));
}

TEST_F(MatrixTest, GetValues3x3){
    createMatrix3x3();

    //Getting valuses from existing nodes
    double value = matrix.get(0, 0);
    EXPECT_DOUBLE_EQ(value, 8.9);
    value = matrix.get(2, 2);
    EXPECT_DOUBLE_EQ(value, 0);
    value = matrix.get(1, 0);
    EXPECT_DOUBLE_EQ(value, -1.5);

    //Trying to get values from the nodes out of the matrix
    EXPECT_ANY_THROW(matrix.get(-1, 1));
    EXPECT_ANY_THROW(matrix.get(2, 7));
}

TEST_F(MatrixTest, GetValues2x4){
    createMatrix2x4();

    //Getting valuses from existing nodes
    double value = matrix.get(0, 0);
    EXPECT_DOUBLE_EQ(value, 56);
    value = matrix.get(1, 3);
    EXPECT_DOUBLE_EQ(value, 2);
    value = matrix.get(0, 1);
    EXPECT_DOUBLE_EQ(value, 4.6);

    //Trying to get values from the nodes out of the matrix
    EXPECT_ANY_THROW(matrix.get(-1, 1));
    EXPECT_ANY_THROW(matrix.get(2, 7));
}

TEST_F(MatrixTest, GetValues4x2){
    createMatrix4x2();

    //Getting valuses from existing nodes
    double value = matrix.get(0, 0);
    EXPECT_DOUBLE_EQ(value, 5);
    value = matrix.get(1, 1);
    EXPECT_DOUBLE_EQ(value, 0);
    value = matrix.get(3, 1);
    EXPECT_DOUBLE_EQ(value, -8.66);

    //Trying to get values from the nodes out of the matrix
    EXPECT_ANY_THROW(matrix.get(4, 1));
    EXPECT_ANY_THROW(matrix.get(2, 2));
}

TEST_F(MatrixTest, Equality){
    //2 equal matrixes
    Matrix matrix1 = createMatrix3x3();
    ASSERT_TRUE(matrix1.operator==(createMatrix3x3()));

    //2 different matrixes
    matrix1.set(0, 1, 44);
    ASSERT_FALSE(matrix1.operator==(createMatrix3x3()));

    //Matrixes with different dimensions
    Matrix matrix2 = createMatrix2x4();
    EXPECT_ANY_THROW(matrix1.operator==(matrix2));
    matrix1 = createMatrix4x2();
    EXPECT_ANY_THROW(matrix1.operator==(matrix2));
}

TEST_F(MatrixTest, Sum){
    Matrix matrix1 = createMatrix3x3();
    Matrix matrix2 = createMatrix4x2();

    //Matrixes with different dimensions cannot be added
    EXPECT_ANY_THROW(matrix1.operator+(matrix2));
    EXPECT_ANY_THROW(matrix2.operator+(matrix1));

    //Sum of 2 matrixes should be equal to expected result
    matrix2 = createMatrix3x3();
    matrix2.set(std::vector<std::vector<double>> {
        {0.1, -0.008, 32},
        {0.25, -3, 6},
        {1, 3, 23}
    });
    Matrix expectedMatrixSum = Matrix(3, 3);
    expectedMatrixSum.set(std::vector<std::vector<double>> {
        {9, 3, -21},
        {-1.25, 21, 8},
        {0, 11, 23}
    });
    EXPECT_TRUE(expectedMatrixSum.operator==(matrix1.operator+(matrix2)));

    //Changing expected result
    expectedMatrixSum.set(1, 0, 100);
    EXPECT_FALSE(expectedMatrixSum.operator==(matrix1.operator+(matrix2)));

}

TEST_F(MatrixTest, MatrixProduct){
    Matrix matrix = createMatrix3x3();
    Matrix matrix2 = createMatrix4x2();

    /*Number of the rows of the first matrix should be equal to the
    number of columns of the second one*/
    EXPECT_ANY_THROW(matrix.operator*(matrix2));
    EXPECT_ANY_THROW(matrix2.operator*(matrix));

    
    Matrix matrix1 = createMatrix2x4();
    Matrix expectedMatrixProduct = Matrix(2, 2);
    expectedMatrixProduct.set(std::vector<std::vector<double>> {
        {647.96, 755.06},
        {5128.32003, 6421.68}
    });
    Matrix currentMatrixProduct = Matrix(2, 2);
    currentMatrixProduct = matrix1.operator*(matrix2);
    EXPECT_TRUE(expectedMatrixProduct.operator==(currentMatrixProduct));
    
    // A*B != B*A
    EXPECT_ANY_THROW(expectedMatrixProduct.operator==(matrix2.operator*(matrix1)));
}

TEST_F(MatrixTest, Multiplication){
    Matrix matrix1 = createMatrix3x3();
    EXPECT_TRUE(matrix1.operator==(matrix1.operator*(1)));

    Matrix matrix2 = Matrix(3, 3);
    EXPECT_TRUE(matrix2.operator==(matrix1.operator*(0)));

    Matrix matrix3 = matrix1.operator+(matrix1.operator+(matrix1));
    EXPECT_TRUE(matrix3.operator==(matrix1.operator*(3)));
}

TEST_F(MatrixTest, EquationSolveInvalid){
    //Matrix should be square
    Matrix matrix1 = createMatrix4x2();
    EXPECT_ANY_THROW(matrix1.solveEquation({1, 1}));

    /*Number of matrix's rows should be equal to the number of rows
    of the matrix from the right side*/
    Matrix matrix2 = createMatrix3x3();
    EXPECT_ANY_THROW(matrix2.solveEquation({1, 3, 2, 9}));

    //The determinant should not be equal to 0
    matrix2.set(std::vector<std::vector<double>> {
        {1, 10, 5},
        {3, 30, 15},
        {7, 2, 89}
    });
    EXPECT_ANY_THROW(matrix2.solveEquation({9, -4, 31}));
}

TEST_F(MatrixTest, EquationSolve){
    Matrix matrix1 = createMatrix1x1();
    std::vector<double> result = {{10}};
    EXPECT_EQ(matrix1.solveEquation({50}), result);

    Matrix matrix2 = Matrix(2, 2);
    matrix2.set(std::vector<std::vector<double>> {
        {2, 3},
        {5, -2}
    });
    result = {3, 2};
    EXPECT_EQ(matrix2.solveEquation({12, 11}), result);

    Matrix matrix3 = Matrix(3, 3);
    matrix3.set(std::vector<std::vector<double>> {
        {3, -2, 5},
        {7, 4, -8},
        {5, -3, -4}
    });
    result = {1, 3, 2};
    EXPECT_EQ(matrix3.solveEquation({7, 3, -12}), result);

    Matrix matrix4 = Matrix(4, 4);
    matrix4.set(std::vector<std::vector<double>> {
        {1, 1, 2, -1},
        {1, 1, -2, 1},
        {1, -1, 1, 2},
        {1, -1, -1, -2}
    });
    result = {3, 5, -1, -3};
    EXPECT_EQ(matrix4.solveEquation({9, 7, -9, 5}), result);
}

/*** Konec souboru white_box_tests.cpp ***/
