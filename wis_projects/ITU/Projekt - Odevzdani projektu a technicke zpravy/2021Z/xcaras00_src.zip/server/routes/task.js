const Router = require('express')
const router = new Router()
const task_controller = require('../controllers/task')

router.post('/get_user_tasks', task_controller.get_user_tasks)
router.post('/update_user_task', task_controller.update_user_task)

module.exports = router