import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import {Header} from 'antd/lib/layout/layout';
import {Row, Col, Form, Input, Button, message, Empty} from 'antd';
import CarrierHeader from '../../components/header/carrier_header';
import styles from '../../styles/index.module.scss';
import axios from 'axios';
import Router from "next/router";
import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";
import Link from "next/link";

class CarrierPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            loggedUser: 'loading',
            searchUser: 'loading',
        }
    }

    static async getInitialProps({query}) {
        console.log('getInitialProps')
        let email = decodeURIComponent(query.email)
        return {email}
    }

    componentDidMount = () => { 
        let authToken = localStorage.getItem('authToken')
       
        if (authToken === null) {
            console.log("No token")
            Router.push('/')
            
            
        } else {
            let user = jwt_decode(authToken)
            this.setState({loggedUser: user})

            if (this.props.email !== undefined && this.props.email !== null) {
                console.log('this.props.emaaaaaaail', this.props.email)
                axios({
                    method: "POST",
                    url: "https://iis-public-transport.herokuapp.com/api/user/get_staff",
                    data: {email: this.props.email},
                    headers: {
                        'Authorization': 'Bearer ' + authToken
                    }
                })
                .then (
                    (res) => {
                        console.log('res1 is', res)
                        
                        this.setState({searchUser: res.data})
                        console.log("search user", this.state.searchUser)

                    },
                )
                .catch (    (err) => {
                        // USER NOT FOUND
                        console.log('res2 is', err)
                        this.setState({searchUser: 'error'})
                    }
                )
            } else {
                this.setState({searchUser: 'error'})
            }
        }
    }





    handleFinish = (data) => {
        data.id = this.state.searchUser.id
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/user/user_update",
            data: data
        })
            .then(res => {
                message.info('Staff info was changed', 3)
                Router.push('/carrier/staff')
            }
                    
                )
            .catch(err => console.log(err));
    }

    handleDelete = () => {
        axios({
            method: "post",
            url: "https://iis-public-transport.herokuapp.com/api/user/user_delite",
            data: {id: this.state.searchUser.id},
        })
            .then(res => {
                message.info('Staff was successfully deleted.', 3)
                Router.push('/carrier/staff')
            }
                    
                )
            .catch(err => console.log(err));
    }

    

    render() {
        if (this.state.loggedUser === 'loading' || this.state.searchUser === 'loading') {
            return (
                <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                    <LoadingOutlined/>
                </div>
            )
        }
        else if (this.state.searchUser === 'error') {
            return (
                <div>
                <Header style={{padding: '0',}}>
                    <CarrierHeader />
                </Header>
                <Row align='center' style={{marginTop: '128px'}}>
                    <Empty
                        image="https://gw.alipayobjects.com/zos/antfincdn/ZHrcdLPrvN/empty.svg"
                        imageStyle={{
                        height: 200,
                        }}
                        description={
                        <span >
                                <div style={{fontSize: '3em', paddingTop: '2vh'}} align='center'>User not found</div>
                        </span>
                        }
                        >
                        <Link href="/carrier/staff">
                            <Button type="primary">SEARCH AGAIN</Button>
                        </Link>
                    </Empty>
                </Row>
                </div>
            )
        
        } else if (this.state.loggedUser && this.state.loggedUser.role === 'CARRIER') {


        return (
            <div>
                <Head>
                    <title>Carrier</title>
                </Head>
		        <Header style={{padding: '0',}}>
                	<CarrierHeader/>
		        </Header>  
                
                <Row align='center' style={{marginTop: '128px'}}>
                        {console.log('this.state.searchUser.email', this.state.searchUser.email)}
                        <Col align='center' xs={22} sm={11} md={10} lg={7} xl={6} xxl={6}>
                        <Form onFinish={this.handleFinish} className={styles.forms}
                                initialValues = {{
                                    'email': this.state.searchUser.email,   
                                    'name': this.state.searchUser.name,
                                    'phone_number': this.state.searchUser.phone_number,
                                }}>
                                <Form.Item name="name">
                                    <Input placeholder='Name' className={styles.forms} size='large'/>                      
                                </Form.Item>
                                <Form.Item name="phone_number">
                                    <Input placeholder='Phone'className={styles.forms} size='large'/>
                                </Form.Item>
                                <Form.Item name="email">
                                    <Input placeholder='Email' type="email" className={styles.forms} size='large'/>
                                </Form.Item>
                                <Form.Item>
                                    <div  align='center'style={{marginTop:'10px'}} >
                                    <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'60%'}}>SEND </Button>
                                    </div>  
                                </Form.Item>        
                        </Form>
                        <Form onFinish={this.handleDelete} className={styles.forms}>
                                <div  align='center'>
                                    <Button type='primary' size='large' htmlType='submit' style={{float: 'center',width:'60%'}}>DELETE ACCOUNT </Button>
                                </div> 
                        </Form>
                        </Col>
                    </Row> 
            </div>
        )}
        else if ((this.state.loggedUser && this.state.loggedUser.role !== 'CARRIER')) {
            return (
                <div align='center'>
                    You dont have enough priviligies to open this page
                </div>
            )
        }
    }
}



const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (CarrierPage);