import { Result, Button } from 'antd';
import { SmileOutlined } from '@ant-design/icons';

import React, {useState} from "react";
import {connect} from "react-redux";
import Head from 'next/head';
import Link from "next/link"; 

import styles from '../styles/index.module.scss' // Styles 
import MenuItem from "antd/lib/menu/MenuItem";

class IndexPage extends React.Component {
    constructor(props) {
        super(props);
        this.state = {}
    }

    handleFinish = (data) => {
        console.log('This is my data!!!', data)
        let router = new Router()
        router.push('/registered')
    }

    render() {
        return (
            <div>
                <Head>
                    <title>Oooops</title>
                </Head>     
                
                <Result
                      icon={<SmileOutlined />}
                       title="We will add it later, we promise!!"
                       extra={<Button type="primary" href="/">OK</Button>}></Result>
            </div>
        )
    }
}
const mapStateToProps = state => {
    return {
    }
}
export default connect(mapStateToProps, {
}) (IndexPage);
