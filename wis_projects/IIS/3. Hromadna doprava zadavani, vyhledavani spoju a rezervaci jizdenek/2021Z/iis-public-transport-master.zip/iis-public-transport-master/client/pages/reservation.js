import React, {useState} from "react";
import Head from 'next/head';

import {Row, Col, message, Table, Alert } from 'antd'; 

import axios from 'axios';
import Router from 'next/router';

import {LoadingOutlined} from '@ant-design/icons';
import jwt_decode from "jwt-decode";

export default class Ticket extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          loggedUser: 'loading',
          data : 'loading'
        }
    }

    componentDidMount = () => {
      let token = localStorage.getItem('authToken')
      if (token === null) {
          Router.push('/')
      } else {
          let user = jwt_decode(token)
          this.setState({loggedUser: user})

          axios({
            method: "get",
            url: "https://iis-public-transport.herokuapp.com/api/ticket/get_ticket_list",
            headers: {
              'Authorization': 'Bearer ' + token
          }
        })
            .then(res => {
              console.log(res.data)
              this.setState({data:res.data})
            }
                )
            .catch(err => {
                console.log(err)
                this.state({data: null})
            })


      }
  }

    render() {
      const columns = [
        {
          title: 'ID',
          dataIndex: 'id',
          key: 'id',
        },
        {
          title: 'ConnectionId',
          dataIndex: 'connectionId',
          key: 'connectionId',
          },
        {
          title: 'From',
          dataIndex: 'from',
          key: 'from',
        },
        {
          title: 'To',
          dataIndex: 'to',
          key: 'to',
        },
    
        {
          title: 'Email',
          dataIndex: 'email',
          key: 'email',
          },

        {
          title: 'Price',
          dataIndex: 'price',
          key: 'price',
          },
    
      ];
      if (this.state.loggedUser === 'loading' || this.state.data === 'loading') {
        return (
            <div style={{fontSize: '4em', paddingTop: '6vh'}} align='center'>
                <LoadingOutlined/>
            </div>
        )
    } else if (this.state.loggedUser !== 'loading' && this.state.data !== "loading") {
        return (
          <>
          {this.state.data.length > 0 ?
            <div>
                <Head>
                    <title>Ticket</title>
                </Head>     
                <Row  style={{marginTop: '10em'}}>
                <Col xs={0} sm={1} md={3} lg={4} xl={4}>
                </Col>
                    <Col align='right' xs={0} sm={6} md={14} lg={15} xl={15}>
                    <Table columns={columns} dataSource={this.state.data} />
                    </Col>
                </Row> 

            </div>
            : <div>
                <Alert
                message="Warning"
                description="You have no reserved tickets."
                type="warning"
                showIcon
                closable
                />
            </div>
          }
          </>
        ) }    else {
            return(<></>)
        
        }
    } 

}
